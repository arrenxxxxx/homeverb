#!/usr/bin/env python3
"""Fixed AIHome H5 read routes from HisenseHA commit 43c7f17c. No controls.

This commonweb transport is distinct from the APK's native gateWay bridge.
Its live verification and login-session provenance are recorded separately.
"""
import time
import uuid
import argparse
from pathlib import Path
from datetime import datetime, timezone

from hisense_account import HisenseAccount, AccountError, portal_request, load_tokens, private_write


class HisenseAIHomeRead(HisenseAccount):
    _ENDPOINTS = {
        "aihome_homes": ("POST", "https://iot-aihome.hismarttv.com/4.0/iot/home/list"),
        "aihome_devices": ("POST", "https://iot-aihome.hismarttv.com/4.0/iot/devices/list"),
        "aihome_detail": ("POST", "https://iot-aihome.hismarttv.com/4.0/iot/devices/detail"),
    }
    _SIGNED_OPERATIONS = set(_ENDPOINTS)

    def _read(self, operation, access_token, customer_id, fields):
        if operation not in self._ENDPOINTS:
            raise ValueError("Unsupported AIHome read")
        expected = {"aihome_homes": set(), "aihome_devices": {"homeId"},
                    "aihome_detail": {"deviceId", "partnerId"}}
        if (set(fields) != expected[operation]
                or any(not isinstance(value, str) or not value for value in fields.values())):
            raise ValueError("Unsupported AIHome read fields")
        if not isinstance(access_token, str) or not access_token:
            raise ValueError("An access token is required")
        if not isinstance(customer_id, str) or not customer_id:
            raise ValueError("A customer ID from the account response is required")
        timestamp = int(time.time() * 1000)
        body = {
            "lastUpdateTime": 0, "accessToken": access_token, "appVersion": "", "openId": "",
            "version": "1.0", "deviceType": 2, "appType": 100, "versionCode": "101",
            "adaptertRank": 720, "_": timestamp,
            "header": {"messageId": str(uuid.uuid4())},
            "payload": {"customerId": customer_id, "sourceType": 3, **fields},
        }
        request = portal_request(body, timestamp)
        # This H5 transport signs the JSON body and has no system query string.
        request.pop("params")
        request["headers"].update(Accept="application/json", **{"User-Agent": "okhttp/4.10.0"})
        result = self._request(operation, **request)
        payload = result.get("payload") if isinstance(result, dict) else None
        if (not isinstance(payload, dict) or payload.get("status") != "SUCCESS"
                or result.get("httpCode") in (401, 403)):
            raise AccountError("AIHome read did not return payload.status SUCCESS")
        return payload

    def homes(self, access_token, customer_id):
        payload = self._read("aihome_homes", access_token, customer_id, {})
        if not isinstance(payload.get("homes"), list):
            raise AccountError("AIHome response has no homes list")
        return payload["homes"]

    def devices(self, access_token, customer_id, home_id):
        if not isinstance(home_id, str) or not home_id:
            raise ValueError("A home ID from homes() is required")
        payload = self._read("aihome_devices", access_token, customer_id, {"homeId": home_id})
        if not isinstance(payload.get("devices"), list):
            raise AccountError("AIHome response has no devices list")
        return payload["devices"]

    def detail(self, access_token, customer_id, device_id, partner_id):
        if any(not isinstance(value, str) or not value for value in (device_id, partner_id)):
            raise ValueError("Device and partner IDs from devices() are required")
        payload = self._read("aihome_detail", access_token, customer_id,
                             {"deviceId": device_id, "partnerId": partner_id})
        if not isinstance(payload.get("device"), dict) or not payload["device"]:
            raise AccountError("AIHome response has no device detail object")
        return payload["device"]


def read_washers(api, tokens):
    homes = api.homes(tokens.access_token, tokens.customer_id)
    records = []
    for home in homes:
        home_id = (home.get("id") or home.get("homeId")) if isinstance(home, dict) else None
        if not isinstance(home_id, (str, int)) or isinstance(home_id, bool) or not home_id:
            raise AccountError("AIHome home record has no identity")
        devices = api.devices(tokens.access_token, tokens.customer_id, str(home_id))
        details = []
        for device in devices:
            if not isinstance(device, dict):
                raise AccountError("Invalid AIHome device record")
            if (device.get("product") or {}).get("code") not in {"WV20W-1", "WH120E5S-1"}:
                continue
            partner_id = str((device.get("partner") or {}).get("id") or device.get("partnerId") or "1001")
            detail = api.detail(tokens.access_token, tokens.customer_id, str(device["deviceId"]), partner_id)
            if (detail.get("deviceId") != device["deviceId"]
                    or (detail.get("product") or {}).get("code") != device["product"]["code"]
                    or not isinstance(detail.get("states"), dict) or not detail["states"]):
                raise AccountError("Washer detail lacks matching identity or states")
            details.append(detail)
        records.append({"home": home, "devices": devices, "target_details": details})
    return {"received_at": datetime.now(timezone.utc).isoformat(), "transport": "AIHome H5 commonweb",
            "homes": records, "physical_sample_freshness_confirmed": False, "control_executed": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--private-dir", type=Path,
                        default=Path(__file__).resolve().parents[1] / "runtime/private/account")
    args = parser.parse_args()
    api = HisenseAIHomeRead()
    try:
        data = read_washers(api, load_tokens(args.private_dir / "session.json"))
        private_write(args.private_dir / "aihome-directory.json", data)
        print("只读验证完成：家庭数 %d，目标洗衣机详情数 %d；原始结果已私密保存。" % (
            len(data["homes"]), sum(len(h["target_details"]) for h in data["homes"])))
    except AccountError as error:
        if api.last_response_text is not None:
            private_write(args.private_dir / "aihome-error-wire.json", {"text": api.last_response_text})
        print(str(error))
        raise SystemExit(1) from None
    except (ValueError, OSError):
        print("读取未完成，请检查私有会话文件与权限；未输出敏感详情。")
        raise SystemExit(1) from None
    finally:
        api.close()


if __name__ == "__main__":
    main()
