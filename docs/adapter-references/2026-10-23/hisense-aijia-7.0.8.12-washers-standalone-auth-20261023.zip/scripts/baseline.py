#!/usr/bin/env python3
"""Offline inventory for this exact APK; never contacts a device or service."""
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
APK = ROOT.parents[2] / "HIAILife_Android_7.0.8.12_fortify_JUHAOKAN_QRCODE.apk"
EXPECTED_SHA256 = "937cf3f074457e9550b201329e635e9c38c4c012d6fe4744ab2b8fe530584a55"


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def main():
    digest = hashlib.file_digest(APK.open("rb"), "sha256").hexdigest()
    if digest != EXPECTED_SHA256:
        raise SystemExit("APK digest differs; use a separate analysis directory")
    with ZipFile(APK) as archive:
        entries = archive.infolist()
        inventory = []
        for entry in entries:
            item = {"path": entry.filename, "bytes": entry.file_size}
            if entry.filename.startswith("lib/") or entry.filename.endswith((".dex", ".jar")):
                item["sha256"] = hashlib.sha256(archive.read(entry)).hexdigest()
            inventory.append(item)
        save("apk_inventory.json", inventory)
        for name in ["libapp.so", "libflutter.so", "libEncryption.so", "libhiconnect_jni.so", "libhs_protocol_clientjni_64k.so", "libbaiduprotect.so", "libdexvmp.so"]:
            data = archive.read("lib/arm64-v8a/" + name)
            rows = [f"{m.start():08x}\t{m[0].decode('ascii')}" for m in re.finditer(rb"[\x20-\x7e]{5,}", data)]
            target = ROOT / "sources" / (name + ".strings.tsv")
            target.write_text("\n".join(rows) + "\n")
    manifest = ET.parse(ROOT / "jadx/resources/AndroidManifest.xml").getroot()
    android = "{http://schemas.android.com/apk/res/android}"
    sdk = manifest.find("uses-sdk")
    log = (ROOT / "jadx.log").read_text(errors="replace")
    sources = list((ROOT / "jadx/sources").rglob("*.java"))
    failed_entries = re.findall(r"Failed to read zip entry: [^\n]*?:([^\n]+)", log)
    node_errors = re.findall(r"finished with errors, count: (\d+)", log)
    baseline = {
        "apk": APK.name, "sha256": digest, "bytes": APK.stat().st_size,
        "package": manifest.get("package"), "version_name": manifest.get(android + "versionName"),
        "version_code": manifest.get(android + "versionCode"),
        "min_sdk": sdk.get(android + "minSdkVersion"), "target_sdk": sdk.get(android + "targetSdkVersion"),
        "zip_entries": len(entries), "abis": sorted({e.filename.split('/')[1] for e in entries if e.filename.startswith('lib/')}),
        "native_libraries": sum(e.filename.startswith('lib/') and e.filename.endswith('.so') for e in entries),
        "root_dex_files": [e.filename for e in entries if re.fullmatch(r'classes\d*\.dex', e.filename)],
        "protected_jar_payloads": sum(bool(re.fullmatch(r'assets/baiduprotect\d+\.jar', e.filename)) for e in entries),
        "jadx": {"version": "1.5.6", "java": "21.0.11-tem", "exit_code": 3,
                 "java_files": len(sources), "failed_input_entries": failed_entries,
                 "reported_node_errors": int(node_errors[-1]) if node_errors else None,
                 "limitation": "Java business payloads remain protected; the i.dex archives contain mostly zero-filled placeholder DEX files. Flutter AOT is a separate evidence source."},
        "scope": "Two user-owned washing machines; exact models not provided; read-only dynamic validation",
        "control_executed": False,
    }
    save("baseline.json", baseline)
    route_index = []
    string_file = ROOT / "sources/libapp.so.strings.tsv"
    for line, row in enumerate(string_file.read_text().splitlines(), 1):
        offset, text = row.split("\t", 1)
        if re.match(r"https?://", text):
            route_index.append({"literal": text, "elf_file_offset": "0x" + offset,
                                "source": str(string_file.relative_to(ROOT)), "line": line,
                                "level": "string_candidate_only", "method": None, "body": None,
                                "execution_enabled": False})
    save("route_candidates.json", route_index)
    print(json.dumps({"package": baseline["package"], "version": baseline["version_name"],
                      "java_files": len(sources), "failed_input_entries": len(failed_entries),
                      "route_literals": len(route_index)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
