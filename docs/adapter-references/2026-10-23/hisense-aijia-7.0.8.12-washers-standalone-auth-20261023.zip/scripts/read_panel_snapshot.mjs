// Read the existing family-washer Vuex state. No bridge calls or device requests.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const privateDir = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../runtime/private');
const targets = JSON.parse(fs.readFileSync(path.join(privateDir, 'webview-targets.json'), 'utf8'));
const target = targets.find(item => item.title === 'family-washer' && item.type === 'page');
if (!target) throw new Error('Expected family-washer page is not available');
const endpoint = new URL(target.webSocketDebuggerUrl);
if (endpoint.protocol !== 'ws:' || !['127.0.0.1', 'localhost'].includes(endpoint.hostname)) {
  throw new Error('Only the local Android WebView forward is permitted');
}
const expression = `(() => {
  const state = document.querySelector('#app').__vue__.$store.state;
  const result = {
    capturedAt: new Date().toISOString(),
    currentDeviceInfo: state.currentDeviceInfo,
    groupInfo: state.groupInfo,
    wholeFamilyControl: state.wholeFamilyControl,
    currentAppTubeMode: state.currentAppTubeMode,
    remoteAuthConfig: state.remoteAuthConfig,
    deviceModules: Object.fromEntries(Object.entries(state).filter(([key]) => key.includes(':')))
  };
  const ancestors = [];
  return JSON.stringify(result, function (key, value) {
    if (!value || typeof value !== 'object') return value;
    while (ancestors.length && ancestors[ancestors.length - 1] !== this) ancestors.pop();
    if (ancestors.includes(value)) return '[circular reference]';
    ancestors.push(value);
    return value;
  });
})()`;
const socket = new WebSocket(endpoint);
try {
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('WebView connection timeout')), 10000);
    socket.onopen = () => { clearTimeout(timer); resolve(); };
    socket.onerror = () => { clearTimeout(timer); reject(new Error('WebView connection failed')); };
  });
  const reply = await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('WebView read timeout')), 15000);
    socket.onmessage = event => {
      const message = JSON.parse(event.data);
      if (message.id !== 1) return;
      clearTimeout(timer);
      resolve(message);
    };
    socket.send(JSON.stringify({ id: 1, method: 'Runtime.evaluate',
      params: { expression, returnByValue: true } }));
  });
  if (reply.error || reply.result?.exceptionDetails) throw new Error('WebView snapshot failed');
  const raw = reply.result.result.value;
  const snapshot = JSON.parse(raw);
  const output = path.join(privateDir, 'panel-state.json');
  fs.writeFileSync(output, raw, { mode: 0o600 });
  fs.chmodSync(output, 0o600);
  console.log(JSON.stringify({ capturedAt: snapshot.capturedAt,
    moduleCount: Object.keys(snapshot.deviceModules).length, bytes: Buffer.byteLength(raw) }));
} finally {
  socket.close();
}
