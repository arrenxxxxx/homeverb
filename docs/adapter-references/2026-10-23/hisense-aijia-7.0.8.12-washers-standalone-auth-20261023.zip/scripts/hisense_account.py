#!/usr/bin/env python3
"""CN SMS/password account login, renewal and legacy directory reads. No controls.

SMS source: official account mobile 7.9.0-0 app.js, retrieved 2026-10-23.
Legacy renewal/directory: HisenseHA at 3d02d9859b7663412ded3e5e51608db4ebb34c20.
Live compatibility and native /4.0 support are recorded separately.
"""
import argparse
import base64
from dataclasses import dataclass, field
from datetime import datetime, timezone
import getpass
import hashlib
import hmac
import json
import os
from pathlib import Path
import stat
import time
import re
import uuid

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
import requests

from portal_constants import APP_KEY, APP_SECRET, AES_IV


class AccountError(Exception):
    """Safe diagnostic without credentials, URLs, or server messages."""


@dataclass(repr=False)
class Tokens:
    access_token: str = field(repr=False)
    refresh_token: str = field(repr=False)
    customer_id: str = field(default="", repr=False)


def encrypt_login_field(value):
    raw = value.encode("utf-8")
    padding = 16 - len(raw) % 16
    encryptor = Cipher(algorithms.AES(APP_SECRET.encode("ascii")), modes.CBC(AES_IV)).encryptor()
    data = encryptor.update(raw + bytes([padding]) * padding) + encryptor.finalize()
    return base64.b64encode(data).decode("ascii")


def portal_request(payload, timestamp_ms):
    body = json.dumps(payload, separators=(",", ":"), ensure_ascii=False)
    signature = hashlib.md5((body + APP_SECRET).encode("utf-8"), usedforsecurity=False).digest()
    return {
        "params": {"lastUpdateTime": "0", "version": "1.0", "deviceType": "2",
                   "appType": "100", "versionCode": "101", "adaptertRank": "720", "_": str(timestamp_ms)},
        "headers": {"Content-Type": "application/json; charset=UTF-8", "appKey": APP_KEY,
                    "X-Sign-For": base64.b64encode(signature).decode("ascii")},
        "data": body.encode("utf-8"),
    }


def login_request(username, password, timestamp_ms):
    if not isinstance(username, str) or not username or not isinstance(password, str) or not password:
        raise ValueError("Username and password are required")
    return portal_request({
        "loginName": encrypt_login_field(username), "signature": encrypt_login_field(password),
        "serverCode": "9501", "distributeId": "2001", "termType": 2,
    }, timestamp_ms)


def sms_request(phone, timestamp_ms, *, code=None, terminal_identity=None, sid=None):
    if not isinstance(phone, str) or not re.fullmatch(r"1[3-9][0-9]{9}", phone):
        raise ValueError("A mainland China mobile number is required")
    payload = {"mobilePhone": encrypt_login_field(phone)}
    if code is None:
        # Official AI Home login form, app.js character offset 605497.
        payload.update(serverCode="9501", accCategory="newhxaj", sourceType=2)
    else:
        if not isinstance(code, str) or not re.fullmatch(r"[0-9]{6}", code):
            raise ValueError("A six digit SMS code is required")
        if (not isinstance(terminal_identity, dict)
                or not re.fullmatch(r"[a-z0-9]{56}", terminal_identity.get("deviceId", ""))
                or not re.fullmatch(r"[0-9a-f]{32}", terminal_identity.get("devSerial", ""))
                or not isinstance(sid, str) or not re.fullmatch(r"[0-9a-f]{32}", sid)):
            raise ValueError("A standalone terminal identity and login flow ID are required")
        # Official AIHome form, offset 602130; verified with a standalone session.
        payload.update(authCode=code, sourceType=1, version="7.5", serverCode="9501",
                       sid=sid, accCategory="newhxaj", autoRegist="1",
                       deviceId=terminal_identity["deviceId"], devSerial=terminal_identity["devSerial"],
                       deviceType=1)
    return portal_request(payload, timestamp_ms)


def verify_portal_response(raw, value):
    signature = value.get("signatureServer") if isinstance(value, dict) else None
    # Official Je() remembers the final regex match, then removes only that one.
    # Nested upstream responses can carry another signatureServer field.
    matches = list(re.finditer(r',"signatureServer":(?:\s+)?"([^,]*)"', raw))
    if not matches or not isinstance(signature, str):
        raise AccountError("Account response signature is missing")
    match = matches[-1]
    unsigned = raw[:match.start()] + raw[match.end():]
    digest = hashlib.md5((unsigned + APP_SECRET).encode("utf-8"), usedforsecurity=False).digest()
    expected = base64.b64encode(digest).decode("ascii")
    if not hmac.compare_digest(signature, expected):
        raise AccountError("Account response signature verification failed")


class HisenseAccount:
    """Only login, renewal, family enumeration and device enumeration are exposed."""

    _ENDPOINTS = {
        "login": ("POST", "https://portal-account.hismarttv.com/mobile/se/signon"),
        "send_sms": ("POST", "https://portal-account.hismarttv.com/mobile/se/sendauthcode"),
        "sms_login": ("POST", "https://portal-account.hismarttv.com/mobile/se/loginByAuthCode"),
        "refresh": ("POST", "https://bas-wg.hismarttv.com/aaa/refresh_token2"),
        "homes": ("GET", "https://api-wg.hismarttv.com/wg/dm/getHomeList"),
        "devices": ("GET", "https://api-wg.hismarttv.com/wg/dm/getHomeDeviceList"),
    }
    _SIGNED_OPERATIONS = {"login", "send_sms", "sms_login"}

    def __init__(self):
        self._session = requests.Session()
        self._session.trust_env = False
        self._sms_sent_at = None
        self.last_response = None
        self.last_response_text = None

    def close(self):
        self._session.close()

    def _request(self, operation, **kwargs):
        # No arbitrary URL, route, redirect or device-command interface.
        if operation not in self._ENDPOINTS:
            raise ValueError("Unsupported operation")
        self.last_response = None
        self.last_response_text = None
        method, url = self._ENDPOINTS[operation]
        try:
            response = self._session.request(method, url, timeout=(10, 25),
                                             allow_redirects=False, **kwargs)
        except requests.RequestException:
            raise AccountError(f"{operation}: network/TLS request failed") from None
        try:
            # fetch().text() in the official client decodes UTF-8 regardless of
            # a misleading HTTP charset. Keep diagnostics before any rejection.
            raw = response.content.decode("utf-8-sig", errors="replace")
            self.last_response_text = raw
            if response.status_code != 200:
                raise AccountError(f"{operation}: HTTP {response.status_code}")
            try:
                value = json.loads(raw)
            except ValueError:
                raise AccountError(f"{operation}: invalid JSON response") from None
            # Diagnostic data is untrusted until verification succeeds. Callers may
            # save it privately on failure, but must not accept its tokens.
            self.last_response = value
            if operation in self._SIGNED_OPERATIONS:
                verify_portal_response(raw, value)
            return value
        finally:
            response.close()

    @staticmethod
    def _successful_object(value, key, codes=(0,)):
        data = value.get(key) if isinstance(value, dict) else None
        if (not isinstance(data, dict) or type(data.get("resultCode")) is not int
                or data["resultCode"] not in codes or data.get("errorCode")):
            code = data.get("resultCode") if isinstance(data, dict) else None
            safe_code = str(code) if type(code) is int else "unknown"
            error = data.get("errorCode") if isinstance(data, dict) else None
            safe_error = str(error) if type(error) is int else "unknown"
            detail = ""
            description = data.get("errorDesc") if isinstance(data, dict) else None
            if isinstance(description, str):
                missing = re.fullmatch(r'Error: required parameter: "([A-Za-z_][A-Za-z0-9_.-]{0,63})" (not found|value is empty)\.', description)
                if missing:
                    detail = f"; required parameter {missing[1]}: {missing[2]}"
                elif description == "TypeError: Cipher data must be a string or a buffer":
                    detail = "; server cipher input type error (field unknown)"
            raise AccountError(f"Business request rejected (resultCode={safe_code}, errorCode={safe_error}){detail}")
        return data

    @classmethod
    def _tokens(cls, response):
        data = cls._successful_object(response, "data", (0, 100000))
        info = data.get("tokenInfo")
        if not isinstance(info, dict) or not isinstance(info.get("token"), str) or not info["token"]:
            raise AccountError("Login response has no access token")
        if not isinstance(info.get("refreshToken"), str) or not info["refreshToken"]:
            raise AccountError("Login response has no refresh token")
        customer = info.get("customerId") or data.get("customerId") or response.get("customerId")
        customer_id = str(customer) if type(customer) is int or isinstance(customer, str) else ""
        return Tokens(info["token"], info["refreshToken"], customer_id)

    def login(self, username, password):
        return self._tokens(self._request("login", **login_request(username, password, int(time.time() * 1000))))

    def send_sms(self, phone):
        # One explicit request, no retries after a timeout; server may already have sent it.
        if self._sms_sent_at is not None and time.monotonic() - self._sms_sent_at < 60:
            raise AccountError("Wait 60 seconds before requesting another SMS")
        request = sms_request(phone, int(time.time() * 1000))
        self._sms_sent_at = time.monotonic()
        self._successful_object(self._request("send_sms", **request), "data", (0, 100000))

    def login_sms(self, phone, code, *, terminal_identity, sid, allow_registration=False):
        if not allow_registration:
            raise ValueError("Official AIHome login includes autoRegist=1; explicit opt-in is required")
        request = sms_request(phone, int(time.time() * 1000), code=code,
                              terminal_identity=terminal_identity, sid=sid)
        return self._tokens(self._request("sms_login", **request))

    def refresh(self, tokens):
        result = self._request("refresh", data={"refreshToken": tokens.refresh_token,
                                                "appKey": "1234567890", "format": "1"})
        info = result[0] if isinstance(result, list) and result else None
        if not isinstance(info, dict) or not isinstance(info.get("token"), str) or not info["token"]:
            raise AccountError("Renewal response has no access token; login is required")
        # Published implementation establishes no reliable expiry unit or failure-code retry rule.
        rotated = info.get("refreshToken")
        return Tokens(info["token"], rotated if isinstance(rotated, str) and rotated else tokens.refresh_token,
                      tokens.customer_id)

    @staticmethod
    def _directory_params(tokens):
        return {"sign": "", "languageId": "0", "version": "8.0", "accessToken": tokens.access_token,
                "timezone": "28800", "format": "1", "timeStamp": str(int(time.time() * 1000))}

    def homes(self, tokens):
        data = self._successful_object(self._request("homes", params=self._directory_params(tokens)), "response")
        if not isinstance(data.get("homeList"), list):
            raise AccountError("Directory response has no homeList")
        return data["homeList"]

    def devices(self, tokens, home_id):
        if not isinstance(home_id, str) or not home_id:
            raise ValueError("A home ID returned by homes() is required")
        params = self._directory_params(tokens)
        params["homeId"] = home_id
        data = self._successful_object(self._request("devices", params=params), "response")
        if not isinstance(data.get("deviceList"), list):
            raise AccountError("Directory response has no deviceList")
        return data["deviceList"]


def private_write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    if path.parent.is_symlink() or stat.S_IMODE(path.parent.stat().st_mode) != 0o700:
        raise ValueError("Private output directory must have mode 0700 and not be a symlink")
    temporary = path.with_name(path.name + ".tmp")
    fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    try:
        with os.fdopen(fd, "w") as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
        if path.is_symlink():
            raise ValueError("Private output must not be a symlink")
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def save_tokens(path, tokens):
    private_write(path, {"access_token": tokens.access_token, "refresh_token": tokens.refresh_token,
                         "customer_id": tokens.customer_id,
                         "updated_at": datetime.now(timezone.utc).isoformat(), "source": "CN_portal"})


def load_tokens(path):
    path = Path(path)
    if path.is_symlink() or stat.S_IMODE(path.stat().st_mode) != 0o600:
        raise ValueError("Session file must have mode 0600 and not be a symlink")
    value = json.loads(path.read_text())
    if any(not isinstance(value.get(k), str) or not value[k] for k in ("access_token", "refresh_token")):
        raise ValueError("Invalid session file")
    customer = value.get("customer_id", "")
    if not isinstance(customer, str):
        raise ValueError("Invalid customer ID in session file")
    return Tokens(value["access_token"], value["refresh_token"], customer)


def standalone_terminal(path):
    path = Path(path)
    if path.exists():
        if path.is_symlink() or stat.S_IMODE(path.stat().st_mode) != 0o600:
            raise ValueError("Terminal identity must be a private 0600 file")
        return json.loads(path.read_text())
    identity = {"deviceId": "862fff00fffefff00000fffexyz" + uuid.uuid4().hex[:29],
                "devSerial": uuid.uuid4().hex, "source": "independently_generated_client_identity",
                "not_copied_from_App": True}
    private_write(path, identity)
    return identity


def read_directory(api, tokens):
    homes = api.homes(tokens)
    records = []
    for home in homes:
        home_id = home.get("homeId") if isinstance(home, dict) else None
        # The live legacy directory returns numeric IDs; query parameters are text.
        if type(home_id) is int and home_id > 0:
            home_id = str(home_id)
        if not isinstance(home_id, str) or not home_id:
            raise AccountError("Family record has no homeId")
        records.append({"home": home, "devices": api.devices(tokens, home_id)})
    return {"received_at": datetime.now(timezone.utc).isoformat(), "source": "legacy_directory",
            "homes": records, "physical_state_freshness_confirmed": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("sms-login", "sms-complete", "login", "refresh", "devices"))
    parser.add_argument("--private-dir", type=Path, default=Path(__file__).resolve().parents[1] / "runtime/private/account")
    parser.add_argument("--allow-registration", action="store_true",
                        help="Explicitly allow official SMS login's autoRegist=1 behavior")
    args = parser.parse_args()
    session_path = args.private_dir / "session.json"
    status_path = args.private_dir / "last_run.json"
    phase = "start"
    api = HisenseAccount()
    try:
        if args.command in {"sms-login", "sms-complete", "login"} and not os.isatty(0):
            raise ValueError("Run login in a local terminal; credentials are never command-line arguments")
        if args.command in {"sms-login", "sms-complete"}:
            if not args.allow_registration:
                raise AccountError("SMS login requires --allow-registration because the official form uses autoRegist=1")
            identity = standalone_terminal(args.private_dir / "standalone-terminal.json")
            sid = uuid.uuid4().hex
            phone = getpass.getpass("海信已注册手机号（隐藏输入）: ")
            if args.command == "sms-login":
                phase = "send_sms"
                api.send_sms(phone)
                print("已请求发送一条登录短信，请在此终端输入验证码。")
            else:
                print("复用刚才收到的验证码，本次不发送新短信。")
            code = getpass.getpass("短信验证码（隐藏输入）: ")
            phase = "sms_login"
            tokens = api.login_sms(phone, code, terminal_identity=identity, sid=sid,
                                   allow_registration=args.allow_registration)
            del phone, code
            save_tokens(session_path, tokens)
            print("短信登录成功；令牌已写入本机私有文件。")
        elif args.command == "login":
            username = getpass.getpass("海信账号（隐藏输入）: ")
            password = getpass.getpass("海信密码（隐藏输入）: ")
            phase = "password_login"
            tokens = api.login(username, password)
            del username, password
            save_tokens(session_path, tokens)
            print("独立账号登录成功；令牌已写入本机私有文件。")
        elif args.command == "refresh":
            phase = "refresh"
            tokens = api.refresh(load_tokens(session_path))
            save_tokens(session_path, tokens)
            print("独立令牌续期成功；私有会话已更新。")
        else:
            phase = "directory"
            data = read_directory(api, load_tokens(session_path))
            private_write(args.private_dir / "directory.json", data)
            print(json.dumps({"homes": len(data["homes"]),
                              "device_records": sum(len(h["devices"]) for h in data["homes"]),
                              "raw_output_private": True}, ensure_ascii=False))
        private_write(status_path, {"command": args.command, "phase": phase, "success": True,
                                    "at": datetime.now(timezone.utc).isoformat()})
    except AccountError as error:
        if api.last_response is not None:
            private_write(args.private_dir / "error_response.json", api.last_response)
        if api.last_response_text is not None:
            private_write(args.private_dir / "error_response_wire.json", {"text": api.last_response_text})
        private_write(status_path, {"command": args.command, "phase": phase, "success": False,
                                    "reason": str(error), "at": datetime.now(timezone.utc).isoformat()})
        print(str(error))
        raise SystemExit(1) from None
    except (ValueError, OSError):
        print("操作未通过验证。请检查网络、私有文件权限或账号登录；未输出敏感异常详情。")
        raise SystemExit(1) from None
    finally:
        api.close()


if __name__ == "__main__":
    main()
