#!/usr/bin/env python3
"""Build shareable model capabilities from the authorized private App snapshot. Offline."""
import collections
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SNAPSHOT = ROOT / "runtime/private/panel-state.json"


def select(obj, keys):
    return {key: obj[key] for key in keys if key in obj}


def function_config(function):
    result = select(function, ["code", "name", "desc", "displayable", "action", "states"])
    result["attributes"] = []
    for attribute in function.get("attributes", []):
        clean = select(attribute, ["code", "type", "suffix", "step", "defaultValue", "value"])
        if isinstance(clean.get("value"), list):
            clean["value"] = [select(item, ["value", "code", "name", "stateName", "commandName", "seq"])
                              for item in clean["value"]]
        result["attributes"].append(clean)
    return result


def decode(module, code, state_key):
    raw = module["deviceStatus"].get(state_key)
    function = module["functionMap"].get("connector.device.function." + code, {})
    state = next((s for s in function.get("states", []) if s.get("code") == state_key), {})
    attribute = next((a for a in function.get("attributes", []) if a.get("code") == state.get("attribute")), {})
    values = attribute.get("value", [])
    value = next((v for v in values if str(v.get("value")) == str(raw)), {}) if isinstance(values, list) else {}
    return {"raw": raw, "code": value.get("code"), "label": value.get("stateName", value.get("name"))}


def main():
    snapshot = json.loads(SNAPSHOT.read_text())
    modules = list(snapshot["deviceModules"].values())
    expected = {"WV20W-1", "WH120E5S-1"}
    assert {m["deviceInfo"]["productCode"] for m in modules} == expected
    group_ids = {d["deviceId"] for d in snapshot["groupInfo"]["devices"]}
    module_ids = {m["deviceInfo"]["deviceId"] for m in modules}
    assert len(group_ids) == 2 and group_ids == module_ids
    digest = hashlib.sha256(SNAPSHOT.read_bytes()).hexdigest()
    models = []
    for module in modules:
        info = module["deviceInfo"]
        product = info["productCode"]
        multiple = product == "WV20W-1"
        functions = [function_config(v) for k, v in module["functionMap"].items()
                     if isinstance(v, dict) and v.get("code") == k]
        modes = [select(m, ["code", "value", "name", "desc", "defaultExecTime", "visibleFlag", "functionCodeList"])
                 for m in module["deviceModeList"]]
        counts = collections.Counter("left" if m["code"].endswith(".left") else
                                     "right" if m["code"].endswith(".right") else "single" for m in modes)
        configured = {f["code"] for f in functions}
        mode_refs = {c for m in modes for c in m.get("functionCodeList", [])}
        states = {"online": decode(module, "Online", "onlineStatus"),
                  "power": decode(module, "PowerControl", "powerStatus"),
                  "remote_permission": decode(module, "RemoteControlFlag", "remoteControlFlag"),
                  "child_lock": decode(module, "ChildLock", "childLock")}
        state_keys = (["runStatus.multiple", "runStatus.left", "runStatus.right", "remainRunTime.left", "remainRunTime.right", "workMode.left", "workMode.right", "tubMode"]
                      if multiple else ["runStatus", "remainRunTime", "workMode", "doorStatus", "doorLockStatus"])
        states["additional_raw"] = select(module["deviceStatus"], state_keys)
        models.append({
            "alias": "upper_dual_tub" if multiple else "lower_washer",
            "partition": "upper: left/right" if multiple else "lower",
            "identity": select(info, ["categoryCode", "productCode", "partnerId"]),
            "retail_model": None,
            "retail_model_note": "App product.name equals the internal product code; full retail label not independently confirmed.",
            "reported_device_info": select(info.get("detail", {}).get("deviceInfo", {}), ["hwVersion", "swVersion"]),
            "current_app_state": states,
            "state_freshness": "App cache reception time known; physical sampling time and cache freshness unverified. Remaining time while powered off is not evidence of running.",
            "functions": sorted(functions, key=lambda f: f["code"]),
            "function_definition_count": len(functions),
            "function_count_note": "Excludes the synthetic functionMap.stateMap helper. Definitions are not a feature-coverage denominator.",
            "programs": modes, "program_entry_count": len(modes),
            "program_partition_counts": dict(counts),
            "all_program_entries_visible_in_config": all(m.get("visibleFlag") == 1 for m in modes),
            "mode_parameter_detail": {"complete": False, "program_function_codes_missing_from_general_map": sorted(mode_refs - configured),
                                      "note": "General product attributes are recorded; mode-specific getModesFunctions responses were not captured. Do not apply a general range to every program."},
            "constraint_label_names": sorted(module.get("deviceExternalInfo", {})),
            "statistics_cache": {"present_fields": sorted(module.get("washReportInfo", {})), "period_confirmed": False,
                                 "history_or_report_http_verified": False, "values_included": False},
            "verification": {"original_app_device_cache_observed": True, "independent_http_read_verified": False,
                             "control_executed": False},
            "evidence": {"file": "runtime/private/panel-state.json", "sha256": digest,
                         "selector": "deviceModules.*.deviceInfo.productCode=" + product},
        })
    output = {"schema_version": 1, "captured_at": snapshot["capturedAt"],
              "source": "Existing original-App Vuex state via its pre-enabled local WebView debugger; no query/control bridge calls",
              "group": {"productCode": snapshot["groupInfo"]["productCode"], "member_count": 2,
                        "member_id_set_equals_device_module_id_set": True, "full_account_inventory_verified": False},
              "configuration_note": "Final configuration used by the App; UI-derived active flags omitted. Not a raw server response.",
              "models": models, "execution_enabled": False, "control_executed": False}
    (ROOT / "models.json").write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n")
    observations = {"captured_at": snapshot["capturedAt"], "authenticated_app_session_observed": True,
                    "credential_or_otp_captured": False, "group_members_observed": 2,
                    "full_private_id_set_matched_locally": True, "ids_included": False,
                    "source_snapshot_sha256": digest, "source": "Authorized original-App cache; not independent HTTP",
                    "observed_ui": ["Grouped family washer card", "Upper/lower partitions and left/right tubs", "Powered off", "Control page version 1.8.0.5", "Lower partition long-term remote authorization", "Care manager recommendation page"],
                    "controls_or_settings_written": False, "cloud_requests_sent_by_analysis_client": 0,
                    "limits": ["All-account inventory not independently enumerated", "Physical sampling freshness unknown", "Mode-specific parameter responses not captured", "No independent login/signature/renewal or control validation"],
                    "private_evidence_excluded_from_delivery": True}
    (ROOT / "runtime/observations.json").write_text(json.dumps(observations, ensure_ascii=False, indent=2) + "\n")
    print("Generated 2 sanitized model records; IDs, session values and usage totals excluded")


if __name__ == "__main__":
    main()
