"""Published web-client constants, not user account credentials.
Source: manymuch/HisenseHA, MIT licensed, revision
3d02d9859b7663412ded3e5e51608db4ebb34c20, pyhisenseapi.py:13-15.
"""
APP_KEY = 'commonweb'
APP_SECRET = 'MORZRbkuiWxjp+SM4vR_GxY4pZxLZ6rn'
AES_IV = APP_SECRET[:16].encode("ascii")
