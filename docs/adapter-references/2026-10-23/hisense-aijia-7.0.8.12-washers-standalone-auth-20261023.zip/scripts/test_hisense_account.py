#!/usr/bin/env python3
"""Offline protocol vectors, transport isolation and secret-storage checks."""
import base64
import hashlib
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock, patch

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes

import hisense_account as account


class AccountTests(unittest.TestCase):
    def setUp(self):
        self.client = account.HisenseAccount()
        # Any accidental test network call fails immediately.
        self.network = patch.object(self.client._session, "request")
        self.request = self.network.start()
        self.request.side_effect = AssertionError("Unexpected network request")
        self.tokens = account.Tokens("synthetic-access", "synthetic-refresh")
        self.identity = {"deviceId": "x" * 56, "devSerial": "a" * 32}
        self.sid = "b" * 32

    def sms_login(self, phone, code):
        return self.client.login_sms(phone, code, terminal_identity=self.identity,
                                     sid=self.sid, allow_registration=True)

    def tearDown(self):
        self.network.stop()
        self.client.close()

    def response(self, value, status=200):
        self.request.side_effect = None
        response = Mock(status_code=status)
        # Build an independently signed raw wire response for the portal verifier.
        if isinstance(value, dict):
            unsigned = json.dumps(value, separators=(",", ":"), ensure_ascii=False)
            digest = hashlib.md5((unsigned + account.APP_SECRET).encode(), usedforsecurity=False).digest()
            value = dict(value, signatureServer=base64.b64encode(digest).decode())
        response.text = json.dumps(value, separators=(",", ":"), ensure_ascii=False)
        response.content = response.text.encode("utf-8")
        response.json.return_value = value
        self.request.return_value = response
        return response

    def test_openssl_independent_aes_vector(self):
        key = "0123456789abcdef0123456789abcdef"
        with patch.object(account, "APP_SECRET", key), patch.object(account, "AES_IV", key[:16].encode()):
            self.assertEqual(account.encrypt_login_field("synthetic-user-测试"),
                             "ieZJw3+cPKsU30OtoUCj1n/08BoOckpsvhvPeAis+Xs=")

    def test_signed_body_is_exact_sent_utf8_and_fields_are_encrypted(self):
        request = account.login_request("synthetic-user", "synthetic-password", 1234567890000)
        raw = request["data"]
        self.assertNotIn(b"synthetic-user", raw)
        self.assertNotIn(b"synthetic-password", raw)
        self.assertNotIn(b" ", raw)
        digest = hashlib.md5(raw + account.APP_SECRET.encode(), usedforsecurity=False).digest()
        self.assertEqual(base64.b64decode(request["headers"]["X-Sign-For"]), digest)
        self.assertEqual(request["params"]["_"], "1234567890000")
        self.assertIs(type(json.loads(raw)["termType"]), int)
        encrypted = base64.b64decode(json.loads(raw)["loginName"])
        decryptor = Cipher(algorithms.AES(account.APP_SECRET.encode()), modes.CBC(account.AES_IV)).decryptor()
        padded = decryptor.update(encrypted) + decryptor.finalize()
        self.assertEqual(padded[:-padded[-1]], b"synthetic-user")

    def test_transport_disables_proxy_and_redirect(self):
        self.response({"response": {"resultCode": 0, "homeList": []}})
        self.assertFalse(self.client._session.trust_env)
        self.assertEqual(self.client.homes(self.tokens), [])
        args, kwargs = self.request.call_args
        self.assertEqual(args, ("GET", "https://api-wg.hismarttv.com/wg/dm/getHomeList"))
        self.assertIs(kwargs["allow_redirects"], False)
        self.assertIn("timeout", kwargs)
        self.response({}, 302)
        with self.assertRaisesRegex(account.AccountError, "HTTP 302"):
            self.client.homes(self.tokens)

    def test_no_arbitrary_route_or_control(self):
        for operation in ("execute", "set", "https://example.test", "/iot/devices/execute"):
            with self.assertRaises(ValueError):
                self.client._request(operation)
        self.request.assert_not_called()
        self.assertEqual(set(self.client._ENDPOINTS),
                         {"login", "send_sms", "sms_login", "refresh", "homes", "devices"})

    def test_sms_official_aijia_fields_and_explicit_opt_in(self):
        phone = "13800000000"  # Synthetic only; never sent to a server.
        send = account.sms_request(phone, 123)
        payload = json.loads(send["data"])
        self.assertEqual(payload["sourceType"], 2)
        self.assertEqual(payload["serverCode"], "9501")
        self.assertEqual(payload["accCategory"], "newhxaj")
        self.assertNotIn(phone.encode(), send["data"])
        login = account.sms_request(phone, 456, code="012345", terminal_identity=self.identity, sid=self.sid)
        payload = json.loads(login["data"])
        self.assertEqual(payload["sourceType"], 1)
        self.assertEqual(payload["authCode"], "012345")
        self.assertEqual(payload["version"], "7.5")
        self.assertEqual(payload["deviceType"], 1)
        self.assertEqual(payload["autoRegist"], "1")
        self.assertEqual(payload["deviceId"], self.identity["deviceId"])
        self.assertEqual(payload["devSerial"], self.identity["devSerial"])
        self.assertEqual(payload["sid"], self.sid)
        self.assertNotIn("loginPageShowTime", payload)
        with self.assertRaises(ValueError):
            self.client.login_sms(phone, "012345", terminal_identity=self.identity, sid=self.sid)
        self.request.assert_not_called()
        for bad in ("", "123", "13800000000&x=1", None):
            with self.assertRaises(ValueError):
                account.sms_request(bad, 123)
        for bad in ("", "12345", "1234567", "12345x"):
            with self.assertRaises(ValueError):
                account.sms_request(phone, 123, code=bad, terminal_identity=self.identity, sid=self.sid)

    def test_sms_success_requires_business_code_and_no_duplicate_sends(self):
        self.response({"data": {"resultCode": 100000}})
        self.client.send_sms("13800000000")
        self.assertEqual(self.request.call_args.args[1],
                         "https://portal-account.hismarttv.com/mobile/se/sendauthcode")
        with self.assertRaises(account.AccountError):
            self.client.send_sms("13800000000")
        self.assertEqual(self.request.call_count, 1)
        self.response({"data": {"resultCode": 100000, "tokenInfo": {
            "token": "synthetic-access", "refreshToken": "synthetic-refresh"}}})
        tokens = self.sms_login("13800000000", "012345")
        self.assertEqual(tokens.access_token, "synthetic-access")
        self.assertEqual(self.request.call_args.args[1],
                         "https://portal-account.hismarttv.com/mobile/se/loginByAuthCode")
        self.response({"data": {"resultCode": 0, "errorCode": 201506}})
        with self.assertRaisesRegex(account.AccountError, "201506"):
            self.sms_login("13800000000", "012345")

    def test_portal_signature_detects_tampering_or_missing_field(self):
        response = self.response({"data": {"resultCode": 100000}})
        value = response.json()
        account.verify_portal_response(response.text, value)
        for tampered in (response.text.replace("100000", "100001"), '{}'):
            with self.assertRaises(account.AccountError):
                account.verify_portal_response(tampered, value)

    def test_real_public_error_response_signature_vector(self):
        raw = (Path(__file__).parent / "fixtures/portal-unsigned-account-error.json").read_text()
        value = json.loads(raw)
        account.verify_portal_response(raw, value)
        self.assertEqual(value["data"]["errorCode"], 1)
        self.assertIn('"mobilePhone" not found', value["data"]["errorDesc"])
        with self.assertRaisesRegex(account.AccountError, "required parameter mobilePhone"):
            self.client._successful_object(value, "data", (0, 100000))

    def test_nested_upstream_signature_is_preserved_like_official_wrapper(self):
        response = self.response({"data": {"resultCode": 0, "upstream": {
            "resultCode": 0, "signatureServer": "synthetic-inner-signature"}}})
        account.verify_portal_response(response.text, response.json())
        tampered = response.text.replace("synthetic-inner-signature", "modified-inner-signature")
        with self.assertRaises(account.AccountError):
            account.verify_portal_response(tampered, response.json())

    def test_portal_uses_fetch_utf8_decoding_and_retains_non_json_errors(self):
        response = self.response({"data": {"resultCode": 100000, "message": "合成中文响应"}})
        response.text = response.content.decode("latin-1")
        self.client.send_sms("13800000000")
        self.assertIn("合成中文响应", self.client.last_response_text)
        response.content = b"<html>synthetic upstream failure</html>"
        response.status_code = 502
        with self.assertRaisesRegex(account.AccountError, "HTTP 502"):
            self.client._request("sms_login")
        self.assertEqual(self.client.last_response_text, response.content.decode())

    def test_failed_signature_keeps_untrusted_diagnostics_but_never_accepts_tokens(self):
        response = self.response({"data": {"resultCode": 0, "tokenInfo": {
            "token": "synthetic-access", "refreshToken": "synthetic-refresh"}}})
        response.text = response.text.replace('"resultCode":0', '"resultCode":100000')
        response.content = response.text.encode("utf-8")
        with self.assertRaisesRegex(account.AccountError, "signature verification failed"):
            self.sms_login("13800000000", "012345")
        self.assertEqual(self.client.last_response_text, response.text)
        self.assertIsNotNone(self.client.last_response)
        response.close.assert_called_once()

    def test_http_success_requires_business_success_and_list(self):
        for value in ({}, {"response": {"resultCode": 1, "homeList": []}},
                      {"response": {"resultCode": False, "homeList": []}},
                      {"response": {"resultCode": 0, "homeList": None}}):
            self.response(value)
            with self.assertRaises(account.AccountError):
                self.client.homes(self.tokens)

    def test_cipher_failure_is_distinguishable_without_echoing_arbitrary_server_text(self):
        value = {"data": {"resultCode": 1, "errorCode": 1,
                          "errorDesc": "TypeError: Cipher data must be a string or a buffer"}}
        with self.assertRaisesRegex(account.AccountError, "server cipher input type error.*field unknown"):
            self.client._successful_object(value, "data")
        value["data"]["errorDesc"] = "sensitive-server-detail synthetic-access"
        with self.assertRaises(account.AccountError) as context:
            self.client._successful_object(value, "data")
        self.assertNotIn("sensitive-server-detail", str(context.exception))
        self.assertNotIn("synthetic-access", str(context.exception))

    def test_login_requires_both_tokens(self):
        self.response({"data": {"resultCode": 0, "tokenInfo": {"token": "synthetic-access"}}})
        with self.assertRaises(account.AccountError):
            self.client.login("synthetic-user", "synthetic-password")
        self.response({"data": {"resultCode": 0, "tokenInfo": {
            "token": "synthetic-access", "refreshToken": "synthetic-refresh"}}})
        tokens = self.client.login("synthetic-user", "synthetic-password")
        self.assertEqual(tokens.access_token, self.tokens.access_token)
        self.assertNotIn("synthetic-access", repr(tokens))

    def test_refresh_rotation_and_invalid_response(self):
        for payload in ([], {}, [{"token": ""}], [{"token": 42}]):
            self.response(payload)
            with self.assertRaises(account.AccountError):
                self.client.refresh(self.tokens)
        self.response([{"token": "new-access"}])
        self.assertEqual(self.client.refresh(self.tokens).refresh_token, "synthetic-refresh")
        self.response([{"token": "new-access", "refreshToken": "new-refresh"}])
        self.assertEqual(self.client.refresh(self.tokens).refresh_token, "new-refresh")
        self.assertEqual(self.request.call_args.kwargs["data"], {
            "refreshToken": "synthetic-refresh", "appKey": "1234567890", "format": "1"})

    def test_customer_identity_is_preserved_for_aihome_reads(self):
        value = {"data": {"resultCode": 0, "tokenInfo": {
            "token": "synthetic-access", "refreshToken": "synthetic-refresh", "customerId": 12345}}}
        tokens = self.client._tokens(value)
        self.assertEqual(tokens.customer_id, "12345")
        self.response([{"token": "rotated-access"}])
        self.assertEqual(self.client.refresh(tokens).customer_id, "12345")
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "account/session.json"
            account.save_tokens(path, tokens)
            self.assertEqual(account.load_tokens(path).customer_id, "12345")

    def test_devices_preserve_washers_without_type_filtering(self):
        washer = {"deviceId": "synthetic-washer", "deviceTypeName": "洗衣机"}
        self.response({"response": {"resultCode": 0, "deviceList": [washer]}})
        self.assertEqual(self.client.devices(self.tokens, "synthetic-home"), [washer])
        self.assertEqual(self.request.call_args.kwargs["params"]["homeId"], "synthetic-home")

    def test_live_numeric_home_id_is_converted_for_query_only(self):
        api = Mock()
        api.homes.return_value = [{"homeId": 12345}]
        api.devices.return_value = []
        result = account.read_directory(api, self.tokens)
        api.devices.assert_called_once_with(self.tokens, "12345")
        self.assertEqual(result["homes"][0]["home"]["homeId"], 12345)
        for invalid in (True, None, "", [], {}):
            api.homes.return_value = [{"homeId": invalid}]
            with self.assertRaises(account.AccountError):
                account.read_directory(api, self.tokens)

    def test_private_session_permissions_and_symlink_refusal(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "account/session.json"
            identity = account.standalone_terminal(path.parent / "standalone-terminal.json")
            self.assertEqual(identity, account.standalone_terminal(path.parent / "standalone-terminal.json"))
            self.assertEqual(len(identity["deviceId"]), 56)
            self.assertEqual(len(identity["devSerial"]), 32)
            account.save_tokens(path, self.tokens)
            self.assertEqual(path.parent.stat().st_mode & 0o777, 0o700)
            self.assertEqual(path.stat().st_mode & 0o777, 0o600)
            self.assertEqual(account.load_tokens(path).access_token, "synthetic-access")
            os.chmod(path, 0o644)
            with self.assertRaises(ValueError):
                account.load_tokens(path)
            path.unlink()
            target = path.parent / "target.json"
            target.write_text("unchanged")
            path.symlink_to(target)
            with self.assertRaises(ValueError):
                account.save_tokens(path, self.tokens)
            self.assertEqual(target.read_text(), "unchanged")


if __name__ == "__main__":
    unittest.main()
