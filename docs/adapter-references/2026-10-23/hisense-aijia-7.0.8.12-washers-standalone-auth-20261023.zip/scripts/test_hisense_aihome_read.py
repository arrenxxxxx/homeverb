#!/usr/bin/env python3
"""Offline checks for the H5 read whitelist and signed body."""
import base64
import hashlib
import json
import unittest
from unittest.mock import Mock, patch

import hisense_account as account
from hisense_aihome_read import HisenseAIHomeRead, read_washers


class AIHomeReadTests(unittest.TestCase):
    def setUp(self):
        self.api = HisenseAIHomeRead()
        self.network = patch.object(self.api._session, "request")
        self.request = self.network.start()
        self.request.side_effect = AssertionError("Unexpected network request")

    def tearDown(self):
        self.network.stop()
        self.api.close()

    def respond(self, payload, status=200):
        self.request.side_effect = None
        raw = json.dumps(payload, separators=(",", ":"))
        digest = hashlib.md5((raw + account.APP_SECRET).encode(), usedforsecurity=False).digest()
        signed = {**payload, "signatureServer": base64.b64encode(digest).decode()}
        self.request.return_value = Mock(status_code=status,
                                         content=json.dumps(signed, separators=(",", ":")).encode())

    def test_signed_read_body_and_transport_match_source(self):
        self.respond({"payload": {"status": "SUCCESS", "homes": []}})
        self.assertEqual(self.api.homes("synthetic-token", "synthetic-customer"), [])
        args, kw = self.request.call_args
        self.assertEqual(args, ("POST", "https://iot-aihome.hismarttv.com/4.0/iot/home/list"))
        self.assertNotIn("params", kw)
        self.assertFalse(kw["allow_redirects"])
        self.assertFalse(self.api._session.trust_env)
        body = json.loads(kw["data"])
        self.assertEqual(body["payload"], {"customerId": "synthetic-customer", "sourceType": 3})
        self.assertEqual(body["accessToken"], "synthetic-token")
        self.assertEqual(body["deviceType"], 2)
        digest = hashlib.md5(kw["data"] + account.APP_SECRET.encode(), usedforsecurity=False).digest()
        self.assertEqual(base64.b64decode(kw["headers"]["X-Sign-For"]), digest)

    def test_whitelist_rejects_controls_and_unknown_routes(self):
        for operation in ("execute", "aihome_execute", "login", "/4.0/iot/devices/execute"):
            with self.assertRaises(ValueError):
                self.api._read(operation, "synthetic-token", "synthetic-customer", {})
        with self.assertRaises(ValueError):
            self.api._read("aihome_detail", "synthetic-token", "synthetic-customer", {"actions": []})
        self.assertEqual(set(self.api._ENDPOINTS), {"aihome_homes", "aihome_devices", "aihome_detail"})
        self.request.assert_not_called()

    def test_http_and_business_failures_are_not_success(self):
        for body in ({}, {"payload": {"status": "FAILURE", "homes": []}},
                     {"httpCode": 401, "payload": {"status": "SUCCESS", "homes": []}},
                     {"payload": {"status": "SUCCESS", "homes": None}}):
            self.respond(body)
            with self.assertRaises(account.AccountError):
                self.api.homes("synthetic-token", "synthetic-customer")
        self.respond({}, 302)
        with self.assertRaisesRegex(account.AccountError, "HTTP 302"):
            self.api.homes("synthetic-token", "synthetic-customer")

    def test_device_detail_keeps_named_states_and_requires_payload(self):
        device = {"deviceId": "synthetic-washer", "states": {"powerStatus": "0"}}
        self.respond({"payload": {"status": "SUCCESS", "device": device}})
        self.assertEqual(self.api.detail("synthetic-token", "synthetic-customer",
                                         "synthetic-washer", "1001"), device)
        self.assertEqual(json.loads(self.request.call_args.kwargs["data"])["payload"], {
            "customerId": "synthetic-customer", "sourceType": 3,
            "deviceId": "synthetic-washer", "partnerId": "1001"})
        self.respond({"payload": {"status": "SUCCESS", "device": {}}})
        with self.assertRaises(account.AccountError):
            self.api.detail("synthetic-token", "synthetic-customer", "synthetic-washer", "1001")

    def test_unverified_read_response_is_never_accepted(self):
        self.respond({"payload": {"status": "SUCCESS", "homes": []}})
        self.request.return_value.content = self.request.return_value.content.replace(b'"homes":[]', b'"homes":[{}]')
        with self.assertRaisesRegex(account.AccountError, "signature verification failed"):
            self.api.homes("synthetic-token", "synthetic-customer")

    def test_only_two_supported_models_are_read_and_partition_keys_preserved(self):
        api = Mock()
        tokens = account.Tokens("synthetic-token", "synthetic-refresh", "synthetic-customer")
        api.homes.return_value = [{"id": "synthetic-home"}]
        devices = [{"deviceId": "synthetic-upper", "product": {"code": "WV20W-1"}},
                   {"deviceId": "synthetic-lower", "product": {"code": "WH120E5S-1"}},
                   {"deviceId": "synthetic-other", "product": {"code": "unsupported"}}]
        api.devices.return_value = devices
        api.detail.side_effect = [{**d, "states": {"runStatus.left": "0", "runStatus.right": "1"}}
                                  for d in devices[:2]]
        result = read_washers(api, tokens)
        self.assertEqual(api.detail.call_count, 2)
        details = result["homes"][0]["target_details"]
        self.assertEqual(details[0]["states"]["runStatus.right"], "1")
        self.assertFalse(result["control_executed"])


if __name__ == "__main__":
    unittest.main()
