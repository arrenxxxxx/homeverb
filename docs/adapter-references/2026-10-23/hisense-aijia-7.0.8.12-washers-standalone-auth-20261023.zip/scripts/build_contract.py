#!/usr/bin/env python3
"""Generate the static washer contract. No network or Android execution."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ASM = ROOT / "blutter/asm"
AGENT = "jhk_biz_device/src/agent/network_agent.dart"
PARAMS = "jhk_biz_device/src/agent/params/"
LAYOUT = "jhk_biz_layout/domain/api/layout_resources_agent.dart"


def evidence(path, needle):
    target = ASM / path
    for number, line in enumerate(target.read_text().splitlines(), 1):
        if needle in line:
            return {"file": "blutter/asm/" + path, "line": number,
                    "sha256": hashlib.file_digest(target.open("rb"), "sha256").hexdigest()}
    raise ValueError(f"Missing evidence: {path}: {needle}")


def main():
    # Fields describe the logical Dart JSON before native gateway processing.
    # Server-required/optional status is unknown unless a caller proves it.
    specs = [
        ("inventory", "设备首次枚举", AGENT, "getDeviceList", "/iot/devices/list", "device_ota_list_param.dart", ["sourceType", "customerId", "homeId", "partnerId", "categoryCode", "connectionType", "bindStatus", "withState", "whitelist", "withMultiSplit", "comModuleId"], "payload.devices[] / payload.totalCount"),
        ("detail", "已有 ID 的设备详情", AGENT, "getDeviceDetail", "/iot/devices/detail", "device_detail_param.dart", ["sourceType", "customerId", "deviceId", "partnerId"], "payload.device"),
        ("refresh_state", "请求刷新设备状态", AGENT, "postRefreshDeviceState", "/iot/state/refreshDeviceState", "device_refresh_status_param.dart", ["deviceIds", "partnerId", "deviceId"], "payload.status; subsequent device update needed"),
        ("product_functions", "产品功能描述", AGENT, "getDeviceDetailedFunctions", "/iot/devices/function/getByProduct", "device_function_param.dart", ["sourceType", "products"], "payload.products[].functions"),
        ("card_functions", "设备卡片功能配置", AGENT, "getDeviceCardFunctions", "/iot/devices/function/getHomepageConfig", "device_function_param.dart", ["sourceType", "products"], "payload.products[] / preferFunctions"),
        ("mode_list", "程序清单", AGENT, "queryDeviceModeWithFunctions", "/iot/devices/function/getModeList", "device_mode_function_param.dart", ["sourceType", "categoryCode", "productCode", "partnerId", "deviceId"], "payload.modes[]"),
        ("mode_functions", "按程序查询参数", AGENT, "queryDeviceModeFunctionDetail", "/iot/devices/function/getModesFunctions", "device_mode_function_param.dart", ["sourceType", "categoryCode", "productCode", "modeCodes", "partnerId", "deviceId"], "payload.modes[].functions"),
        ("program_memory", "读取记忆参数", AGENT, "queryDeviceParamMemory", "/iot/param/memory/get", "device_get_memory_param.dart", ["sourceType", "customerId", "deviceId", "partnerId"], "DeviceParamMemoryDtoPayload"),
        ("panel_resources", "控制面板资源清单", AGENT, "queryDeviceH5resource", "/iot/layout/controlFile/list", "device_h5_resource_param.dart", ["productCodeList", "sceneCode"], "payload.controlFileList[]: categoryCode/productCode/fileUrl/md5/sha256/id"),
        ("washer_scenes", "洗衣场景程序清单", LAYOUT, "queryWasherSceneList", "/iot/wash/washScene/device/get", "@jhk_biz_layout/domain/dto/device_washer_scene_list_param.dart", ["sourceType", "categoryCode", "productCode", "tubType"], "WasherSceneDtoPayload"),
        ("washer_custom_programs", "读取自定义洗衣程序", LAYOUT, "queryWasherSelfList", "/iot/cloudCache/operationData/query", "@jhk_biz_layout/domain/dto/device_washer_scene_list_param.dart", ["homeId", "customerId", "businessDataTypes", "businessDataDim", "partnerId", "deviceId"], "WasherSelfDtoPayload; businessDataTypes includes washCustomProgram"),
        ("washer_ai_names", "读取智能程序命名", LAYOUT, "getAIProgram", "/iot/state/value/custom/name/get", "@jhk_biz_layout/domain/dto/device_washer_ai_list_param.dart", ["devices"], "WasherAiDtoPayload"),
        ("execute", "设备控制（仅静态）", AGENT, "execute", "/iot/devices/execute", "device_execute_param.dart", ["sourceType", "exclusionFlag", "customerId", "deviceId", "partnerId", "actions"], "DeviceExecuteDtoPayload; not physical completion evidence"),
    ]
    operations = []
    products = ["WV20W-1", "WH120E5S-1"]
    observed_cache = {"detail", "product_functions", "mode_list", "panel_resources"}
    for op_id, title, agent, method, route, params, fields, response in specs:
        params = params[1:] if params.startswith("@") else PARAMS + params
        full_route = "/4.0" + route
        op = {
            "id": op_id, "title": title, "semantics": "write_action" if op_id == "execute" else "read",
            "transport": {"host": "iot-aihome.hismarttv.com", "scheme": "https", "method": "POST", "path": full_route,
                          "native_gateway_processing_required": True, "wire_body_recovered": False},
            "request": {"logical_envelope": "header + payload + public parameters + accessToken",
                        "payload_fields": fields, "server_required_fields_confirmed": False,
                        "parameter_source": params},
            "response": {"business_path": response, "success_rule": "HTTP 200, valid decoded payload, payload.status == SUCCESS, then operation-specific structure"},
            "applicability": {"internal_product_codes": products, "model_capabilities": "models.json",
                              "operation_wire_response_verified": False},
            "verification": {"static_callsite_recovered": True, "app_ui_observed": op_id == "detail",
                             "original_app_cached_data_observed": op_id in observed_cache,
                             "operation_http_response_captured": False,
                             "independent_read_verified": False, "control_executed": False},
            "execution_enabled": False,
            "evidence": [evidence(agent, f" {method}("), evidence(agent, '"https://iot-aihome.hismarttv.com' + full_route + '"')],
        }
        for field in fields:
            op["evidence"].append(evidence(params, '"' + field + '"'))
        if op_id == "inventory":
            op["notes"] = ["List serializer is compiler-deduplicated to JhkOtaDeviceListRequestPayload.toJson; this does not call an OTA API.", "withState=true and withMultiSplit=true in the recovered caller; validate full ID sets and totalCount after login."]
        if op_id == "mode_functions":
            op["notes"] = ["Caller splits modeCodes into batches of at most 5; preserve category/product/partner/device identity."]
        if op_id == "execute":
            op["request"]["additional_top_level_fields"] = ["sourceName"]
            op["notes"] = ["sourceType is stringified in this caller; exclusionFlag is 1. Do not normalize against read payload types without evidence.", "Logical feature codes are resolved through product functions into actual command/params; no control request is authorized or sent."]
        operations.append(op)
    contract = {
        "schema_version": 1, "analysis_date": "2026-10-22", "baseline": "baseline.json",
        "account_authentication": {"contract": "authentication.json", "guide": "AUTHENTICATION.md",
                                   "sms_protocol_source_recovered": True, "independent_sms_login_verified": False,
                                   "native_gateway_signer_equivalence_proven": False},
        "scope": {"category": "washing machines", "user_device_count": 2, "model_identification_complete": False,
                  "internal_product_identification_complete": True, "retail_model_label_confirmed": False,
                  "group": "virtualWholeFamily: upper dual tub + lower washer",
                  "dynamic_authorization": "read_only", "control_executed": False},
        "runtime_evidence": {"models": "models.json", "observations": "runtime/observations.json",
                             "resources": "resources.json", "level": "authenticated original App UI and cached configuration; independent HTTP not verified"},
        "transport_boundary": {
            "channel": "jhk_network", "method": "cloudRequest",
            "native_options": {"method": 1, "contentType": 0, "requestSignType": 1, "responseType": 0, "responseSignType": 1},
            "enum_meanings": {"method_1": "post", "contentType_0": "json", "requestSignType_1": "gateWay", "responseSignType_1": "gateWay"},
            "public_parameter_names": ["deviceId", "appVersion", "appType", "accessToken"],
            "public_parameter_note": "Top-level deviceId is the phone/app identity, distinct from payload.deviceId of the appliance; appType is string 1.",
            "request_header": {"messageId": "UUID v1", "timestamp": "native fill/units unknown", "languageId": "native/default unknown", "payloadVersion": "caller-specific; refresh uses 1.0"},
            "authentication_source": "jhk_account getAuthData: customerId, token, refreshToken, expiry fields; token supplied as accessToken",
            "unresolved": ["Actual gateway HTTP headers, signature input/order/time unit, encryption and response unwrap", "SMS send succeeded but independent token login rejected; refresh and invalid-session recovery remain unverified", "Cache/source freshness and actual appliance sampling time"],
            "evidence": [evidence("jhk_network/jhk_network_method_channel.dart", '"cloudRequest"'), evidence("jhk_network/jhk_network.dart", '"requestSignType"'), evidence("jhk_network/jhk_network.dart", '"appType"'), evidence(AGENT, '"accessToken"'), evidence("jhk_account/jhk_auth_data.dart", '"token"')],
        },
        "operations": operations,
        "execution_policy": {"network_client_created": False, "account_client_created": True,
            "network_client_scope": "This flag refers to the native washer gateway; the separate account client has no washer routes.", "all_operations_disabled": True,
            "reason": "Two internal product/device identities are matched locally, but native gateway signing and independent session handling remain unverified. This is an analysis contract, not a callable cloud adapter."},
        "capability_rules": ["Use categoryCode/productCode/partner/device identifiers and current function config together.", "Mode codes, UI option indices and command parameter values are separate identifiers.", "Preserve remoteControlFlag, child lock, running state, sale/demo mode and restart constraints.", "The upper WV20W-1 is confirmed as left/right tubs; the lower WH120E5S-1 has a separate device identity.", "Statistics fields and fault functions exist in current config; historical/report API results remain unverified."],
    }
    (ROOT / "contract.json").write_text(json.dumps(contract, ensure_ascii=False, indent=2) + "\n")
    print(f"Generated {len(operations)} static operations, all execution disabled")


if __name__ == "__main__":
    main()
