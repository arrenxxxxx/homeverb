# HisenseHA 43c7f17c 源码对照

固定提交：[43c7f17ca7a2eb92ff064f7ac40bc18f04ad56f6](https://github.com/manymuch/HisenseHA/tree/43c7f17ca7a2eb92ff064f7ac40bc18f04ad56f6)。已读取其公开源码，未运行整个第三方项目。来源摘要在 [auth_provenance.json](auth_provenance.json)。

| 环节 | 这个提交如何实现 | 源码 |
| --- | --- | --- |
| 登录界面 | 必填账号和密码；没有短信入口 | [config_flow.py L23–75](https://github.com/manymuch/HisenseHA/blob/43c7f17ca7a2eb92ff064f7ac40bc18f04ad56f6/custom_components/hisense/config_flow.py#L23-L75) |
| 登录请求 | AES 加密 loginName 和 signature（密码）；签名 JSON POST /mobile/se/signon；提取 token、refreshToken、customerId | [pyhisenseapi.py L62–107](https://github.com/manymuch/HisenseHA/blob/43c7f17ca7a2eb92ff064f7ac40bc18f04ad56f6/custom_components/hisense/pyhisenseapi.py#L62-L107) |
| 失效恢复 | refresh() 用保存的账号密码再次 signon；没有调用 refresh_token2 | [L502–526](https://github.com/manymuch/HisenseHA/blob/43c7f17ca7a2eb92ff064f7ac40bc18f04ad56f6/custom_components/hisense/pyhisenseapi.py#L502-L526) |
| 家庭与设备 | POST /4.0/iot/home/list、/4.0/iot/devices/list | [L109–138](https://github.com/manymuch/HisenseHA/blob/43c7f17ca7a2eb92ff064f7ac40bc18f04ad56f6/custom_components/hisense/pyhisenseapi.py#L109-L138) |
| 读取包装 | 顶层 accessToken、系统字段、UUID4 messageId；payload 包含 customerId、sourceType=3；commonweb 正文签名 | [L319–422](https://github.com/manymuch/HisenseHA/blob/43c7f17ca7a2eb92ff064f7ac40bc18f04ad56f6/custom_components/hisense/pyhisenseapi.py#L319-L422) |
| 洗衣机状态 | POST /4.0/iot/devices/detail，读取 states；洗衣机控制与标签写入直接返回 False | [L1038–1067](https://github.com/manymuch/HisenseHA/blob/43c7f17ca7a2eb92ff064f7ac40bc18f04ad56f6/custom_components/hisense/pyhisenseapi.py#L1038-L1067) |

此前参考的 3d02d985 使用旧版设备目录。用户这次提供的提交增加了 AIHome /4.0 读取方式，可用同一公开应用常量签名；这不等于还原了 APK 的原生 gateWay。新客户端限定三个读取路由，并补上响应验签和禁止重定向。

本次独立短信登录、续期和两台洗衣机状态读取已实际成功；短信协议来自官方爱家网页分支，未从 HisenseHA 获取。验收记录见 [independent-auth-validation.json](runtime/independent-auth-validation.json)。

WV20W-1 的状态以 .left/.right 分筒，不能仅用该项目通用解析器中的无后缀 runStatus/workMode 等字段覆盖上分区。本次客户端保留两台设备的原始状态键；读到字段不代表已验证所有状态值含义或能控制设备。
