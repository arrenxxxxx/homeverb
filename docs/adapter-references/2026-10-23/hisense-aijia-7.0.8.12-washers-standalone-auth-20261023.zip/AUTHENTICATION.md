# 新平台登录、续期和洗衣机只读接入

2026-10-23 已用独立生成的终端身份完成短信登录，取得新 token、refreshToken、customerId，读取两台目标洗衣机状态，并完成续期及续期令牌回读。验收链路未复用 App 令牌或终端身份，不依赖 Android 运行。设备控制、设置修改、绑定、预约、诊断启动和 OTA 均未执行。

## 已验证的结果

| 环节 | 实测结果 |
| --- | --- |
| 独立短信登录 | 一条短信、一次验证码提交；验签通过，data.resultCode=0 |
| 独立身份 | 客户端生成持久终端 ID、devSerial，以及每次登录的 sid；与 App 身份不同 |
| 家庭与设备 | 1 个家庭、2 条设备；完整设备 ID、产品代码和序列号与授权快照一致 |
| WV20W-1 | 读取到 124 个状态字段，保留 .left/.right 分筒键 |
| WH120E5S-1 | 读取到 206 个状态字段 |
| 续期 | refresh_token2 成功；续期后的 token 再读家庭列表并验签成功 |
| 离线检查 | 19 项账号检查、6 项 AIHome 读取检查，共 25 项 |

脱敏验收记录：[independent-auth-validation.json](runtime/independent-auth-validation.json)。字段数是本次返回字段数量，不代表独立功能数量或功能覆盖率。云端报告时间可得，但设备采样新鲜度和缓存语义未独立确认，不能把请求成功等同于实时物理状态。

## HisenseHA 的实现与本次方案

用户提供的 [HisenseHA 固定提交 43c7f17c](https://github.com/manymuch/HisenseHA/tree/43c7f17ca7a2eb92ff064f7ac40bc18f04ad56f6) 使用账号和密码调用 /mobile/se/signon；refresh() 实际用保存的账号密码重新登录。该提交没有短信登录实现。详见[源码对照](HISENSEHA-43c7f17c.md)。

该提交新增的 AIHome H5 读取链路提供了可用的 /4.0 包装：顶层 accessToken 和系统字段、header.messageId、payload.customerId/sourceType=3，以及 commonweb 的 X-Sign-For。本次先复用 App 会话只读验证四个请求，随后用独立短信会话验证完整读取，并对每个响应验签。原 APK 的原生 gateWay 桥接算法仍未完整恢复；它与已成功的 H5 读取方式是不同传输实现。

## 新平台的短信登录步骤

1. 客户端独立生成并私密保存终端身份；每次新登录生成 UUID4 hex sid。当前生成结构已在此账号实际成功，目标原生 SDK 的完整实现仍未知。
2. 用户主动获取一条验证码：POST https://portal-account.hismarttv.com/mobile/se/sendauthcode，正文含加密手机号、serverCode=9501、accCategory=newhxaj、sourceType=整数 2。
3. 提交六位验证码到 /mobile/se/loginByAuthCode。正文含加密手机号、原样字符串验证码、sourceType=整数 1、version=7.5、serverCode=9501、accCategory=newhxaj、sid、autoRegist=字符串 1、deviceId、devSerial、deviceType=整数 1。完整契约见 [authentication.json](authentication.json)。
4. 验证原始回包签名，再检查业务码、token、refreshToken、customerId；私密保存会话。
5. 使用 [AIHome 只读客户端](scripts/hisense_aihome_read.py) 枚举家庭、设备，读取两台目标产品的详情和原样 states。设备 ID 与终端 ID 是不同概念。
6. 需要续期时，以表单 POST https://bas-wg.hismarttv.com/aaa/refresh_token2，字段是 refreshToken、appKey=1234567890、format=1。保留 customerId；有新 refreshToken 时替换。此流程已实测，长期有效期、过期错误码及自动失效恢复仍未验收。

官方爱家短信分支包含 autoRegist=1，可能允许注册账号。客户端要求调用者明确选择 --allow-registration 或 API 参数 allow_registration=True，不会隐式启用。当前两次动态验证均获得用户逐次授权。

## 签名与加密要点

请求正文使用保序紧凑 JSON、UTF-8。X-Sign-For 是原样正文追加公开应用 secret 后的 MD5 **16 字节原始摘要**再 Base64。手机号使用 AES-256-CBC / PKCS7 / Base64；key 是 secret 的 ASCII 字节，IV 是其前 **16** 个字符的 ASCII 字节。常量见 [portal_constants.py](scripts/portal_constants.py)，不是用户密码或令牌。

响应必须按 UTF-8 解码，先保留原文，再按官网纯辅助函数的行为移除**最后一个匹配**的逗号加 signatureServer 字段，保留嵌套签名，然后计算同一摘要并常量时间比较。此次成功登录回包确有两个 signatureServer，旧版“移除第一个”的算法会拒绝这个真实成功回包。UTF-8 与嵌套签名均有离线回归检查。

此前通用 H5 分支的 TypeError: Cipher data must be a string or a buffer 和 09:17 UTC 未留原文的验签失败属于历史失败，保留在账号契约中。不能还原已丢失的前次原文；本次成功回包明确复现旧验签缺陷，修正后完整链路已通过。

## 本地使用

依赖 Python、requests、cryptography。在解压后的包根目录执行：

```sh
python3 scripts/hisense_account.py sms-login --allow-registration
python3 scripts/hisense_aihome_read.py
python3 scripts/hisense_account.py refresh
```

手机号、验证码在本机终端隐藏输入，不放命令参数。sms-login 一次发码、一次提交，不自动重试。已收验证码但尚未提交时可用 sms-complete --allow-registration，不会另发短信。所有命令支持 --private-dir 指定独立私有目录。账号客户端的旧 devices 命令仅保留旧目录兼容用途；读取当前洗衣机使用 hisense_aihome_read.py。

平台代码可以调用 standalone_terminal()、HisenseAccount.send_sms()、HisenseAccount.login_sms(..., terminal_identity=..., sid=..., allow_registration=True)，再调用 HisenseAccount.refresh()、HisenseAIHomeRead 和 read_washers()。会话结构含 access_token、refresh_token、customer_id；手机号和验证码由平台登录界面传入，不需要原 App 参与。

客户端只包含固定账号操作及三个 H5 读取路由，不提供控制透传或任意 URL。禁用环境代理继承和重定向，启用 TLS 证书校验及响应验签。结果仅写入 0700 目录中的 0600 文件；分享包排除全部令牌、原始回包、手机号、完整 ID/SN 和终端身份。

密码登录源代码可供参考，但本次用户只使用短信，未实测密码登录。完整原生 gateWay、控制、逐程序详情、历史统计、设备采样时效及长期令牌失效恢复不在本次成功验收结论中。[contract.json](contract.json) 的 13 项仍是禁用的原生静态候选；三个已验收 H5 只读路由单独记录在 [authentication.json](authentication.json)。
