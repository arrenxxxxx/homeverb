# 六台设备接入接口契约（静态证据版）

目标：六台设备在美居控制页中的全部功能，含高级功能、统计与告警；不含商城、社区和无关售后业务。

**本文件是已定位入口与参数证据，不是已打通的客户端，也不能作为完整型号能力表。当前没有登录、没有发送业务查询或设备命令。**

离线扫描核对了 871 处 HTTP 声明：美的命名空间有 826 处固定注解（696 个去重 method+route）、26 处 @Url 动态声明、1 处常量表达式声明。另有 4,124 处路由字符串候选和 443 处桥接注解声明；这些数量都不代表设备功能数。

最初扫描把两个 @GET("") + @Url 误算为固定空路径，并把常量注解混入动态 URL。现已区分并核对源码位置，原 826 条记录全部保留。

本契约精选 67 个接入相关操作。每个都包含源码锚点、参数已知部分、读写语义、响应类型和未验证标记；其他静态接口保留在完整索引中。

## 使用边界

`read_candidate` 是经静态调用链识别的读取候选，不是已授权执行的自动白名单。未知正文、自定义 query、透传 order 和插件通用云请求均不自动放行。`write` 仅登记，当前禁止调用。登录单列为 authentication，SSE 单列为带会话副作用的订阅。

默认生产代理是 `https://mp-prod.smartmidea.net/mas/v5/app/proxy?alias=`，但需要从正常账号会话确认区域与实际 host。大整数设备 ID 在聚合平台内保存为字符串；接口要求数值时应使用无精度损失的序列化。

JSON 里的 DTO 字段只表明 Java 定义，不能推导必填、默认值、序列化别名或具体设备支持。`body_not_traced` 明确表示尚未追到正文，不提供猜测请求示例。

## 账号与鉴权

### login_id · 登录 ID

`POST /v1/user/login/id/get` · `authentication` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `loginAccount` | 账号 |

登录过程可建立会话；不是普通业务只读查询。

证据：[LoginApi.java:23](jadx/sources/com/midea/business/login/api/LoginApi.java#L23)；[LoginApiService.java:101](jadx/sources/com/midea/business/login/api/LoginApiService.java#L101)。

### password_login · 密码登录

`POST /v6/mj/user/login` · `authentication` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `data` | MucData 上下文 |
| `iotData` | IotData 密码登录分支 |
| `timestamp` | CommonReqData 时间 |

这里只枚举 DTO；不能把全部 IotData 字段作为密码登录必填。哈希输入、生产配置和完整请求头尚未闭合。

证据：[LoginApi.java:50](jadx/sources/com/midea/business/login/api/LoginApi.java#L50)；[LoginApiService.java:140](jadx/sources/com/midea/business/login/api/LoginApiService.java#L140)。

### auto_login · 会话续期

`POST /mj/user/autoLogin` · `authentication` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `userId` | 请求头 |
| `body` | 正常登录产生的 tokenPwd 及上下文；尚未闭合 |

不能等同于通用 Bearer refresh token 流程。

证据：[TokenApiService.java:15](jadx/sources/com/midea/business/login/token/TokenApiService.java#L15)。

## 目录与身份

### home_list · 家庭列表

`POST /v2/homegroup/list/get` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `devicePermissions` | boolean；默认构造为 true |
| `lampSwitch` | Boolean，可空 |
| `onlyDefault` | Boolean，可空 |

全量目录不能仅查询默认家庭；DTO 可空字段的序列化仍需读回。

证据：[HomeApiService.java:41](jadx/sources/com/midea/business/datacenter/api/HomeApiService.java#L41)；[HomeInfoService.java:1387](jadx/sources/com/midea/business/datacenter/service/HomeInfoService.java#L1387)；[HomeGroupListReq.java:117](jadx/sources/com/midea/business/datacenter/bean/req/HomeGroupListReq.java#L117)。

### home_aggregate · 单家庭聚合目录

`POST /v1/homegroup/aggregate/get` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `homegroupId` | 家庭 ID |

证据：[HomeApiService.java:38](jadx/sources/com/midea/business/datacenter/api/HomeApiService.java#L38)；[HomeInfoService.java:527](jadx/sources/com/midea/business/datacenter/service/HomeInfoService.java#L527)。

### home_cards · 首页卡片与设备目录

`POST /v1/appliance/home/list/aggregate` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `cardType` | CardType[] |

卡片目录不保证等于全部设备；需要与每个家庭的 applianceList 对照。

证据：[HomeApiService.java:59](jadx/sources/com/midea/business/datacenter/api/HomeApiService.java#L59)；[HomeInfoService.java:575](jadx/sources/com/midea/business/datacenter/service/HomeInfoService.java#L575)。

### home_devices · 家庭设备列表

`POST /v1/appliance/home/list/get` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `homegroupId` | 数值家庭 ID（该调用直接拼接） |
| `uiTemplate` | "1" |
| `compose` | true |
| `permission` | "1" |

证据：[HomeApiService.java:62](jadx/sources/com/midea/business/datacenter/api/HomeApiService.java#L62)；[HomeInfoService.java:981](jadx/sources/com/midea/business/datacenter/service/HomeInfoService.java#L981)。

### home_members · 家庭成员与共享上下文

`POST /v1/homegroup/member/get` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `homegroupId` | 数值家庭 ID（该调用直接拼接） |
| `devicePermissions` | true |

证据：[HomeApiService.java:44](jadx/sources/com/midea/business/datacenter/api/HomeApiService.java#L44)；[HomeInfoService.java:1647](jadx/sources/com/midea/business/datacenter/service/HomeInfoService.java#L1647)。

### devices_by_ids · 按设备 ID 回读身份

`POST /v1/appliance/info/bind/batch` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `applianceCodes` | JSON 数值数组；本调用链直接拼接数字 ID |

路径中有 bind，调用链是查询已有设备；不能仅凭 URL 关键词分类。大整数应避免 JS Number 精度损失。

证据：[DeviceInfoApiService.java:47](jadx/sources/com/midea/business/datacenter/api/DeviceInfoApiService.java#L47)；[DeviceInfoService.java:823](jadx/sources/com/midea/business/datacenter/service/DeviceInfoService.java#L823)；[DeviceInfoService.java:834](jadx/sources/com/midea/business/datacenter/service/DeviceInfoService.java#L834)。

### batch_device_info · 批量设备元数据

`POST /v1/appliance/batch/info/get` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `applianceCodes` | 单个 ID 或由 - 分隔的字符串 |

证据：[DeviceInfoApiService.java:50](jadx/sources/com/midea/business/datacenter/api/DeviceInfoApiService.java#L50)；[DeviceInfoService.java:1838](jadx/sources/com/midea/business/datacenter/service/DeviceInfoService.java#L1838)；[DeviceInfoService.java:1845](jadx/sources/com/midea/business/datacenter/service/DeviceInfoService.java#L1845)。

### device_auth_status · 设备授权状态

`POST /v1/appliance/auth/batch/get` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `applianceCodeList` | 设备 ID 字符串数组；源码会跳过 GSM 分支 |

证据：[DeviceInfoApiService.java:35](jadx/sources/com/midea/business/datacenter/api/DeviceInfoApiService.java#L35)；[DeviceInfoService.java:1462](jadx/sources/com/midea/business/datacenter/service/DeviceInfoService.java#L1462)。

## 状态读取

### device_status_list · 批量状态摘要

`POST /v1/appliance/batch/getStatus` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `applianceCodes` | 设备 ID 字符串数组；区别于 devices_by_ids 的数值数组 |

证据：[DeviceInfoApiService.java:41](jadx/sources/com/midea/business/datacenter/api/DeviceInfoApiService.java#L41)；[DeviceInfoService.java:1407](jadx/sources/com/midea/business/datacenter/service/DeviceInfoService.java#L1407)。

### status_aggregator · 净水/网关等状态聚合器

`POST /api/v1/aggregator/appliances` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `homegroupId` | 设备所属家庭 |
| `appliances` | [{id,type,sn8,modelNumber,order,smartProductId}] |
| `entities` | ["endlist","tips"]（已读调用点） |

已读调用仅选择净水、子设备、网关/蓝牙网关分支，并排除 smartTy；网关分支还会填 order。不能当作用户六台的统一状态入口，服务端是否另支持其余品类未知。

证据：[DeviceStatusApiService.java:20](jadx/sources/com/midea/business/datacenter/api/DeviceStatusApiService.java#L20)；[DeviceStateService.java:215](jadx/sources/com/midea/business/datacenter/service/DeviceStateService.java#L215)；[DeviceStateService.java:225](jadx/sources/com/midea/business/datacenter/service/DeviceStateService.java#L225)；[DeviceStatusUtils.java:106](jadx/sources/com/midea/business/datacenter/util/DeviceStatusUtils.java#L106)；[GateWayStateHelper.java:67](jadx/sources/com/midea/business/datacenter/util/GateWayStateHelper.java#L67)。

### lua_status_json · 服务端 Lua 状态查询

`POST /v1/device/status/lua/get` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `applianceCode` | 设备 ID |
| `command` | {"query":{...型号查询字段...}}；空参数时 command 为 {} |
| `caller` | 由面板上下文填写 meiju-plugin-lowcode 或 meiju-plugin-tradition |

query 内部字段依赖型号资源；此路径与原始 transparent/send 透传分开。仍须确认响应时效、云缓存/设备回源及服务端行为。

证据：[DeviceAPI.java:21](jadx/sources/com/midea/hybrid/api/meiju/bridge/api/DeviceAPI.java#L21)；[DefaultBridgeDeviceImpl.java:223](jadx/sources/com/midea/hybrid/api/meiju/bridge/impl/DefaultBridgeDeviceImpl.java#L223)；[DefaultBridgeDeviceImpl.java:251](jadx/sources/com/midea/hybrid/api/meiju/bridge/impl/DefaultBridgeDeviceImpl.java#L251)。

## 模板与面板资源

### tsl_templates · 设备 UI/数据模板

`POST /v1/appliance/thing/template/get` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `uiTemplateIds` | Long[]，来自真实设备模板标识 |

响应包含 templateList；单项有 uiTemplateId、dataTemplate、jsTemplate、uiTemplate、urlTemplate、zipMd5 等。不是仅凭此路由就取得完整物模型。

证据：[NewTSLTemplateApiService.java:21](jadx/sources/com/midea/business/datacenter/api/NewTSLTemplateApiService.java#L21)；[NewTSLTemplate.java:30](jadx/sources/com/midea/base/common/bean/tsl/NewTSLTemplate.java#L30)。

### composite_property_codes · 复合卡片模块属性配置

`POST /v1/appliance/composite/card/config/get` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `filterCustomType` | false（已读调用点） |

证据：[NewTSLTemplateApiService.java:27](jadx/sources/com/midea/business/datacenter/api/NewTSLTemplateApiService.java#L27)；[NewTSLTemplateService.java:744](jadx/sources/com/midea/business/datacenter/service/NewTSLTemplateService.java#L744)。

### update_tsl_card · 更新 TSL 卡片配置

`POST /v1/appliance/thing/card/update` · `write` · `mas_proxy`

请求结构状态：`body_not_traced`。

证据：[NewTSLTemplateApiService.java:30](jadx/sources/com/midea/business/datacenter/api/NewTSLTemplateApiService.java#L30)。

### plugin_v3 · 设备面板插件 V3

`POST /v1/plugin/update/getPluginV3` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `iotAppId` | "900" |
| `clientType` | "1" |
| `match` | "1" |
| `clientVersion` | 201 |
| `applianceList` | JSON 数组再次序列化成字符串；不是直接数组 |

applianceList 每项：appType、appModel、applianceCode、modelNumber、versionCode（数值）、appEnterprise、smartProductId。响应先为 ResponseBody，再由服务解析。应保留 url/fileMD5/versionCode/差分包信息。

证据：[PluginDownloadInfoApiService.java:17](jadx/sources/com/midea/business/plugin/api/PluginDownloadInfoApiService.java#L17)；[PluginDownloadInfoServiceImp.java:951](jadx/sources/com/midea/business/plugin/service/PluginDownloadInfoServiceImp.java#L951)；[PluginDownloadInfoServiceImp.java:1098](jadx/sources/com/midea/business/plugin/service/PluginDownloadInfoServiceImp.java#L1098)；[PluginDownloadInfoRep.java:52](jadx/sources/com/midea/base/common/bean/PluginDownloadInfoRep.java#L52)。

### plugin_legacy · 设备插件旧入口

`POST /v1/plugin/update/getplugin` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `iotAppId` | "900" |
| `clientType` | "1" |
| `match` | "1" |
| `clientVersion` | 201 |
| `applianceList` | JSON 数组再次序列化成字符串；不是直接数组 |

旧分支序列化 IPluginInfoReq；不能把 V3 数字版 versionCode 无条件套用到旧分支。

证据：[PluginDownloadInfoApiService.java:26](jadx/sources/com/midea/business/plugin/api/PluginDownloadInfoApiService.java#L26)；[PluginDownloadInfoServiceImp.java:892](jadx/sources/com/midea/business/plugin/service/PluginDownloadInfoServiceImp.java#L892)。

### plugin_model_login · 登录态模块插件

`POST /v1/plugin/update/getLoginModelPlugin` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `modelList` | String[] 模块编号，不是销售型号清单 |
| `iotAppId` | "900" |
| `clientType` | "1" |
| `clientVersion` | 201 |
| `reqId` | 调用点以当前毫秒字符串设置 |
| `stamp` | yyyyMMddHHmmss |
| `phoneNumber` | 当前用户手机号经会话 dataKey 加密 |

按登录状态选择入口；返回 modelNo/moduleCode/url/md5/appVersion/pluginType 等。minix 另有同路由声明。

证据：[PluginDownloadInfoApiService.java:20](jadx/sources/com/midea/business/plugin/api/PluginDownloadInfoApiService.java#L20)；[PluginDownloadInfoServiceImp.java:845](jadx/sources/com/midea/business/plugin/service/PluginDownloadInfoServiceImp.java#L845)；[PluginDownloadInfoServiceImp.java:854](jadx/sources/com/midea/business/plugin/service/PluginDownloadInfoServiceImp.java#L854)。

### plugin_model · 模块插件

`POST /v1/plugin/update/getModelPlugin` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `modelList` | String[] 模块编号，不是销售型号清单 |
| `iotAppId` | "900" |
| `clientType` | "1" |
| `clientVersion` | 201 |
| `reqId` | 调用点以当前毫秒字符串设置 |
| `stamp` | yyyyMMddHHmmss |
| `phoneNumber` | 当前用户手机号经会话 dataKey 加密 |

按登录状态选择入口；返回 modelNo/moduleCode/url/md5/appVersion/pluginType 等。minix 另有同路由声明。

证据：[PluginDownloadInfoApiService.java:23](jadx/sources/com/midea/business/plugin/api/PluginDownloadInfoApiService.java#L23)；[PluginDownloadInfoServiceImp.java:845](jadx/sources/com/midea/business/plugin/service/PluginDownloadInfoServiceImp.java#L845)；[PluginDownloadInfoServiceImp.java:854](jadx/sources/com/midea/business/plugin/service/PluginDownloadInfoServiceImp.java#L854)。

### virtual_plugins · 虚拟插件目录

`POST /v1/plugin/virtualplugin/get` · `read_candidate` · `mas_proxy`

请求结构状态：`no_explicit_body_in_declaration`。

证据：[PluginDownloadInfoApiService.java:29](jadx/sources/com/midea/business/plugin/api/PluginDownloadInfoApiService.java#L29)。

## 物模型读写与动作

### tsl_all · 单设备全部属性

`GET /v1/thing/properties/{applianceCode}` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `path.applianceCode` | 设备 ID |
| `query` | requestId、sync，以及型号桥接 query |

通过 MAS proxy；请求头 caller=900、call-source=mideaApp，可选 call-module。sync 在线上 URL 为 true/false，桥接输入默认整数 1。自定义 query 会透传，不能无条件放行。

证据：[TSLModelService.java:748](jadx/sources/com/midea/business/datacenter/service/TSLModelService.java#L748)；[TSLModelService.java:258](jadx/sources/com/midea/business/datacenter/service/TSLModelService.java#L258)；[DefaultBridgeTSLV2Impl.java:94](jadx/sources/com/midea/hybrid/api/meiju/bridge/impl/DefaultBridgeTSLV2Impl.java#L94)。

### tsl_selected · 单设备指定属性

`POST /v1/thing/properties/{applianceCode}` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `body` | JsonArray；属性代码元素结构由实际模板/插件决定 |
| `query` | requestId、sync，以及型号 query |

通过 MAS proxy；请求头 caller=900、call-source=mideaApp，可选 call-module。sync 在线上 URL 为 true/false，桥接输入默认整数 1。自定义 query 会透传，不能无条件放行。

证据：[TSLModelService.java:704](jadx/sources/com/midea/business/datacenter/service/TSLModelService.java#L704)；[TSLModelService.java:258](jadx/sources/com/midea/business/datacenter/service/TSLModelService.java#L258)；[DefaultBridgeTSLV2Impl.java:94](jadx/sources/com/midea/hybrid/api/meiju/bridge/impl/DefaultBridgeTSLV2Impl.java#L94)。

### tsl_batch_selected · 批量指定属性

`POST /v1/thing/batch/properties` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `body` | DeviceProperty[]：{applianceCode,props,disablePropIntegrityCheck:false}；桥接输入 properties 被转换成服务端正文 props |
| `query` | requestId、sync，以及型号 query |

通过 MAS proxy；请求头 caller=900、call-source=mideaApp，可选 call-module。sync 在线上 URL 为 true/false，桥接输入默认整数 1。自定义 query 会透传，不能无条件放行。

证据：[TSLModelService.java:690](jadx/sources/com/midea/business/datacenter/service/TSLModelService.java#L690)；[TSLModelService.java:258](jadx/sources/com/midea/business/datacenter/service/TSLModelService.java#L258)；[DefaultBridgeTSLV2Impl.java:94](jadx/sources/com/midea/hybrid/api/meiju/bridge/impl/DefaultBridgeTSLV2Impl.java#L94)；[DefaultBridgeTSLV2Impl.java:605](jadx/sources/com/midea/hybrid/api/meiju/bridge/impl/DefaultBridgeTSLV2Impl.java#L605)；[DefaultBridgeTSLV2Impl.java:502](jadx/sources/com/midea/hybrid/api/meiju/bridge/impl/DefaultBridgeTSLV2Impl.java#L502)。

### tsl_batch_all · 批量全部属性

`GET /v1/thing/batch/properties` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `query.applianceCodes` | 逗号分隔 ID |
| `query.requestId` | UUID |
| `query.sync` | 布尔，默认 true |
| `query.disablePropLegalityCheck` | 原调用填写 true，含义与必要性待验证 |

通过 MAS proxy；请求头 caller=900、call-source=mideaApp，可选 call-module。sync 在线上 URL 为 true/false，桥接输入默认整数 1。自定义 query 会透传，不能无条件放行。

证据：[TSLModelService.java:1403](jadx/sources/com/midea/business/datacenter/service/TSLModelService.java#L1403)；[TSLModelService.java:258](jadx/sources/com/midea/business/datacenter/service/TSLModelService.java#L258)；[DefaultBridgeTSLV2Impl.java:94](jadx/sources/com/midea/hybrid/api/meiju/bridge/impl/DefaultBridgeTSLV2Impl.java#L94)。

### tsl_set · 写属性

`PUT /v1/thing/properties/{applianceCode}` · `write` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `body` | JsonObject；模块/属性和值待型号资源确认 |
| `query` | requestId、sync、custom params |

记录接口，当前禁止执行。

证据：[TSLModelService.java:887](jadx/sources/com/midea/business/datacenter/service/TSLModelService.java#L887)；[DefaultBridgeTSLV2Impl.java:433](jadx/sources/com/midea/hybrid/api/meiju/bridge/impl/DefaultBridgeTSLV2Impl.java#L433)。

### tsl_action · 执行高级动作

`POST /v1/thing/action/{moduleCode}/{actionCode}/{applianceCode}` · `write` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `moduleCode` | 模板/插件模块代码 |
| `actionCode` | 动作代码 |
| `body` | JsonObject 动作参数 |
| `query` | requestId、sync、custom params |

高级功能可能通过 action 或写属性实现；具体功能与 wire 字段尚未确定。

证据：[TSLModelService.java:394](jadx/sources/com/midea/business/datacenter/service/TSLModelService.java#L394)；[DefaultBridgeTSLV2Impl.java:187](jadx/sources/com/midea/hybrid/api/meiju/bridge/impl/DefaultBridgeTSLV2Impl.java#L187)。

### tsl_custom_action · 自定义动作 URL

`POST {fullUrl}{applianceCode}` · `mixed_or_unknown` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `fullUrl` | 调用方传入路径 |
| `body` | 调用方 body |

开放路径，不可列为只读允许入口。

证据：[TSLModelService.java:493](jadx/sources/com/midea/business/datacenter/service/TSLModelService.java#L493)。

## 统计、历史与定时

### tsl_history · TSL 事件/属性历史

`POST /v1/thing/batch/history` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `body` | TslDataHistoryRequest[] |
| `item.applianceCode` | long |
| `item.queryType` | 来自 unreadPropertyCodes；event 分支明确存在 |
| `item.fields` | 来自 unreadProperty；可为空字符串 |
| `item.page` | 默认 1 |
| `item.size` | 默认 1 |
| `item.startTime` | 默认由 time lazy 值提供 |
| `query.requestId` | UUID |

此调用用于未读属性/事件历史，不是已证明的六台设备能耗/用水曲线接口。原代码用 &requestId=；与属性路由使用 ?requestId= 的写法不同，需保留并验证。

证据：[NewTSLTemplateUnreadServiceImpl.java:114](jadx/sources/com/midea/business/datacenter/service/NewTSLTemplateUnreadServiceImpl.java#L114)；[NewTSLTemplateUnreadServiceImpl.java:74](jadx/sources/com/midea/business/datacenter/service/NewTSLTemplateUnreadServiceImpl.java#L74)。

### house_summary · 全屋汇总看板

`POST /v1/home/summary` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `homeGroupId` | int（注意大小写） |
| `reqId` | DTO 请求 ID |
| `stamp` | DTO 时间 |

全屋看板含统计相关模型，不足以证明六台都有电量或水量明细。EMS 光伏/电网/储能组件不能充当空调电表接口。

证据：[HouseDashboardApi.java:14](jadx/sources/com/midea/business/home/house/data/HouseDashboardApi.java#L14)；[HouseDashboardDataSource.java:1177](jadx/sources/com/midea/business/home/house/data/HouseDashboardDataSource.java#L1177)。

### house_summary_config · 全屋看板配置查询

`POST /v1/home/summary/config/query` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `homeGroupId` | 家庭 ID；注意与 homegroupId 的大小写区别 |

证据：[HouseApi.java:14](jadx/sources/com/midea/business/home/house/data/HouseApi.java#L14)；[GroupManagementPresent.java:237](jadx/sources/com/midea/business/home/ui/compositecard/GroupManagementPresent.java#L237)。

### house_summary_save · 全屋看板配置保存

`POST /v1/home/summary/config/save` · `write` · `mas_proxy`

请求结构状态：`body_not_traced`。

证据：[HouseApi.java:17](jadx/sources/com/midea/business/home/house/data/HouseApi.java#L17)。

### timer_list · 设备定时列表

`GET /v1/scene/pluginpage/timer/list` · `read_candidate` · `mas_proxy`

请求结构状态：`caller_supplied_object_not_traced`。

包内通用场景 JS 的请求包装函数证据；不是已下载的六台型号面板。定时创建/修改需继续追踪对应插件，不能把删除/开关当作完整定时协议。

证据：[NFC-exe-scene.js:3](extracted/assets/assetsWeex/midea-rooms/NFC/NFC-exe-scene.js#L3)。

### timer_batch_list · 批量定时列表

`POST /v1/scene/pluginpage/timer/batch/list` · `read_candidate` · `mas_proxy`

请求结构状态：`caller_supplied_object_not_traced`。

包内通用场景 JS 的请求包装函数证据；不是已下载的六台型号面板。定时创建/修改需继续追踪对应插件，不能把删除/开关当作完整定时协议。

证据：[NFC-exe-scene.js:3](extracted/assets/assetsWeex/midea-rooms/NFC/NFC-exe-scene.js#L3)。

### timer_delete · 删除定时

`POST /v1/scene/pluginpage/timer/batch/deletion` · `write` · `mas_proxy`

请求结构状态：`caller_supplied_object_not_traced`。

包内通用场景 JS 的请求包装函数证据；不是已下载的六台型号面板。定时创建/修改需继续追踪对应插件，不能把删除/开关当作完整定时协议。

证据：[NFC-exe-scene.js:3](extracted/assets/assetsWeex/midea-rooms/NFC/NFC-exe-scene.js#L3)。

### timer_switch · 开关定时

`POST /v1/scene/pluginpage/timer/switch` · `write` · `mas_proxy`

请求结构状态：`caller_supplied_object_not_traced`。

包内通用场景 JS 的请求包装函数证据；不是已下载的六台型号面板。定时创建/修改需继续追踪对应插件，不能把删除/开关当作完整定时协议。

证据：[NFC-exe-scene.js:3](extracted/assets/assetsWeex/midea-rooms/NFC/NFC-exe-scene.js#L3)。

### timer_results · 定时执行结果

`POST /v1/scene/pluginpage/timer/actionresult/list` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `reqId` | HttpUtil.getReqId() |
| `stamp` | HttpUtil.getTimestamp() |
| `homegroupId` | 指定或当前家庭 |
| `startNum` | pageNum * 10 |
| `num` | 10 |

证据：[SceneMsgApi.java:33](jadx/sources/com/midea/meiju/messagecenter/api/SceneMsgApi.java#L33)；[MessageApiService.java:490](jadx/sources/com/midea/meiju/messagecenter/api/MessageApiService.java#L490)。

### timer_results_delete · 删除定时执行结果

`POST /v1/scene/pluginpage/timer/delete/actionresult` · `write` · `mas_proxy`

请求结构状态：`body_not_traced`。

证据：[SceneMsgApi.java:24](jadx/sources/com/midea/meiju/messagecenter/api/SceneMsgApi.java#L24)。

## 告警与消息

### message_categories · 消息分类列表

`POST /mc/v6/app/messagecenter/assemble/list` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `isNewVersion` | 60101 |
| `iotLogVersion` | "v2" |

证据：[MessageCenterApi.java:27](jadx/sources/com/midea/meiju/messagecenter/api/MessageCenterApi.java#L27)；[MessageApiService.java:85](jadx/sources/com/midea/meiju/messagecenter/api/MessageApiService.java#L85)。

### home_messages · 家庭设备消息

`POST /mc/v6/app/messagecenter/getHomeMsgList` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `homegroupId` | 家庭 ID |
| `pageNum` | 调用方页码 |
| `pageSize` | 20 |

证据：[MessageCenterApi.java:30](jadx/sources/com/midea/meiju/messagecenter/api/MessageCenterApi.java#L30)；[MessageApiService.java:113](jadx/sources/com/midea/meiju/messagecenter/api/MessageApiService.java#L113)。

### category_messages · 分类消息分页

`POST /mc/v6/app/messagecenter/msgList` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `from` | 分类标识 |
| `pageNum` | 调用方页码 |
| `pageSize` | 20 |

证据：[MessageCenterApi.java:42](jadx/sources/com/midea/meiju/messagecenter/api/MessageCenterApi.java#L42)；[MessageApiService.java:105](jadx/sources/com/midea/meiju/messagecenter/api/MessageApiService.java#L105)。

### message_detail · 消息详情

`POST /mc/v6/app/messagecenter/getDetail` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `messageId` | 消息 ID |

App 另有显式已读接口；服务端是否存在附带副作用仍待正常响应核对，当前未调用。

证据：[MessageCenterApi.java:39](jadx/sources/com/midea/meiju/messagecenter/api/MessageCenterApi.java#L39)；[MessageApiService.java:312](jadx/sources/com/midea/meiju/messagecenter/api/MessageApiService.java#L312)。

### message_unread · 未读计数

`POST /mc/v6/app/messagecenter/assemble/totalUnread` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `from` | "" |
| `isNewVersion` | 60101 |

证据：[MessageCenterApi.java:48](jadx/sources/com/midea/meiju/messagecenter/api/MessageCenterApi.java#L48)；[MessageApiService.java:127](jadx/sources/com/midea/meiju/messagecenter/api/MessageApiService.java#L127)。

### message_status · 消息状态查询

`POST /mc/v6/app/messagecenter/getMessageStatus` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `messageId` | 消息 ID |

证据：[MessageCenterApi.java:45](jadx/sources/com/midea/meiju/messagecenter/api/MessageCenterApi.java#L45)；[MessageDetail.java:288](jadx/sources/com/midea/meiju/messagecenter/detail/MessageDetail.java#L288)。

### message_important · 重要消息列表

`POST /mc/v6/app/messagecenter/scale/msg` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `scale` | 1 |
| `unread` | true |
| `pageSize` | 20 |
| `pageNum` | 1 |

证据：[MessageCenterApi.java:33](jadx/sources/com/midea/meiju/messagecenter/api/MessageCenterApi.java#L33)；[UCenterMessageImpl.java:192](jadx/sources/com/midea/meiju/messagecenter/api/UCenterMessageImpl.java#L192)。

### message_read · 标记已读

`POST /mc/v6/app/messagecenter/setMessageReaded` · `write` · `mas_proxy`

请求结构状态：`body_not_traced`。

只登记，禁止在只读验证中执行。

证据：[MessageCenterApi.java:54](jadx/sources/com/midea/meiju/messagecenter/api/MessageCenterApi.java#L54)。

### message_status_set · 修改消息状态

`POST /mc/v6/app/messagecenter/setMessageStatus` · `write` · `mas_proxy`

请求结构状态：`body_not_traced`。

只登记，禁止在只读验证中执行。

证据：[MessageCenterApi.java:57](jadx/sources/com/midea/meiju/messagecenter/api/MessageCenterApi.java#L57)。

### message_delete · 删除消息

`POST /mc/v6/app/messagecenter/delete` · `write` · `mas_proxy`

请求结构状态：`body_not_traced`。

只登记，禁止在只读验证中执行。

证据：[MessageCenterApi.java:24](jadx/sources/com/midea/meiju/messagecenter/api/MessageCenterApi.java#L24)。

### message_home_delete · 删除家庭消息

`POST /mc/v6/app/messagecenter/deleteByHome` · `write` · `mas_proxy`

请求结构状态：`body_not_traced`。

只登记，禁止在只读验证中执行。

证据：[MessageCenterApi.java:21](jadx/sources/com/midea/meiju/messagecenter/api/MessageCenterApi.java#L21)。

### message_category_delete · 分类清理/已读

`POST /mc/v6/app/messagecenter/assemble/delete` · `write` · `mas_proxy`

请求结构状态：`body_not_traced`。

只登记，禁止在只读验证中执行。

证据：[MessageCenterApi.java:51](jadx/sources/com/midea/meiju/messagecenter/api/MessageCenterApi.java#L51)。

### device_messages_v2 · 新版单设备消息

`POST /mc/v6/app/messagecenter/appliance/list` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `pageNum` | 页码 |
| `pageSize` | 页大小 |
| `applianceCode` | 设备 ID |
| `reminderTypes` | Integer，可空 |
| `appKey` | 该调用使用内置消息应用标识 |
| `from` | 消息来源 |

证据：[MessageCenterNewApi.java:20](jadx/sources/com/midea/meiju/messagecenter/api/MessageCenterNewApi.java#L20)；[MessageCenterDataSource.java:284](jadx/sources/com/midea/meiju/messagecenter/data/MessageCenterDataSource.java#L284)。

### messages_v2 · 新版消息列表

`POST /mc/v6/app/messagecenter/newList` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `pageNum` | 页码 |
| `pageSize` | 页大小 |
| `homeGroupId` | 家庭 ID |
| `messageType` | Integer，可空 |
| `readFlag` | Integer，可空 |
| `appKey` | DTO 默认；不是登录生产密钥 |

证据：[MessageCenterNewApi.java:23](jadx/sources/com/midea/meiju/messagecenter/api/MessageCenterNewApi.java#L23)；[MessageCenterDataSource.java:136](jadx/sources/com/midea/meiju/messagecenter/data/MessageCenterDataSource.java#L136)。

### message_update_v2 · 新版消息状态更新

`POST /mc/v6/app/messagecenter/updateMessageStatus` · `write` · `mas_proxy`

请求结构状态：`body_not_traced`。

证据：[MessageCenterNewApi.java:26](jadx/sources/com/midea/meiju/messagecenter/api/MessageCenterNewApi.java#L26)。

### mute_get · 告警免打扰配置查询

`POST /mc/v6/app/messagecenter/getMute` · `read_candidate` · `mas_proxy`

请求结构状态：`no_explicit_body_in_declaration`。

证据：[MessageMuteApi.java:14](jadx/sources/com/midea/meiju/messagecenter/settings/data/MessageMuteApi.java#L14)。

### mute_set · 告警免打扰配置修改

`POST /mc/v6/app/messagecenter/setMute` · `write` · `mas_proxy`

请求结构状态：`body_not_traced`。

证据：[MessageMuteApi.java:17](jadx/sources/com/midea/meiju/messagecenter/settings/data/MessageMuteApi.java#L17)。

## 旧协议资源与透传

### lua_resource · Lua 协议资源查询

`POST v1/appliance/protocol/lua/luaGet` · `read_candidate` · `msmart_wrapper_workmode_dependent`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `iotAppId` | SDK 配置 |
| `applianceMFCode` | 厂商代码 |
| `applianceType` | 0x + 品类代码 |
| `modelNumber` | 设备内部子型号 |
| `applianceSn` | SN；海外分支先加密 |
| `version` | 当前 Lua 版本 |
| `smartProductId` | 非空时添加 |
| `encryptedType ` | 海外分支 2；源码键末尾有空格 |

按 workMode 选择，不能三条同时请求试探。国内默认旧入口；海外 OBM 为 CBC 命名入口，OEM 为 open/sdk。资源载荷加密方案尚未恢复。

证据：[ServerUrls.java:18](jadx/sources/com/midea/iot/msmart/common/utils/ServerUrls.java#L18)；[ProtocolControlManager.java:993](jadx/sources/com/midea/iot/msmart/protocol/ProtocolControlManager.java#L993)；[ProtocolControlManager.java:1001](jadx/sources/com/midea/iot/msmart/protocol/ProtocolControlManager.java#L1001)。

### lua_resource_cbc · Lua 协议资源查询

`POST v2/luaEncryption/luaGet` · `read_candidate` · `msmart_wrapper_workmode_dependent`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `iotAppId` | SDK 配置 |
| `applianceMFCode` | 厂商代码 |
| `applianceType` | 0x + 品类代码 |
| `modelNumber` | 设备内部子型号 |
| `applianceSn` | SN；海外分支先加密 |
| `version` | 当前 Lua 版本 |
| `smartProductId` | 非空时添加 |
| `encryptedType ` | 海外分支 2；源码键末尾有空格 |

按 workMode 选择，不能三条同时请求试探。国内默认旧入口；海外 OBM 为 CBC 命名入口，OEM 为 open/sdk。资源载荷加密方案尚未恢复。

证据：[ServerUrls.java:19](jadx/sources/com/midea/iot/msmart/common/utils/ServerUrls.java#L19)；[ProtocolControlManager.java:993](jadx/sources/com/midea/iot/msmart/protocol/ProtocolControlManager.java#L993)；[ProtocolControlManager.java:1001](jadx/sources/com/midea/iot/msmart/protocol/ProtocolControlManager.java#L1001)。

### lua_resource_oem · Lua 协议资源查询

`POST /v2/open/sdk/product/encrptedLuaGet` · `read_candidate` · `msmart_wrapper_workmode_dependent`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `iotAppId` | SDK 配置 |
| `applianceMFCode` | 厂商代码 |
| `applianceType` | 0x + 品类代码 |
| `modelNumber` | 设备内部子型号 |
| `applianceSn` | SN；海外分支先加密 |
| `version` | 当前 Lua 版本 |
| `smartProductId` | 非空时添加 |
| `encryptedType ` | 海外分支 2；源码键末尾有空格 |

按 workMode 选择，不能三条同时请求试探。国内默认旧入口；海外 OBM 为 CBC 命名入口，OEM 为 open/sdk。资源载荷加密方案尚未恢复。

证据：[ServerUrls.java:20](jadx/sources/com/midea/iot/msmart/common/utils/ServerUrls.java#L20)；[ProtocolControlManager.java:993](jadx/sources/com/midea/iot/msmart/protocol/ProtocolControlManager.java#L993)；[ProtocolControlManager.java:1001](jadx/sources/com/midea/iot/msmart/protocol/ProtocolControlManager.java#L1001)。

### transparent · 原始协议透传

`POST v1/appliance/transparent/send` · `mixed_or_unknown` · `msmart_wrapper_workmode_dependent`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `applianceCode` | 设备 ID |
| `order` | 二进制→十进制字符串→会话 AES 加密→hex |
| `timestamp` | 字符串 "true" |
| `isFull` | 字符串 "false" |

同一路由承载查询和控制。只读阶段不允许不透明 order；须先证明精确查询报文及 Lua 版本。

证据：[ServerUrls.java:21](jadx/sources/com/midea/iot/msmart/common/utils/ServerUrls.java#L21)；[DataTransportHelper.java:441](jadx/sources/com/midea/iot/msmart/control/DataTransportHelper.java#L441)。

### transparent_oem · 原始协议透传

`POST /v2/open/sdk/appliance/transparent/send` · `mixed_or_unknown` · `msmart_wrapper_workmode_dependent`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `applianceCode` | 设备 ID |
| `order` | 二进制→十进制字符串→会话 AES 加密→hex |
| `timestamp` | 字符串 "true" |
| `isFull` | 字符串 "false" |

同一路由承载查询和控制。只读阶段不允许不透明 order；须先证明精确查询报文及 Lua 版本。

证据：[ServerUrls.java:22](jadx/sources/com/midea/iot/msmart/common/utils/ServerUrls.java#L22)；[DataTransportHelper.java:441](jadx/sources/com/midea/iot/msmart/control/DataTransportHelper.java#L441)。

## 插件桥接与事件

### plugin_cloud_bridge · 插件通用云请求

`POST /{version}/{url}` · `mixed_or_unknown` · `legacy_midea_wrapper_mas`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `bridge.version` | 默认 v1 |
| `bridge.url` | 调用方路径 |
| `bridge.params` | JSONObject |
| `injected` | reqId、stamp、当前 homegroupId，可选 uid |
| `header.accessToken` | 正常登录 token |

动态插件可构造新的业务接口；桥接签名存在不代表已枚举其调用集合。未知路径或 params 必须保持禁止执行。

证据：[DefaultBridgeNetImpl.java:109](jadx/sources/com/midea/hybrid/api/meiju/bridge/impl/DefaultBridgeNetImpl.java#L109)；[DefaultBridgeNetImpl.java:159](jadx/sources/com/midea/hybrid/api/meiju/bridge/impl/DefaultBridgeNetImpl.java#L159)。

### sse_access · SSE 事件流

`GET /v3/sse/access` · `subscription_with_session_effects` · `direct_regional_sse_host`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `query.reset` | 配置默认 2 |
| `query.offset` | latestMessageId 或 0 |
| `query.client_type` | GlobalConfig.clientType |
| `headers` | accessToken、terminalId、appId，可选区域签名；还需完整 RequestClient 链 |

连接可能改变消费位置；美居实现会另行确认消息。当前只读阶段先分析已有会话事件，不主动新建/确认订阅。

证据：[SSEChannelService.java:1044](jadx/sources/com/midea/push/channel/SSEChannelService.java#L1044)；[OkHttpEventSource.java:45](jadx/sources/com/midea/push/sse/OkHttpEventSource.java#L45)；[SSEHeaderInterceptor.java:23](jadx/sources/com/midea/push/common/SSEHeaderInterceptor.java#L23)。

### sse_confirm · 确认 SSE 消息偏移

`PUT /v3/msg/confirm` · `write` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `query.alias` | "/v3/msg/confirm" |
| `query.offset` | 消息 ID |
| `body` | 空字符串 |

经确认 host 的 /mas/v5/app/proxy；与直连 SSE host 分开。确认消费位置，不等同于已读接口，仍有写副作用。

证据：[SSEChannelService.java:1017](jadx/sources/com/midea/push/channel/SSEChannelService.java#L1017)；[SSEChannelService.java:1057](jadx/sources/com/midea/push/channel/SSEChannelService.java#L1057)。

## 设备专项辅助

### panel_device_list · 面板设备 ID 列表

`POST /v1/appliance/list/codes` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `reqId` | 当前毫秒字符串 |
| `stamp` | yyyyMMddHHmmss |
| `platform` | "app" |
| `version` | App 版本 |
| `applianceCodes` | 设备 ID 字符串数组 |

固件检查入口不等于执行升级；升级下发与实际刷写禁止执行。

证据：[DeviceAPI.java:18](jadx/sources/com/midea/hybrid/api/meiju/bridge/api/DeviceAPI.java#L18)；[DefaultBridgeDeviceImpl.java:1549](jadx/sources/com/midea/hybrid/api/meiju/bridge/impl/DefaultBridgeDeviceImpl.java#L1549)。

### ota_check · 混合设备固件更新检查

`POST /v2/mix/device/update/has/check` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `applianceList` | JSON 数组 [{"applianceCode":"..."}]，区别于旧接口的字符串 |

固件检查入口不等于执行升级；升级下发与实际刷写禁止执行。

证据：[DeviceAPI.java:15](jadx/sources/com/midea/hybrid/api/meiju/bridge/api/DeviceAPI.java#L15)；[DefaultBridgeDeviceImpl.java:1317](jadx/sources/com/midea/hybrid/api/meiju/bridge/impl/DefaultBridgeDeviceImpl.java#L1317)。

### ota_list_check · 固件更新检查列表

`POST /v1/device/update/has/check/list` · `read_candidate` · `mas_proxy`

| 参数位置/字段 | 已读源码所示 |
| --- | --- |
| `applianceList` | JSON 字符串；内容为 [{"applianceCode":"..."}] |

固件检查入口不等于执行升级；升级下发与实际刷写禁止执行。

证据：[DeviceAPI.java:24](jadx/sources/com/midea/hybrid/api/meiju/bridge/api/DeviceAPI.java#L24)；[DefaultBridgeDeviceImpl.java:1243](jadx/sources/com/midea/hybrid/api/meiju/bridge/impl/DefaultBridgeDeviceImpl.java#L1243)。

## 全功能覆盖仍缺的证据

每台需要建立“美居页面功能 → 插件/模板事件 → route/桥接方法 → 请求字段/枚举 → 状态/事件确认”的逐项映射。仅有属性 URL 或通用品类文案无法证明全功能。

四台空调要分别核对舒适/节能/风向/能耗等扩展；冰箱核对深冷、制冰、变温及相关统计告警；洗碗机核对云程序、投放、分层/强洗、储存、预约、耗材与用水用电统计。以上项目是否在该设备面板开放，以实际面板与资源为准。

特别注意：TSL 未读历史不是已证实的能耗接口，全屋 EMS 组件也不是空调计量；参数枚举和数值范围目前保持未知。Lua 的 key 派生可读到 MD5/SHA256 截取分支，但真正的 AES 重载是 native，不能仅因 IV 为 null 就断言 ECB 或补齐方式。

当前 ADB 设备列表为空，缺少正常登录的 Android 环境及型号面板资源。后续在本机完成正常登录，凭据和完整令牌不进入聊天或报告；先拿目录、资源、状态与历史列表，对照页面，只读阶段不执行设置、动作、定时编辑、告警已读/删除或 SSE 确认。

完整原始索引：[HTTP 声明](interface_catalog.json)、[路由字符串候选](route_literal_index.json)、[桥接声明](bridge_interface_index.json)。机器可读的字段和 DTO 证据见 [integration_contract.json](integration_contract.json)。
