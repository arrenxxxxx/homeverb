# 六台美居设备：型号能力与接口恢复记录

更新：2026-10-22。目标是自研聚合 App 的设备拉取、状态查询和型号专属控制，包含设备相关高级功能、统计和告警。家庭管理、首页、商城、社区不需要重做。动态验证保持只读。

**独立客户端已完成账号设备枚举、六台 TSL 状态读取、四台空调及冰箱 Lua 状态读取，以及部分统计、配置和已有告警读取。没有执行任何设备控制或设置。独立登录、续期和全部高级功能仍未完成，不能称为“全部接口已跑通”。**

只读客户端：[readonly_client.py](runtime/waydroid/readonly_client.py)。已保存响应的脱敏证据：[readonly-observations.json](runtime/waydroid/readonly-observations.json)。它汇总每个操作／型号最新一次成功快照，共 22 份；不是所有请求尝试的审计计数。洗碗机配置返回空正文，单独保留为未解决项。

结构化结果：[six-device-contract.json](six-device-contract.json)。它包括真实产品身份、资源摘要、型号配置、控制参数构造代码、状态字段映射、动作转换逻辑和专有云路由候选；全部禁止自动执行。`plugin_route_catalog` 还覆盖下载插件的所有主面板和子页面，按字面量合并并保留每处源码引用；该索引含共享业务和不完整路径片段，不能直接等同于这六台支持的功能或可执行接口。

## 真实设备与资源

| 型号 | 品类 | modelNumber | SN8 | smartProductId | 首页模板 |
| --- | --- | --- | --- | --- | --- |
| KFR-26G/N8VJC3 | 0xAC | 0 | 22012559 | 10003004 | 241082 |
| KFR-35G/N8HE1ⅡPro | 0xAC | 0 | 22040089 | 10008870 | 241764 |
| KFR-35G/WF2 | 0xAC | 0 | 22013331 | 10014235 | 273778 |
| KFR-72G/N8HA1Pro | 0xAC | 0 | 220F4057 | 10014643 | 277500 |
| BCD-600WUFIPZM(E) | 0xCA | 56 | 310A2111 | 10012798 | 253672 |
| GX1200Max 尊享版 | 0xE1 | 3 | 760064BA | 10012847 | 280055 |

以上先由登录后的设备缓存识别，随后独立 `home/list/aggregate` 响应恰好返回六台，设备 ID 集合与缓存完全一致。完整 applianceCode 和加密 SN 只保存在本机私有文件，分享版契约不包含它们。缓存中的 onlineStatus 均为 1，但这只是该次缓存的在线标记。

四台空调的 `modelNumber` 全为 0，因此仅按它选择功能一定会丢失区别。六台的 `supportThing=1` 是目录线索；面板仍有 Lua/物模型/固件分支，不能据此断定实际所有请求都走同一种协议。

资源实证：六个产品目录共复制 182 个 JS、JSON、HTML、map 文件，其中 JS 140 份。四台空调主脚本 SHA256 相同，属于通用面板；冰箱与洗碗机各有自己的面板及子页面。文件路径、大小及 SHA256 已写入契约。

已取得并解密 9 份 Lua：六台各自准确 SN8 的专有协议和三份通用协议，全部通过 Lua 5.3 的**仅编译语法检查**。没有在本地执行 Lua，也没有用其生成控制报文；服务端 Lua 状态读取是独立的 HTTP 查询。

## 型号独有能力怎么获得

实际有三层：设备接口返回内部产品身份；资源接口选择插件、模板和 Lua；插件再按子型号、固件、当前状态及云配置决定功能。

| 品类 | 已恢复的选择规则 | 运行时仍需确认 |
| --- | --- | --- |
| 四台空调 | 同一插件的 `SNFuncMatch` 按 SN5 匹配子型号，合并默认功能；未知型号还可读 SN 参照和 `/applianceConfig/getSn5Function` 云配置 | 最终功能矩阵、额外规则、固件条件、实际物模型分支 |
| 冰箱 | 实际云配置已返回；冷藏 2～8℃、冷冻 -24～-16℃、变温档 6/2/0℃，`luaSource=0` | 本次云端扩展列表为空，旧缓存有静音／省电星，仍需解释差异 |
| 洗碗机 | 状态实测 `dishwasher.mcuFunctionVersion=1`，命中 `760064BA_1`；协议版本 51 | `settingInfo` 返回空正文，未取得有效云覆盖配置 |

首页模板只描述卡片显示的少量状态，不能作为全功能能力表。目录里的 `ability` 也主要是连接/配网标志。

## 设备拉取和通用传输

以下是业务路径；固定只读客户端已实现当前本机会话的 MAS 鉴权与包装。它不接受任意 URL、方法或正文，没有控制执行入口。

| 目的 | 方法与业务路径 | 已恢复的关键参数 |
| --- | --- | --- |
| 账号设备枚举 | POST `/v1/appliance/home/list/aggregate` | `cardType` 数组；每项 `type/query/extra`，注意是单数 `cardType` |
| 已知 ID 的设备详情 | POST `/v1/appliance/info/bind/batch` 等 | 已知 applianceCode 集合；这些接口本身不能完成账号枚举 |
| 服务端 Lua 状态 | POST `/v1/device/status/lua/get` | `applianceCode`、`command.query`、`caller`；查询字段来自具体插件 |
| 物模型全量状态 | GET `/v1/thing/properties/{applianceCode}` | `requestId`、`sync`、经确认的查询参数 |
| 物模型部分状态 | POST 同一路径 | 属性代码数组；POST 在这里也是读 |
| 物模型写属性 | PUT 同一路径 | 模块属性到值的对象；本次未执行 |
| 物模型动作 | POST `/v1/thing/action/{moduleCode}/{actionCode}/{applianceCode}` | 动作正文；部分 query 类动作仍需逐项判定 |
| Lua 透传 | POST `v1/appliance/transparent/send` | 加密 order、timestamp、isFull；查询与控制共用路径 |
| 空调专有服务转发 | POST `v1/app2base/data/transmit` | `uid/proType/data/param`；data 是账号 dataKey 加密的 transmitData JSON，param 含 serviceUrl |
| 设备插件、模板、Lua | `getPluginV3`、`thing/template/get`、`protocol/lua/luaGet` | 产品身份、模板 ID、资源版本及摘要 |

原 App 枚举请求的业务正文为：

```json
{
  "cardType": [
    {"type":"appliance","query":{},"extra":["uiTemplate","newUiTemplate","compose","permission"]},
    {"type":"lightGroup","query":{},"extra":["permission","newUiTemplate"]}
  ]
}
```

响应模型是 `MasRsp<HomeCardRsp>`，`data.appliance` 包含家庭与设备对象；聚合平台内部展开成扁平设备列表即可。第二项是原调用的灯组请求，本账号没有在此证明可删除该项；这不要求重做家庭或首页 UI。

证据：[HomeApiService.java:59](jadx/sources/com/midea/business/datacenter/api/HomeApiService.java#L59)、[DeviceInfoService.java:609](jadx/sources/com/midea/business/datacenter/service/DeviceInfoService.java#L609)、[HomeCardReq.java:13](jadx/sources/com/midea/business/datacenter/bean/req/HomeCardReq.java#L13)。已独立回放成功，并核对六台完整 ID 集合。

## 四台空调的确定差异

下面是**精确 SN5 静态配置匹配**，尚不等于当前设备返回的能力。完整功能标志及 Lua 键在 JSON 的 `devices[].static_config_matches`。

| 型号 | 插件子型号 | 与基础温控之外相关的配置 |
| --- | --- | --- |
| N8VJC3 | `_MJA` | ECO、上下摆风、防直吹、干燥防霉、电辅热、睡眠曲线、屏显、智控温、智清洁、滤网保养；当前匹配表未启用左右摆风和电量统计标志 |
| N8HE1ⅡPro | `_HELPRO` | 省电、强冷、左右摆风、摆风角度、智能光感、电控声音、升级版智清洁、高温除菌设置、电量统计、电辅热默认规则 |
| WF2 | `_WF` | 酷省电、无风感、母婴模式、安装位置、湿度显示、智能光感、电量统计、物模型控制标志 |
| N8HA1Pro | `_KS2Gua_ProvinceHeat` | 省电、上下防直吹、左右摆风、摆风角度、智能光感、电量统计、物模型控制标志 |

这些配置还包含 UI 和协议开关，因此 32/43/45/41 个合并标志不能当作可控制功能数量。JSON 将其中 25 个实际控制参数构造方法关联到了对应型号标志；`shared_device_request_builders` 另外保留整个空调控制模块中发起设备请求的方法，避免漏掉没有直接引用 FuncType 的构造器。共享方法并不表示该台可用，仍需型号与状态筛选。

部分已恢复的参数和条件：

| 功能 | Lua/面板键 | 物模型映射或条件 |
| --- | --- | --- |
| 开关 | `power:"on"/"off"`，可附 buzzer | 物模型按实际模块转换 |
| 模式 | `mode`：cool/heat/fan/auto/dry | 切模式会按协议分支清理睡眠、省电等互斥参数，不能只抄一个 mode 字段 |
| 目标温度 | `temperature` 整数加 `small_temperature` 0/0.5 | `targetTemperature`；通用构造方法夹取 16–30℃，最终可调范围和模式限制仍需设备证明 |
| 风速 | `wind_speed` | 1–100；超过 100 归为 102 自动风；物模型使用 windSpeed 或 autoWindSpeed |
| 上下摆风 | `wind_swing_ud` | verticalSwing；角度另为 wind_swing_ud_angle / verticalSwingAngle |
| 左右摆风 | `wind_swing_lr` | 只在对应配置启用时暴露 |
| VJC3 ECO | `eco` | 与其他省电功能分开 |
| 省电/酷省电 | `cool_power_saving` | 不应与 ECO 混成一个无条件开关 |
| 屏显 | `screen_display` | TH 与旧分支的值形态不同；物模型为 screenDisplaySwitch |
| 无风感 | `no_wind_sense` | WF2 配置启用 |
| 母婴模式 | `mother_baby_mode` | WF2 配置启用，仍有状态约束 |
| 上下防直吹 | `prevent_straight_wind`、`prevent_straight_wind_lr` | 72G 对应配置 |
| 强冷 | `strong_cool` | HE1 Pro 对应配置 |

统计/告警和高级设置的专有路径已定位，例如：

- `/rac-air/v1/elec/statistic/support`、`/rac-air/v1/elec/date/get`、`/elec/monthly/report/get`。
- `/ac_fault/record/get`、`/ac_fault/record/list/query`、`/rac-check/check/midea/detection/fault/info`。
- `/rac-air-sleep-midea/sleep/curve/query/CurvesByApplianceId` 等睡眠曲线读取；保存、启动、停止是独立写操作。
- `/rac-air/filter/queryCleanRecords` 等滤网记录；清洁确认/重置是写操作。

上述路径来自 `serviceUrl` 或同类包装，不能直接把它拼到 MAS host 上调用。转发加密代码见 [DefaultBridgeBusinessNetImpl.java:916](jadx/sources/com/midea/hybrid/api/meiju/bridge/impl/DefaultBridgeBusinessNetImpl.java#L916)。

## 冰箱 BCD-600WUFIPZM(E)

**这台的 getFridgeConfig 实际响应已取得，`luaSource=0`。** 冷藏范围 2～8℃、冷冻 -24～-16℃，变温空间是母婴 6℃／珍品 2℃／零度 0℃；三温区的 `canClose=false`。基础模式码为 0、1、21、22、24、28、37、13，须继续经过插件 `handleModes` 合成界面模式；13 的 `isAlwaysLight=true`。深冷名称为“-30℃深冷”，但 `deepcold_temp=null`，不能把名称直接当作可写温度。

本次独立云响应 `extendList=[]`、`have_silence_model=false`、`eco_power_star=0`；较早 App 缓存含静音 type4、省电星 type8。因此保留两份证据，不把缓存扩展项直接标为当前已验证功能。准确 SN8 Lua 和转换字典还包含其他冰箱的字段，不能全部暴露给本台。

配置请求参数为 `sn=SN5`、`fridgeSn=解密SN`、`fridgeId=设备ID`。插件还增加 `time_stamp/nonce/token`，并把它们串入 `/bx/fridgesn/v2/getInfo.do&...`。这里的 token 是独立业务签名：参数名和值拼接、排序、合并、MD5，再用插件内置常量执行 AES-ECB/PKCS7，输出十六进制密文。MD5 模块已用空字符串、ASCII 和中文三个样例与 Node 标准实现比对通过。它不是账号登录 token，也不能替代 MAS 鉴权；常量值未写入报告。

已恢复 112 条最终转换映射，含类型与 transformType；示例：

| Lua 键 | 物模型键 |
| --- | --- |
| storage_temperature | storageChamber.targetTemperature |
| freezing_temperature | freezerChamber.targetTemperature |
| storage_power | storageChamber.power |
| freezing_power | freezerChamber.power |
| storage_mode | storageChamber.quickCooling |
| freezing_mode | freezerChamber.quickFreezing |
| deep_cold_mode | freezerChamber.deepColdMode |
| freezing_ice_machine_power | freezerIceMachine.iceMachineSwitch |

独立 TSL 与 Lua 状态均已成功返回；TSL 返回 22 个顶层属性。记录中的 HTTP 收包时间不等于物理采样时间，Lua 查询是否使用云缓存仍待确认。

`luaSource=1` 且 App 版本达标时，插件会把 Lua 形态转换成物模型请求；其他情况使用 Lua。部分查询失败后会请求影子状态，聚合 App 必须标出缓存状态与实时回源状态。

相关云服务候选包括运行报告 `/bx/fridge/FridgeStatistics/index40`、开门记录 `getPatternOpenDoorListNew`、自检 `.../fault/getSelfCheckData.do`、健康状态 `getFridgeStatus2`、云功能开关 `.../switchStatus/get.do`。其中配置、运行报告和已有诊断数据读取已独立成功。报告含能耗评分、开门统计和清洁周期；已有诊断接口含 noticeList、sensorList、performanceList、coreList。没有触发设备自检。其他候选仍需按型号与正文逐项筛选。

## 洗碗机 GX1200Max 尊享版

精确 `760064BA_0` 和 `760064BA_1` 两分支已离线恢复。状态读取的 `dishwasher.mcuFunctionVersion=1` 已确认当前使用 **760064BA_1**，不是根据 OTA 版本猜测。分层洗、专区强洗、智能投放、储存和循环储存的 Supported 标志均返回 true；这只能确认对应支持标记，不能证明所有控制组合已验收。

| 功能组 | 精确型号配置 |
| --- | --- |
| 本地程序 | 抑菌储存 keep/100、晶焰消毒 crystal_flame_disinfect/33、果蔬洗 fruit/11、快速洗 rapid/7、超强洗 strong/2、标准洗 normal/3、一键洗烘 wash_dry/31 |
| 云程序 | 自清洁 self_clean/10、节能洗 eco/4、消毒洗 germ/13、静音洗 quiet_night/19、轻柔洗 glass/5、火锅洗 hotpot/18、海鲜洗 seafood/16 |
| 更多功能 | 抑菌储存、分层洗、专区强洗、智能投放 |
| 功能页 | 水电统计、固件升级、滤网清洁与保养、洗碗盐档位、漂洗剂档位 |

表中的程序数字是插件配置值；物模型协议还通过 `Tt` 再转换，不能将这些数字无条件作为 TSL workMode 直接发送。`funList` 没有某项也不代表没有基础运行操作。

已取得 77 个物模型到内部状态的映射、60 个内部参数到物模型的映射，以及 42 个设备操作参数构造器、53 个共享云请求构造器。数字描述恢复的代码，**不是该型号已验证可用功能数**。

| 功能 | 内部/Lua 字段 | 物模型行为 |
| --- | --- | --- |
| 电源 | work_status=power_on/power_off | dishwasher.power 布尔值 |
| 开始洗涤 | 程序和选项组合 | startWashing 动作 |
| 暂停/继续 | work_status 及当前 operator | pauseWashing/recoverWashing；仅在对应运行状态 |
| 取消 | work_status=cancel 或功能专用取消字段 | 按当前状态选 cancelStorage/cancelDry/cancelVentilation/cancelAppointing/cancelWashing |
| 分层洗 | wash_region、more_region | 转换为对应 TSL zoneWash 等字段，数值并非一一相等 |
| 专区强洗 | more_region_reinforce | 对应属性布尔化 |
| 智能投放 | more_auto_throw | 对应属性布尔化 |
| 储存 | more_keep、keep_time | 储存开关或 startStorage/cancelStorage；keep_time 转换含除以 60 的单位变化 |
| 洗碗盐/漂洗剂 | consumables_salt_gear / consumables_bright_gear | 对应物模型档位属性 |

部分名称具有误导性：`setOrderMode` 在物模型分支调用的是 **querySingleMode**，用于查询程序时长/选项；`getDeviceModeOrder` 调用 devicePanelModeAction 并传 actionType=query。聚合平台应按正文和实际动作语义判定读写，不能只看函数名。

云配置示例正文是 `msg=e1Common`，`params` 含 `sn8/action=get/key=version_<设备版本>/value=""/type=settingInfo`。

专有云接口主要复用 `/cfhrs/e1/v1/api`、`/cfhrs/e1/v3/api`；请求包装补充当前用户 authUserId。不同业务由 msg 与 params.action 决定：

| 业务 | msg / action 或参数 |
| --- | --- |
| 水电汇总 | WaterDisherConsumptionV2 / V3；applianceId、userId、queryType |
| 近期用量 | getRecentDaysUseData / V2；date 或 month |
| 按月用量 | getUseDataByMonth；date |
| 自动储存 | smartStoreSwitch；action=get 读取，action=set 写入 |
| 自动童锁 | smartChildLockSetting；action=get/set |
| 收藏程序 | collections；action 和 data 决定读写 |
| 滤网/耗材 | consumablesManagement；action 和 data 决定读写 |
| 预约参数 | paramsManagement；action 与 data.key 决定操作 |
| 模型实例 | `/v1/appliance/thing/model/instance`；smartProductId、stamp、reqId |

这些共享请求中有该型号未启用的功能，契约保留了原参数表达式以便继续筛选。固件升级、重置、预约写入和所有控制均未执行。

## 已验证的只读接口

| 读取 | 结果 |
| --- | --- |
| 设备枚举 | HTTP 200、code=0；六台 ID 与 App 缓存完全一致 |
| 六台 TSL 全量状态 | 全部成功；依次 HE1/WF2/72G/VJC3/冰箱/洗碗机返回 15/59/39/18/22/36 个顶层属性 |
| 四台空调及冰箱 Lua 状态 | 全部成功；通用解码字段不代表全部物理能力 |
| HE1/WF2/72G 当月用电 | 业务 errCode=0；当前返回 5.97/1.23/47.89 kWh，统计值会随时间变化 |
| HE1 已有故障记录 | 业务 errCode=0；返回按日记录，记录数不是故障次数，没有启动诊断 |
| 洗碗机月水电 | retCode=0；31 条日记录合计 131.80L、6.46kWh；savedWater=308.20L |
| 洗碗机当前洗涤／自清洁历史 | 读取成功；当前洗涤的部分字段为 null，不声称已取到有效上次洗涤详情 |
| 冰箱型号配置／运行报告／已有诊断 | 均 code=0；已有诊断只读取结果，没有触发自检 |
| 洗碗机 settingInfo | HTTP 200 但正文为空，未获得有效配置 JSON |

TSL 请求使用 `sync=true`，可能向设备回源读取状态；没有写属性或执行动作。接收时间和响应文件摘要已记录，物理采样时间及云缓存时效仍未完全核验。UI 中“开机／关机”可能是可执行按钮，不能据按钮文字认定当前状态。

## 独立鉴权与封装

生产代理为 `https://mp-prod.smartmidea.net/mas/v5/app/proxy?alias=业务路径`。对原样 JSON 正文，加上按参数名排序的 query 名和值（排除 alias），得到 content；`random` 为 epoch 毫秒字符串。签名为 `HMAC-SHA256(masKey, mucSecret + content + random)`，输出小写 hex。DOFHttp 使用 `getMucSecret`，不要误用 `getIotSecret`。请求带 accessToken、appId=900、terminalId=900-android、secretVersion=1、version=11.7.10、platform=0、systemVersion=13，以及 random/sign。POST 正文还带 reqId、stamp。

这些密钥与当前会话只保存在本机 0600 文件；分享版不包含实际值。当前客户端复用已登录会话，**尚未实现独立登录或自动续期**。

空调转发的外层 alias 为 `/v1/app2base/data/transmit`，正文为 `uid/proType/data/param/reqId/stamp`。uid 为 C4A uid；部分内部业务的 userId 是 iotUserId，两者不可混用。国内缓存 dataKey 先用 ASCII `MD5(appKey)[:16]`、AES-ECB/PKCS7 解密；设备 SN 再用解出的账号 dataKey 解密。业务参数 JSON 用该 dataKey 执行 AES-128-ECB/PKCS7，输出小写 hex；param 中携带固定 serviceUrl。已验证 `/rac-air/v1/elec/date/get` 与 `/ac_fault/record/list/query`，没有把业务路径直接拼到 MAS 根路径。

冰箱还需要业务 token 和 `Authorization: iotUserId=<当前用户>&checkAuth=1`；它与 MAS accessToken/sign 属于不同封装层。

## 剩余工作与控制边界

1. 独立登录、token 续期及失效恢复仍未实现。
2. 洗碗机云覆盖配置为空，冰箱新旧扩展配置存在差异，需要继续核对。
3. 所有高级功能的可用条件、参数范围、其他统计周期、告警订阅和历史查询尚未逐项核验。共享路由和协议字段不能算作型号功能覆盖数。
4. 控制参数、转换和条件已静态恢复，但**所有控制执行均关闭，未做任何实际控制测试**。因此不能承诺全部控制已经可用。

Waydroid 面板已通过本机解包库的 Weex 单进程回退补丁显示，原签名 APK 未改。九份 Lua 已齐全，不存在待完成的管理员认证任务。兼容性实验和历史失败记录保存在运行时 README；不要将历史失败当作当前阻塞。
