#!/usr/bin/env python3
"""Build a shareable, redacted contract from the locally recovered model code."""
from datetime import datetime
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parent
BASE = ROOT/'runtime/waydroid/account-cache'
sys.path.insert(0,str(ROOT/'runtime/waydroid'))
from share_privacy import assert_shareable
def read(name):
    return json.loads((BASE/name).read_text())
def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n')

inventory = read('devices.private.json')
ac = read('ac-model-functions.json')
dw = read('dishwasher-protocol-contract.json')
ca = read('refrigerator-property-mappings.json')
index = read('plugin-contract-evidence.private.json')
manifest = read('plugin-file-manifest.json')
protocols = read('lua-decoded-manifest.json')
observations = json.loads((ROOT/'runtime/waydroid/readonly-observations.json').read_text())
ac_script = next(x for x in index['scripts'] if x['file']=='T0xAC_10003004/weex.readable.js')
ca_script = next(x for x in index['scripts'] if x['file']=='T0xCA_10012798/weex.readable.js')

def ref(file, line):
    return {'source':'runtime/waydroid/account-cache/plugins/'+file,'line':line}

ac_controls = []
for method in ac_script['methods']:
    if not 5500 <= method['line'] <= 6600:
        continue
    features = sorted(set(re.findall(r'FuncType\.([A-Za-z_]\w*)',method['source'])))
    if not features or not re.search(r'sendDeviceData|_sendDeviceData',method['source']):
        continue
    models = [d['productModel'] for d in ac if any(
        set(features)&{f['key'] for f in m['functions']} for m in d['matches'])]
    if not models:
        continue
    ac_controls.append({'operation':method['name'],'feature_keys':features,
        'static_model_candidates':models,'parameter_names':method['parameters'],
        'payload_constructor_source':method['source'],
        'evidence':ref(ac_script['file'],method['line']),
        'live_applicability_verified':False,'execution_enabled':False})

# Keep every device-request method in the shared AC control module, including
# methods without a direct FuncType reference. Applicability stays unverified.
ac_shared_builders = [dict(m, evidence=ref(ac_script['file'], m['line']),
    model_support_verified=False, execution_enabled=False)
    for m in ac_script['methods'] if 5484 <= m['line'] <= 6631 and
    re.search(r'sendDeviceData|_sendDeviceData', m['source'])]

# Subpages contain additional device settings and statistics. Preserve their
# route occurrences with source references without copying unrelated code.
route_catalog = {}
for script in index['scripts']:
    for route in script['routes']:
        route_catalog.setdefault(route['route'], []).append(dict(
            ref(script['file'], route['line']), function=route['function'],
            enclosing_property=route.get('enclosing_property')))

def cloud_candidates(script, route_filter=None):
    out=[]
    for route in script['routes']:
        if route_filter and not route_filter(route['route']):
            continue
        method = next((m for m in script['methods'] if m['name']==route['function'] and
                       m['line']<=route['line'] and route['line']-m['line']<200),None)
        out.append({'business_route_literal':route['route'],
            'function':route['function'],'request_constructor_source':method['source'] if method else route['source_context'],
            'evidence':ref(script['file'],route['line']),
            'semantics':'unclassified_static_candidate',
            'model_support_verified':False,'runtime_verified':False,'execution_enabled':False})
    return out

models=[]
for device in inventory:
    entry={k:device.get(k) for k in ['productModel','type','modelNumber','sn8','smartProductId','currentUiTemplateId','supportThing']}
    entry.update({'identity_evidence':'authorized_logged_in_app_device_cache',
        'private_identity_reference':'runtime/waydroid/account-cache/devices.private.json',
        'plugin_code_downloaded':True,'adapter_status_query_verified':True,'control_executed':False})
    entry['runtime_read_evidence']=[r for r in observations['requests'] if r['productModel']==device['productModel']]
    plugin=f"T{device['type']}_{device['smartProductId']}"
    plugin_files=[m for m in manifest if m['path'].split('/')[0]==plugin]
    entry['plugin_files']=plugin_files
    entry['downloaded_lua']=[p['file'] for p in protocols if '_'+device['sn8']+'_' in p['file']]
    if device['type']=='0xAC':
        model=next(x for x in ac if x['smartProductId']==device['smartProductId'])
        entry['capability_selection']=model['selection']
        entry['static_config_matches']=model['matches']
        entry['capability_evidence']=model['evidence']
    elif device['type']=='0xE1':
        entry['capability_selection']='Exact SN8 + device firmware/application version; cloud settingInfo may override'
        entry['actual_firmware_branch']=observations['dishwasher']['actual_firmware_branch']
        entry['runtime_capability']=observations['dishwasher']
        entry['firmware_configurations']=dw['firmware_settings']
    else:
        entry['capability_selection']='Cloud /bx/fridgesn/v2/getInfo.do; local cache key A2111FridgeDeviceCAFunc'
        entry['cloud_capability_response_obtained']=True
        entry['runtime_capability']=observations['refrigerator_capability']
        entry['cached_extension_conflict']=observations['refrigerator_config_caveat']
        entry['homepage_observed_fields']=['storageChamber.targetTemperature','storageChamber.power',
            'freezerChamber.targetTemperature','freezerChamber.deepColdMode']
    models.append(entry)

focused=json.loads((ROOT/'device_integration_contract.json').read_text())
selected=['lua_status_json','tsl_all','tsl_selected','tsl_batch_selected','tsl_batch_all',
          'tsl_set','tsl_action','transparent','tsl_templates','plugin_v3','lua_resource']
common=[x for x in focused['operations'] if x['id'] in selected]
for operation in common:
    read_op = {'tsl_all':'state','lua_status_json':'lua-state'}.get(operation['id'])
    if read_op:
        operation['runtime_verified']=True
        operation['verified_models']=[r['productModel'] for r in observations['requests'] if r['operation']==read_op and r['success']]
        operation['runtime_evidence']='runtime/waydroid/readonly-observations.json'
aggregate={
 'id':'account_device_inventory_aggregate','http_method':'POST',
 'route':'/v1/appliance/home/list/aggregate','transport':'mas_proxy',
 'semantics':'read','execution_enabled':False,'runtime_verified':True,
 'request':{'cardType':[
     {'type':'appliance','query':{},'extra':['uiTemplate','newUiTemplate','compose','permission']},
     {'type':'lightGroup','query':{},'extra':['permission','newUiTemplate']}]},
 'response':'MasRsp<HomeCardRsp>; data.appliance contains HomeInfo objects; flatten devices internally',
 'notes':'Independent authenticated HTTP replay returned exactly six device IDs, identical to the logged-in app cache. No household management UI is needed.',
 'runtime_evidence':'runtime/waydroid/readonly-observations.json',
 'evidence':[{'source':'jadx/sources/com/midea/business/datacenter/api/HomeApiService.java','line':59},
     {'source':'jadx/sources/com/midea/business/datacenter/service/DeviceInfoService.java','line':609},
     {'source':'jadx/sources/com/midea/business/datacenter/bean/req/HomeCardReq.java','line':13},
     {'source':'jadx/sources/com/midea/business/datacenter/bean/req/CardType.java','line':27}]}

ca_protocol=next((p for p in protocols if '_CA_310A2111_' in p['file']),None)
ca_fields=[]
if ca_protocol:
    source=(BASE/'lua-decoded'/ca_protocol['file']).read_text()
    ca_fields=sorted(set(re.findall(r'\bstreams\["([^"\]]+)"\]',source)))

contract={
 'generated_at':datetime.now().astimezone().isoformat(timespec='seconds'),
 'status':'independent_inventory_and_six_device_state_verified; model_specific_read_services_partly_verified; control_static_only',
 'scope':{'device_inventory':True,'device_status':True,'model_specific_control':True,
     'device_specific_statistics_and_alarms':True,'family_management_ui':False,
     'homepage_ui':False,'execution_policy':'read_only; no appliance-control execution'},
 'validation':{'logged_in_app':True,'actual_devices_observed':len(inventory),
     'model_plugin_count':6,'independent_client_implemented':True,
     'authenticated_http_replay_verified':True,'appliance_control_executed':False,
     'independent_login_implemented':False,'session_refresh_verified':False,
     'lua_decrypted':len(protocols),'lua_syntax_valid':sum(p.get('syntax_valid_lua53',False) for p in protocols)},
 'devices':models,
 'common_operations':[aggregate]+common,
 'runtime_observations':observations,
 'authentication':{
     'endpoint':'https://mp-prod.smartmidea.net/mas/v5/app/proxy?alias={business_route}',
     'headers':['accessToken','appId=900','terminalId=900-android','secretVersion=1','platform=0','version=11.7.10','systemVersion=13','random','sign'],
     'sign':'HMAC-SHA256(masKey, mucSecret + exact_JSON_body + sorted_query_name_values_excluding_alias + epoch_milliseconds), lowercase hex',
     'query_order':'Sort unescaped parameter names; append each name and string value. Sign the exact body bytes sent.',
     'post_meta':['reqId: UUID without hyphens','stamp: yyyyMMddHHmmss in the app timezone'],
     'key_note':'DOFHttp uses PROConfig.getMucSecret for signing; getIotSecret is a different cached-token encryption key. Values remain private.',
     'session_source':'Current authorized local app session; standalone login and refresh not implemented',
     'client':'runtime/waydroid/readonly_client.py','control_execution_available':False},
 'air_conditioner':{
     'shared_plugin_sha256':next(x['sha256'] for x in manifest if x['path']=='T0xAC_10003004/weex.js'),
     'feature_bound_control_builders':ac_controls,
     'shared_device_request_builders':ac_shared_builders,
     'query_builders':[dict(m,evidence=ref(ac_script['file'],m['line'])) for m in ac_script['methods']
                       if 5500<=m['line']<=5555 and m['name'].startswith('query')],
     'cloud_route_candidates':cloud_candidates(ac_script),
     'transport':{'bridge':'requestDataTransmit', 'http_method':'POST',
         'route':'v1/app2base/data/transmit',
         'body_fields':['uid','proType','data','param','enterprise (optional)'],
         'data_encoding':'AES-128-ECB/PKCS7 over transmitData JSON using decoded account dataKey; lowercase ciphertext hex. Domestic cached dataKey is decrypted using ASCII MD5(appKey)[:16]; device SN is then decrypted with dataKey.',
         'param':'queryStrings object, including serviceUrl literal from the plugin',
         'evidence':{'source':'jadx/sources/com/midea/hybrid/api/meiju/bridge/impl/DefaultBridgeBusinessNetImpl.java','line':916},
         'uid':'C4A uid, different from iotUserId; both are required by some nested services',
         'runtime_verified_business_routes':['/ac_fault/record/list/query','/rac-air/v1/elec/date/get']},
     'notes':['Shared route catalog includes other AC models; only model flags identify static applicability.',
         'Configuration flags include UI and protocol switches; flag count is not a count of controllable features.',
         'SN5 baseline matching does not prove cloud overrides, firmware conditions or observed runtime protocol branch.']},
 'dishwasher':dict(dw,actual_firmware_branch=observations['dishwasher']['actual_firmware_branch'],
     runtime_observation=observations['dishwasher']),
 'refrigerator':{
     'config_request':{'business_route':'/bx/fridgesn/v2/getInfo.do',
         'fields':['sn (SN5)','fridgeSn (decrypted SN)','fridgeId'],
         'plugin_added_fields':['time_stamp','nonce','token'],
         'response_fields':['devType','luaSource','fridgeData','extendList','humanSenser'],
         'evidence':ref(ca_script['file'],14372),'runtime_verified':True},
     'business_token':{'algorithm':'Sort concatenated parameter-name + parameter-value strings; join; MD5; AES-ECB with PKCS7; lowercase ciphertext hex',
         'constant_key_source':ref(ca_script['file'],3879),
         'digest_evidence':dict(ref(ca_script['file'],4902), verification='Isolated pure module 61 matches Node MD5 for empty, ASCII and UTF-8 inputs'),
         'note':'Business token is separate from MAS/session authentication; static key value is deliberately omitted.'},
     'property_mappings':ca['mappings'],
     'converter_source':next(m for m in ca_script['methods'] if m['name']=='t2.sendLuaRequest'),
     'cloud_route_candidates':cloud_candidates(ca_script,lambda r:r.startswith('/bx/') or r.startswith('/api/meiju/') or r.startswith('/FridgeStatistics/')),
     'lua_vocabulary_candidates':ca_fields,
     'runtime_capability':observations['refrigerator_capability'],
     'notes':[observations['refrigerator_config_caveat'],
         'Downloaded SN8 Lua contains shared protocol fields beyond this physical model; vocabulary is not a supported-feature list.',
         'luaSource=1 plus app version selects TSL conversion; otherwise Lua bridge. This appliance returned luaSource=0.',
         'Shadow-query fallback may contain cached state; report freshness separately.']},
 'protocol_resources':protocols,
 'plugin_route_catalog':{
     'scope':'All main panels and subpages in the downloaded six-product plugin index; duplicate script contents indexed once',
     'note':'Literal discovery index includes shared code, unrelated services and incomplete route fragments; not a callable API allowlist or device feature count.',
     'runtime_verified':False,'execution_enabled':False,
     'unique_literal_count':len(route_catalog),
     'occurrence_count':sum(map(len,route_catalog.values())),
     'routes':[{'business_route_literal':route,'evidence':evidence,
                'semantics':'unclassified_static_candidate','execution_enabled':False}
               for route,evidence in sorted(route_catalog.items())]},
 'remaining_work':['Standalone login and session refresh are not implemented or verified.',
     'Dishwasher settingInfo returned an empty HTTP body; cloud override remains unknown.',
     'Refrigerator current cloud and prior app cache differ in extension capabilities.',
     'All advanced feature applicability, value constraints, historical/statistical periods and alarm services are not yet individually verified.',
     'Physical sample time and response cache semantics remain unverified; HTTP receipt time is recorded.',
     'Control constructors are statically recovered only and have not been executed.'],
 'execution_enabled':False}

# Fail closed against accidental inclusion of account-specific identifiers or key.
rendered=json.dumps(contract,ensure_ascii=False)
assert_shareable(rendered)
save(ROOT/'six-device-contract.json',contract)
print(json.dumps({'devices':len(models),'ac_feature_bound_builders':len(ac_controls),
    'ac_cloud_candidates':len(contract['air_conditioner']['cloud_route_candidates']),
    'refrigerator_mappings':len(ca['mappings']),
    'refrigerator_cloud_candidates':len(contract['refrigerator']['cloud_route_candidates']),
    'dishwasher_device_builders':len(dw['builders']['device']),
    'dishwasher_cloud_builders':len(dw['builders']['cloud']),
    'private_identifier_scan':'passed','control_executed':False},ensure_ascii=False,indent=2))
