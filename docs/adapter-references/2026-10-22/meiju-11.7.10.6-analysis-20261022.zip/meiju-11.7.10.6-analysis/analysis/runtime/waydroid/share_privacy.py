"""Known local account secrets to exclude from shareable analysis artifacts."""
import json
import re

from readonly_client import BASE, account_data_key, current_session, decrypt_ecb


def private_values():
    session = current_session()
    config = json.loads((BASE/'mas-config.private.json').read_text())
    devices = json.loads((BASE/'devices.private.json').read_text())
    key = account_data_key(session)
    values = [str(v).encode() for v in session.values()]
    values += [config[k].encode() for k in ('mas_key','iot_secret')]
    values += [key]
    for name in ('lua-app-key.private','token-key.private','token-iv.private'):
        values.append((BASE/name).read_bytes())
    for device in devices:
        values.extend([str(device['applianceCode']).encode(), device['sn'].encode(),
                       decrypt_ecb(device['sn'],key)])
    source = (BASE/'plugins/T0xCA_10012798/weex.readable.js').read_text()
    values.append(re.search(r'var a = n\(60\), r = a\.enc\.Utf8\.parse\("([^"]+)"\)',source).group(1).encode())
    # Include raw and hex encodings without ever printing either form.
    return set(v for value in values for v in (value,value.hex().encode()) if len(v)>=8)


def assert_shareable(data):
    if isinstance(data,str):
        data = data.encode()
    if any(value in data for value in private_values()):
        raise ValueError('Known private account identifier or secret found; output blocked')
