"""Offline boundary tests: no real account data and no network connections."""
import contextlib
import hashlib
import hmac
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
from urllib.parse import parse_qs, urlsplit

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.padding import PKCS7
import readonly_client as client


def encrypt(text,key):
    pad = PKCS7(128).padder()
    padded = pad.update(text.encode())+pad.finalize()
    enc = Cipher(algorithms.AES(key),modes.ECB()).encryptor()
    return (enc.update(padded)+enc.finalize()).hex()


class Response:
    status = 200
    def __enter__(self): return self
    def __exit__(self,*args): pass
    def read(self,limit): return b'{"code":"0"}'


class ReadBoundaryTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name)
        self.requests = []
        self.session = {'accessToken':'test-token','iotUserId':'test-iot-user','c4aUid':'test-c4a-user'}
        app_key = '0123456789abcdef0123456789abcdef'
        self.data_key = b'abcdefghijklmnop'
        self.session['dataKey'] = encrypt(self.data_key.decode(),hashlib.md5(app_key.encode()).hexdigest()[:16].encode())
        self.config = {'base_url':'https://mp-prod.smartmidea.net/mas/v5/app/proxy','mas_key':'test-mas-key','iot_secret':'test-secret'}
        devices = [{'productModel':'AC','type':'0xAC','sn8':'22040089','applianceCode':'100001','sn':encrypt('TEST-SERIAL',self.data_key)},
            {'productModel':'OldAC','type':'0xAC','sn8':'22012559','applianceCode':'100002','sn':encrypt('TEST-OLD-SERIAL',self.data_key)},
            {'productModel':'BCD-600WUFIPZM(E)','type':'0xCA','sn8':'310A2111','applianceCode':'100003'},
            {'productModel':'GX1200Max 尊享版','type':'0xE1','sn8':'760064BA','applianceCode':'100004'}]
        for name,value in [('mas-config.private.json',self.config),('devices.private.json',devices),
            ('panel-config-cache.private.json',[{'value':{'fridgeData':{},'SN':'TEST-FRIDGE-SERIAL'}}])]:
            (self.base/name).write_text(json.dumps(value))
        (self.base/'lua-app-key.private').write_text(app_key)
        source = self.base/'plugins/T0xCA_10012798/weex.readable.js'
        source.parent.mkdir(parents=True)
        source.write_text('var a = n(60), r = a.enc.Utf8.parse("1234567890abcdef")')
        for item in (patch.object(client,'BASE',self.base),
            patch.object(client,'current_session',return_value=self.session),
            patch.object(client,'build_opener',return_value=self)):
            item.start()
            self.addCleanup(item.stop)

    def open(self,request,timeout):
        self.requests.append(request)
        return Response()

    def run_read(self,op,model='AC'):
        with contextlib.redirect_stdout(io.StringIO()):
            client.request_read(op,model)
        request = self.requests[-1]
        query = {k:v[0] for k,v in parse_qs(urlsplit(request.full_url).query).items()}
        body = json.loads(request.data) if request.data else None
        content = (request.data.decode() if request.data else '')+''.join(k+query[k] for k in sorted(query) if k!='alias')
        expected = hmac.new(b'test-mas-key',('test-secret'+content+request.get_header('Random')).encode(),hashlib.sha256).hexdigest()
        self.assertEqual(request.get_header('Sign'),expected)
        self.assertEqual(urlsplit(request.full_url).netloc,'mp-prod.smartmidea.net')
        return request,query,body

    def test_all_operations_have_fixed_read_shapes(self):
        for op in client.OPERATIONS:
            with self.subTest(op=op):
                request,q,b = self.run_read(op)
                self.assertIn(request.method,('GET','POST'))
                if op=='state':
                    self.assertEqual(q['alias'],'/v1/thing/properties/100001')
                    self.assertEqual(q['sync'],'true')
                    self.assertIsNone(b)
                elif op=='lua-state':
                    self.assertEqual(q['alias'],'/v1/device/status/lua/get')
                    self.assertEqual(b['command'],{})
                elif op.startswith('ac-'):
                    self.assertEqual(q['alias'],'/v1/app2base/data/transmit')
                    expected_route = '/ac_fault/record/list/query' if op=='ac-fault-history' else '/rac-air/v1/elec/date/get'
                    self.assertEqual(b['param'],{'serviceUrl':expected_route})
                    data = json.loads(client.decrypt_ecb(b['data'],self.data_key))
                    self.assertEqual(data.get('deviceSn',data.get('sn')),'TEST-SERIAL')
                    if op=='ac-statistics': self.assertEqual(data['type'],2)
                elif op.startswith('dw-'):
                    self.assertEqual(q['alias'],'/cfhrs/e1/v1/api')
                    self.assertEqual(b['msg'],{'dw-config':'e1Common','dw-statistics':'WaterDisherConsumptionV2',
                        'dw-last-wash':'getCurrentWashData','dw-clean-history':'getSelfCleanHistory'}[op])
                    if op=='dw-config': self.assertEqual(b['params']['action'],'get')
                elif op.startswith('fridge-'):
                    self.assertEqual(q['alias'],{'fridge-config':'/bx/fridgesn/v2/getInfo.do',
                        'fridge-report':'/bx/fridge/FridgeStatistics/index40',
                        'fridge-faults':'/bx/api/meiju/plugin/fault/getSelfCheckData.do'}[op])
                else:
                    self.assertEqual(q['alias'],'/v1/appliance/home/list/aggregate')
                    self.assertIn('cardType',b)

    def test_unknown_operations_and_wrong_models_never_connect(self):
        for operation,model in [('control','AC'),('https://example.com','AC'),('ac-statistics','OldAC'),
            ('ac-fault-history','BCD-600WUFIPZM(E)')]:
            with self.subTest(operation=operation,model=model), self.assertRaises(ValueError):
                client.request_read(operation,model)
        self.assertEqual(self.requests,[])

    def test_other_host_and_redirect_are_rejected(self):
        self.config['base_url']='https://example.com'
        (self.base/'mas-config.private.json').write_text(json.dumps(self.config))
        with self.assertRaises(ValueError): client.request_read('inventory')
        self.assertEqual(self.requests,[])
        self.assertIsNone(client.NoRedirect().redirect_request(None,None,302,'',{},'https://example.com'))


if __name__=='__main__': unittest.main()
