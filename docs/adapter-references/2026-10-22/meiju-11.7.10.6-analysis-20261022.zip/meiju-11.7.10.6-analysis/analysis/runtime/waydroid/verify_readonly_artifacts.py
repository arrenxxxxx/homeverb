#!/usr/bin/env python3
"""Verify local evidence, source links and known-secret exclusion offline."""
import ast
from datetime import datetime
import hashlib
import json
from pathlib import Path
import re

from share_privacy import assert_shareable

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BASE = HERE/'account-cache'


def read(path):
    return json.loads(path.read_text())


def walk(value):
    if isinstance(value,dict):
        yield value
        for item in value.values(): yield from walk(item)
    elif isinstance(value,list):
        for item in value: yield from walk(item)


contract_path = ROOT/'six-device-contract.json'
contract = read(contract_path)
observations = read(HERE/'readonly-observations.json')
assert len(contract['devices'])==6
assert observations['inventory']['exact_id_set_matches_app_cache']
assert contract['validation']['authenticated_http_replay_verified']
assert not contract['validation']['appliance_control_executed']
assert all(x.get('execution_enabled') is not True for x in walk(contract))
for record in observations['requests']:
    raw = ROOT/record['private_response_file']
    assert hashlib.sha256(raw.read_bytes()).hexdigest()==record['response_sha256']
    assert raw.stat().st_mode & 0o077 == 0
    assert not record['control_executed']
assert all(x['success'] for x in observations['requests'])

manifest = read(BASE/'plugin-file-manifest.json')
for item in manifest:
    data = (BASE/'plugins'/item['path']).read_bytes()
    assert len(data)==item['size']
    assert hashlib.sha256(data).hexdigest()==item['sha256']
protocols = read(BASE/'lua-decoded-manifest.json')
assert len(protocols)==9
for item in protocols:
    data = (BASE/'lua-decoded'/item['file']).read_bytes()
    assert hashlib.sha256(data).hexdigest()==item['sha256']
    assert item['syntax_valid_lua53'] and not item['lua_executed']

references = set()
line_counts = {}
for item in walk(contract):
    source = item.get('source')
    if not isinstance(source,str) or '\n' in source or not isinstance(item.get('line'),int): continue
    path = ROOT/source
    if not path.is_file() and (BASE/source).is_file(): path = BASE/source
    assert path.is_file(),source
    if path not in line_counts: line_counts[path]=len(path.read_text().splitlines())
    assert 1<=item['line']<=line_counts[path],(source,item['line'])
    references.add((source,item['line']))

share_files = [ROOT/name for name in ('README.md','device-integration.md','six-device-interfaces.md',
    'six-device-contract.json','device_integration_contract.json','integration_contract.json','integration-contract.md')]
share_files += [HERE/name for name in ('README.md','runtime-status.json','readonly-observations.json')]
for path in share_files:
    assert_shareable(path.read_bytes())
    if path.suffix=='.md':
        for target in re.findall(r'\]\((/[^)]+)\)',path.read_text()):
            assert Path(re.sub(r':\d+$','',target)).exists(),target
for path in [ROOT/'build_six_device_contract.py',*HERE.glob('*.py')]:
    ast.parse(path.read_text(),filename=str(path))
summary = {'checked_at':datetime.now().astimezone().isoformat(timespec='seconds'),'status':'passed',
    'checks':['Python syntax','Saved HTTP response hashes and private permissions',
        'Plugin and decoded Lua hashes','Source reference files and line bounds',
        'Known account IDs, encrypted/plain SN, tokens, dataKey and signing/business secrets excluded from listed share files',
        'Control execution disabled','Absolute report links resolve'],
    'share_files_scanned':[str(p.relative_to(ROOT)) for p in share_files],
    'resource_files_verified':len(manifest),'lua_files_verified':len(protocols),
    'unique_source_references':len(references),'saved_successful_read_responses':len(observations['requests']),
    'contract_sha256':hashlib.sha256(contract_path.read_bytes()).hexdigest(),
    'independent_authenticated_http_verified':True,'independent_login_verified':False,
    'session_refresh_verified':False,'lua_executed_locally':False,'appliance_control_executed':False}
(HERE/'offline-verification.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
