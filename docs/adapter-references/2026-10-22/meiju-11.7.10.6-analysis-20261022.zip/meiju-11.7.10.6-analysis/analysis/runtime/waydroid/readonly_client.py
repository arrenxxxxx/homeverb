#!/usr/bin/env python3
"""Fixed read-only MAS inventory and property requests for this user's six devices."""
import argparse
from datetime import datetime, timedelta, timezone
import hashlib
import hmac
import json
from pathlib import Path
import re
import secrets
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, build_opener, HTTPRedirectHandler, ProxyHandler
import uuid

from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives.padding import PKCS7

BASE = Path(__file__).resolve().parent/'account-cache'
OPERATIONS = ('inventory','state','lua-state','ac-fault-history','ac-statistics',
    'dw-config','dw-statistics','dw-last-wash','dw-clean-history',
    'fridge-config','fridge-report','fridge-faults')

def private_save(name, value):
    path = BASE/name
    path.touch(mode=0o600,exist_ok=True)
    path.chmod(0o600)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

def current_session():
    session = json.loads((BASE/'session-fields.private.json').read_text())
    key = (BASE/'token-key.private').read_bytes()
    iv = (BASE/'token-iv.private').read_bytes()
    dec = Cipher(algorithms.AES(key),modes.CBC(iv)).decryptor()
    padded = dec.update(bytes.fromhex(session['token']))+dec.finalize()
    unpad = PKCS7(128).unpadder()
    token = (unpad.update(padded)+unpad.finalize()).decode()
    if not token or not token.isascii():
        raise ValueError('Unexpected token encoding')
    session['accessToken'] = token
    return session

def fridge_business_params(params):
    source = (BASE/'plugins/T0xCA_10012798/weex.readable.js').read_text()
    key = re.search(r'var a = n\(60\), r = a\.enc\.Utf8\.parse\("([^"]+)"\)',source).group(1).encode()
    params = dict(params,time_stamp=int(time.time()*1000),nonce=secrets.randbelow(1000000))
    content = ''.join(sorted(k+str(v) for k,v in params.items()))
    digest = hashlib.md5(content.encode()).hexdigest().encode()
    pad = PKCS7(128).padder()
    padded = pad.update(digest)+pad.finalize()
    enc = Cipher(algorithms.AES(key),modes.ECB()).encryptor()
    params['token'] = (enc.update(padded)+enc.finalize()).hex()
    return params

def decrypt_ecb(ciphertext, key):
    dec = Cipher(algorithms.AES(key),modes.ECB()).decryptor()
    padded = dec.update(bytes.fromhex(ciphertext))+dec.finalize()
    unpad = PKCS7(128).unpadder()
    return unpad.update(padded)+unpad.finalize()

def account_data_key(session):
    # Domestic SecurityUtils.decodeAES128WithAppKey uses MD5[:16], ECB.
    app_key = (BASE/'lua-app-key.private').read_bytes()
    key = hashlib.md5(app_key).hexdigest()[:16].encode()
    data_key = decrypt_ecb(session['dataKey'],key)
    if len(data_key) != 16:
        raise ValueError('Unexpected account dataKey length')
    return data_key

def ac_transmit_body(operation, device, session, req_id, stamp):
    data_key = account_data_key(session)
    # Exact read constructor: AC plugin query(), not diagnosis/start/reset.
    sn = decrypt_ecb(device['sn'],data_key).decode()
    if operation == 'ac-fault-history':
        route = '/ac_fault/record/list/query'
        params = {'deviceId':int(device['applianceCode']),'deviceSn':sn,'day':10}
    else:
        route = '/rac-air/v1/elec/date/get'
        params = {'applianceId':int(device['applianceCode']),'type':2,
            'date':datetime.now(timezone(timedelta(hours=8))).strftime('%Y-%m-%d'),
            'userId':session['iotUserId'],'sn':sn}
    content = json.dumps(params,separators=(',',':')).encode()
    pad = PKCS7(128).padder()
    padded = pad.update(content)+pad.finalize()
    enc = Cipher(algorithms.AES(data_key),modes.ECB()).encryptor()
    return {'uid':session['c4aUid'],'proType':'0xAC',
        'data':(enc.update(padded)+enc.finalize()).hex(),
        'param':{'serviceUrl':route},
        'reqId':req_id,'stamp':stamp}

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None

def request_read(operation, model=None):
    if operation not in OPERATIONS:
        raise ValueError('Operation is not on the read-only allowlist')
    config = json.loads((BASE/'mas-config.private.json').read_text())
    if config['base_url'] != 'https://mp-prod.smartmidea.net/mas/v5/app/proxy':
        raise ValueError('Unexpected MAS host')
    session = current_session()
    devices = json.loads((BASE/'devices.private.json').read_text())
    if operation in ('state','lua-state','ac-fault-history','ac-statistics'):
        device = next(d for d in devices if d['productModel'] == model)
        if operation.startswith('ac-') and device['type'] != '0xAC':
            raise ValueError('AC history requires an air conditioner')
        if operation == 'ac-statistics' and device['sn8'] == '22012559':
            raise ValueError('This model has no enabled statistics flag')
    req_id = uuid.uuid4().hex
    # Match the app's current timezone (+02); random uses UTC epoch milliseconds.
    stamp = datetime.now(timezone(timedelta(hours=2))).strftime('%Y%m%d%H%M%S')
    headers = {'Content-Type':'application/json; charset=utf-8',
        'secretVersion':'1','version':'11.7.10','systemVersion':'13','platform':'0',
        'Accept-Encoding':'identity','terminalId':'900-android','appId':'900',
        'accessToken':session['accessToken'],
        'User-Agent':'meiju/11.7.10.6 (Android;waydroid_x86_6413)'}
    if operation == 'inventory':
        method = 'POST'
        query = {'alias':'/v1/appliance/home/list/aggregate'}
        body = {'cardType':[
            {'type':'appliance','query':{},'extra':['uiTemplate','newUiTemplate','compose','permission']},
            {'type':'lightGroup','query':{},'extra':['permission','newUiTemplate']}],
            'reqId':req_id,'stamp':stamp}
    elif operation in ('state','lua-state'):
        if operation == 'state':
            method = 'GET'
            query = {'alias':'/v1/thing/properties/'+str(device['applianceCode']),
                     'requestId':str(uuid.uuid4()),'sync':'true','reqId':req_id,'stamp':stamp}
            headers.update({'caller':'900','call-source':'mideaApp'})
            body = None
        else:
            method = 'POST'
            query = {'alias':'/v1/device/status/lua/get'}
            body = {'applianceCode':str(device['applianceCode']),'command':{},
                    'caller':'meiju-plugin-tradition','reqId':req_id,'stamp':stamp}
    elif operation in ('ac-fault-history','ac-statistics'):
        method = 'POST'
        query = {'alias':'/v1/app2base/data/transmit'}
        body = ac_transmit_body(operation,device,session,req_id,stamp)
    elif operation in ('fridge-config','fridge-report','fridge-faults'):
        model = 'BCD-600WUFIPZM(E)'
        device = next(d for d in devices if d['productModel'] == model)
        method = 'POST'
        headers['Authorization'] = 'iotUserId='+session['iotUserId']+'&checkAuth=1'
        params = {'fridgeId':str(device['applianceCode'])}
        if operation == 'fridge-config':
            cached = json.loads((BASE/'panel-config-cache.private.json').read_text())
            capability = next(x['value'] for x in cached if 'fridgeData' in x['value'])
            params.update({'sn':device['sn8'][-5:],'fridgeSn':capability['SN']})
            query = {'alias':'/bx/fridgesn/v2/getInfo.do',**fridge_business_params(params)}
            body = {'reqId':req_id,'stamp':stamp}
        elif operation == 'fridge-faults':
            params['sn8'] = device['sn8'][-5:]
            query = {'alias':'/bx/api/meiju/plugin/fault/getSelfCheckData.do',**fridge_business_params(params)}
            body = {'reqId':req_id,'stamp':stamp}
        else:
            query = {'alias':'/bx/fridge/FridgeStatistics/index40'}
            body = dict(fridge_business_params(params),reqId=req_id,stamp=stamp)
    elif operation in ('dw-config','dw-statistics','dw-last-wash','dw-clean-history'):
        model = 'GX1200Max 尊享版'
        device = next(d for d in devices if d['productModel'] == model)
        method = 'POST'
        query = {'alias':'/cfhrs/e1/v1/api'}
        params = {'authUserId':session['iotUserId']}
        if operation == 'dw-config':
            msg = 'e1Common'
            params.update({'sn8':device['sn8'],'action':'get','key':'version_1',
                           'value':'','type':'settingInfo'})
        elif operation == 'dw-statistics':
            msg = 'WaterDisherConsumptionV2'
            params.update({'applianceId':str(device['applianceCode']),
                           'userId':session['iotUserId'],'queryType':'month'})
        elif operation == 'dw-last-wash':
            msg = 'getCurrentWashData'
            params['applianceId'] = str(device['applianceCode'])
        else:
            msg = 'getSelfCleanHistory'
            params['applianceId'] = str(device['applianceCode'])
        body = {'msg':msg,'params':params,'reqId':req_id,'stamp':stamp}
    else:
        raise ValueError('Operation is not on the read-only allowlist')
    wire = json.dumps(body,ensure_ascii=False,separators=(',',':')).encode() if body is not None else None
    content = (wire.decode() if wire else '')+''.join(k+str(query[k]) for k in sorted(query) if k != 'alias')
    random = str(int(time.time()*1000))
    headers['random'] = random
    headers['sign'] = hmac.new(config['mas_key'].encode(),
        (config['iot_secret']+content+random).encode(),hashlib.sha256).hexdigest()
    url = config['base_url']+'?'+urlencode(query)
    # Avoid forwarding the account's token to redirects or inherited proxies.
    opener = build_opener(ProxyHandler({}),NoRedirect())
    request = Request(url,data=wire,headers=headers,method=method)
    started = time.time()
    try:
        with opener.open(request,timeout=25) as response:
            status = response.status
            payload = response.read(4*1024*1024)
    except HTTPError as error:
        status = error.code
        payload = error.read(1024*1024)
    except URLError as error:
        print(json.dumps({'operation':operation,'network_error':type(error.reason).__name__}))
        return
    try:
        parsed = json.loads(payload)
    except (ValueError,UnicodeError):
        path = BASE/('http-'+operation+'-raw.private.bin')
        path.touch(mode=0o600,exist_ok=True)
        path.chmod(0o600)
        path.write_bytes(payload)
        print(json.dumps({'operation':operation,'http_status':status,'json_response':False,
                          'response_bytes':len(payload)}))
        return
    safe_name = next((str(i) for i,d in enumerate(devices,1) if d['productModel']==model),'inventory')
    private_save('http-'+operation+'-'+safe_name+'.private.json',parsed)
    route = query['alias']
    if operation == 'state':
        route = '/v1/thing/properties/{applianceCode}'
    summary = {'operation':operation,'productModel':model,'http_method':method,
        'route':route,'http_status':status,
        'response_code':parsed.get('code',parsed.get('retCode')) if isinstance(parsed,dict) else None,
        'top_level_fields':list(parsed) if isinstance(parsed,dict) else [],
        'elapsed_seconds':round(time.time()-started,2),'control_executed':False,
        'observed_at':datetime.now().astimezone().isoformat(timespec='seconds')}
    private_save('http-'+operation+'-'+safe_name+'-summary.json',summary)
    print(json.dumps(summary,ensure_ascii=False))

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation',choices=OPERATIONS)
    models = [d['productModel'] for d in json.loads((BASE/'devices.private.json').read_text())]
    parser.add_argument('--model',choices=models)
    args = parser.parse_args()
    if args.operation in ('state','lua-state','ac-fault-history','ac-statistics') and not args.model:
        parser.error('This operation requires one --model')
    request_read(args.operation,args.model)
