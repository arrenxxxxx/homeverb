#!/usr/bin/env python3
"""Summarize saved read-only responses offline, without copying account IDs."""
from datetime import datetime
from decimal import Decimal
import hashlib
import json
from pathlib import Path

from readonly_client import BASE
from share_privacy import assert_shareable


def read(name):
    return json.loads((BASE/name).read_text())


def inner_response(payload):
    data = payload.get('data')
    if isinstance(data,dict) and 'returnData' in data:
        inner = data['returnData']
        return json.loads(inner) if isinstance(inner,str) else inner
    return payload


def field_types(data):
    return {k:type(v).__name__ for k,v in data.items()}


def device_ids(value):
    if isinstance(value,dict):
        found = {str(value['applianceCode'])} if 'applianceCode' in value else set()
        return found.union(*(device_ids(v) for v in value.values()))
    if isinstance(value,list):
        return set().union(*(device_ids(v) for v in value))
    return set()


devices = read('devices.private.json')
records = []
for path in sorted(BASE.glob('http-*-summary.json')):
    summary = json.loads(path.read_text())
    raw = path.with_name(path.name.replace('-summary.json','.private.json'))
    payload = json.loads(raw.read_text())
    inner = inner_response(payload)
    code = payload.get('code',payload.get('retCode'))
    inner_code = inner.get('errCode')
    route = summary.get('route')
    if summary['operation']=='inventory':
        route = '/v1/appliance/home/list/aggregate'
    elif summary['operation']=='state':
        route = '/v1/thing/properties/{applianceCode}'
    record = {k:summary.get(k) for k in ('operation','productModel','http_status','observed_at')}
    record.update(http_method=summary.get('http_method','GET' if summary['operation']=='state' else 'POST'),
        route=route,response_code=code,business_code=inner_code,
        success=summary['http_status']==200 and str(code)=='0' and (inner_code is None or str(inner_code)=='0'),
        private_response_file='runtime/waydroid/account-cache/'+raw.name,
        response_sha256=hashlib.sha256(raw.read_bytes()).hexdigest(),control_executed=False)
    if summary['operation'] in ('state','lua-state'):
        record['returned_field_types'] = field_types(payload['data'])
    if summary['operation'].startswith('ac-'):
        record['business_route'] = '/rac-air/v1/elec/date/get' if summary['operation']=='ac-statistics' else '/ac_fault/record/list/query'
        result = inner.get('result')
        if isinstance(result,dict):
            record['result_fields'] = field_types(result)
            record['monthly_totals'] = {k:result[k] for k in ('totalUseElec','totalUseTime','hasElecSaveProtocol') if k in result}
        elif isinstance(result,list):
            record['returned_day_records'] = len(result)
            record['note'] = 'Day records are not a fault count; rows may contain only a day field.'
    records.append(record)

fridge = read('http-fridge-config-5.private.json')['data']
cached = next(x['value'] for x in read('panel-config-cache.private.json') if 'fridgeData' in x['value'])
dw_state = read('http-state-6.private.json')['data']
dw_statistics = read('http-dw-statistics-6.private.json')['result']
usage = dw_statistics['data']
inventory = read('http-inventory-inventory.private.json')
report = {
    'generated_at':datetime.now().astimezone().isoformat(timespec='seconds'),
    'scope':'Saved independent HTTP read responses; no control execution',
    'capture_scope':'Latest saved successful response per operation/model; not an append-only count of all HTTP attempts',
    'inventory':{'success':str(inventory['code'])=='0',
        'device_count':len(device_ids(inventory)),
        'exact_id_set_matches_app_cache':device_ids(inventory)=={str(d['applianceCode']) for d in devices}},
    'requests':records,
    'refrigerator_capability':{k:fridge[k] for k in ('devType','luaSource','fridgeData','extendList')},
    'refrigerator_cached_extend_list':cached.get('extendList'),
    'refrigerator_config_caveat':'Current cloud extendList is empty; earlier app cache contains types 4 and 8. Preserve this conflict; cached extensions are not independently verified enabled functions.',
    'dishwasher':{'actual_firmware_branch':dw_state['dishwasher.mcuFunctionVersion'],
        'branch_key':'760064BA_'+str(dw_state['dishwasher.mcuFunctionVersion']),
        'protocol_version':dw_state['dishwasher.mcuProtocolVersion'],
        'supported_flags':{k:v for k,v in dw_state.items() if k.endswith('Supported')},
        'cloud_override_verified':False,
        'cloud_override_result':'HTTP 200 with empty body; no valid settingInfo JSON obtained',
        'monthly_statistics':{'water_litres':str(sum(Decimal(x['yWater']) for x in usage)),
            'electricity_kwh':str(sum(Decimal(x['yElectricity']) for x in usage)),
            'savedWater':dw_statistics['savedWater'],'day_records':len(usage)},
        'last_wash_fields':field_types(read('http-dw-last-wash-6.private.json')['result']),
        'self_clean_history_count':len(read('http-dw-clean-history-6.private.json')['result'])},
    'refrigerator_report':read('http-fridge-report-5.private.json')['data'],
    'freshness':'observed_at is HTTP receipt time, not proof of physical sample time; TSL sync=true requests refresh, Lua response cache semantics remain unverified',
    'returned_fields_are_capabilities':False,
    'appliance_control_executed':False,
    'lua_executed_locally':False,
    'independent_login_implemented':False,'session_refresh_verified':False
}
rendered = json.dumps(report,ensure_ascii=False,indent=2)+'\n'
assert_shareable(rendered)
target = Path(__file__).resolve().parent/'readonly-observations.json'
target.write_text(rendered)
print(json.dumps({'requests':len(records),'successful_reads':sum(x['success'] for x in records),
    'exact_inventory_match':report['inventory']['exact_id_set_matches_app_cache'],
    'control_executed':False,'known_secret_scan':'passed'}))
