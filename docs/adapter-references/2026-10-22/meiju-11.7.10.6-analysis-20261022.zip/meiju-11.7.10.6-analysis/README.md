# 美居 11.7.10.6：精简接入分析包

整理时间：2026-10-22T15:46:54+08:00（Asia/Shanghai）。从已脱敏的完整归档选取交付材料；未重新发送设备请求。

## 阅读入口

- [六台设备分析报告](analysis/six-device-interfaces.md)：当前结论、型号差异、已验证读取和缺口。
- [六台设备契约](analysis/six-device-contract.json)：型号配置、参数构造、映射、资源摘要和验证级别。
- [通用接入说明](analysis/integration-contract.md)及[契约](analysis/integration_contract.json)：传输和通用静态候选。具体六台结论以六台契约为准。
- [脱敏读取证据](analysis/runtime/waydroid/readonly-observations.json)：22 份每项最新成功快照，不是全部请求尝试数。
- `analysis/runtime/waydroid/account-cache/`：仅五份脱敏能力/协议配置 JSON，没有会话和私有回包。

已完成六台独立枚举与状态读取、部分型号配置及统计告警读取。没有执行控制，独立登录、续期和全部高级功能仍未完成。运行记录保留采集时点；本地安卓调试 App、Waydroid 和 ADB 已在后续收尾关闭，打包不会启动它们。

## 精简与备份

保留报告、接口契约、型号配置、验证结果和必要的只读/生成/验证脚本。移除 PDF/说明书文本、整份 JS/Java/Lua、全局静态路由和资产索引，以及安装、启动、补丁和诊断脚本。所选既有文件逐字节沿用完整包的已脱敏内容，六台能力与读取结论不变；只重写本页与清单。

完整旧包保存在导出目录 `backups/meiju-11.7.10.6-analysis-20261022.zip`，SHA256：`bc711d46b5610d38bd2c70d0221f7777595aa61de91ede769cc163d36419496c`。原工作区材料不动。文件摘要、继承的脱敏信息、排除分类及解压后测试结果见 `PACKAGE-MANIFEST.json`。

未包含 APK、真实登录态、账号密钥、完整设备 ID/SN、原始回包、截图、日志和转储。文档及 JSON 中的源码/插件/私有证据引用是追溯入口，目标只在原工作区中保留，不属于精简包。

## 离线复核

解压后可运行合成数据白名单测试（依赖 Python、cryptography，不联网）：

```sh
python3 -m unittest discover -s analysis/runtime/waydroid -p test_readonly_client.py -v
```

客户端缺少真实认证材料，不能直接登录或重放账号请求。生成器及完整证据验证脚本依赖未打包的本机私有快照和源码，只能在原工作区完整运行。`offline-verification.json` 是原分析阶段的历史验证，新包完整性与测试结果以本包清单为准。
