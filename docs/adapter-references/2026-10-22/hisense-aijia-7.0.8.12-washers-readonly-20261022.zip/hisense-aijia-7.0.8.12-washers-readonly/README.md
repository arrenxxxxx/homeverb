# 海信爱家 7.0.8.12：两台洗衣机接入分析

分析日期：2026-10-22。范围是用户拥有的两台洗衣机；内部产品身份已匹配，完整零售铭牌型号仍未独立确认。动态验证限只读，控制、预约、配置修改、绑定、诊断启动和 OTA 均未执行。

**当前结论：原始 App 已正常登录，只读确认两个设备对象组成一张全家筒卡片：上分区 `WV20W-1`（左/右筒）和下分区 `WH120E5S-1`。已取得其实际功能与程序配置，并校验三个动态面板包。尚未恢复独立 HTTP 网关签名/登录续期，未交付可独立调用的云适配器。全程未发送设备控制或修改设备设置。**

优先阅读 [型号能力与完整程序配置](models.json)、[结构化契约](contract.json) 和 [只读观察](runtime/observations.json)。本目录与美居分析隔离，不修改 `analysis/` 下既有结果、登录态或设备缓存。

## 1. 已验证的 APK 基线

| 项目 | 结果 |
| --- | --- |
| 包名 | `com.hisense.ms.fly2tv` |
| 版本 | `7.0.8.12` / versionCode `70008012` |
| APK SHA256 | `937cf3f074457e9550b201329e635e9c38c4c012d6fe4744ab2b8fe530584a55` |
| APK 大小 | 149,676,839 字节 |
| Android | minSdk 21，targetSdk 30，compileSdk 34 |
| ABI | 仅 `arm64-v8a` |
| 包内文件 / 原生库 | 4,209 个文件 / 58 个 `.so` |
| 加固 | 百度 `com.sagittarius.v6.StubApplication`；23 份受保护业务 JAR |
| Java 反编译 | JADX 1.5.6 / Java 21，退出码 3；24 个输入项加载失败，另报告 6 个节点错误；仅得到 135 份 Java 文件 |
| 占位 DEX | 23 份 `.i.dex` 实为 ZIP；展开合计 78,167,088 字节，每份 50–51 个非零字节，不能当成业务源码 |
| Flutter | Dart 3.6.1；snapshot `f956f595844a2f845a55707faaaa51e4`；ARM64 compressed pointers |
| AOT 离线解析 | Blutter 成功导出对象池、带符号汇编；未执行其生成的 Frida 脚本 |

JADX 不是完整源码来源。下面的核心业务证据主要来自原始 `libapp.so` 的 AOT 解析；文件扩展名虽为 `.dart`，内容是工具推断的符号与 ARM64 汇编，不能视为可编译 Dart 源码。代码被去重后，方法可能显示为另一个业务类名，必须追到被调用的实现。

工具版本、输入摘要与限制见 [baseline.json](baseline.json)、[tool_provenance.json](tool_provenance.json)。完整字符串 URL 候选保存在 [route_candidates.json](route_candidates.json)，其中数量不代表洗衣机功能覆盖率。

## 2. 已恢复的接入主线

```text
正常账号登录（Android 原生；独立协议尚未恢复）
  → jhk_account.getAuthData
  → customerId / token / refreshToken 与有效期
  → 设备目录（首次枚举）
  → deviceId / partner / categoryCode / product / serialNumber / deviceInfo / states / labels
  → 产品功能描述、程序列表、各程序参数、面板资源
  → 状态映射与界面限制
  → 逻辑功能 → 实际 command + params → 原生网关（仅静态）
```

零售型号、`categoryCode`、产品对象中的内部代码、程序 `code/value` 和状态键是不同标识。两台设备必须分别保留内部身份和资源摘要，不能按同为“洗衣机”合并能力。[E01][E02][E03]

### 请求正文与网关边界

Flutter 层的逻辑正文为：

```text
header: messageId(UUID v1), timestamp, languageId, payloadVersion
payload: 具体业务字段
顶层公共参数: deviceId, appVersion, appType="1", accessToken
```

顶层 `deviceId` 来自手机/App 身份方法，与 `payload.deviceId` 的家电 ID 不同。`accessToken` 来自账号 `token`，不是 `refreshToken`。设备 Agent 初始化将 `sourceType` 设为 20；常见读取 DTO 保留整数，`execute` 调用先转成字符串，不能统一改写类型。`timestamp` 的最终填充、时间单位、签名覆盖原文与加密均仍需原生层证据。[E04][E05][E06]

业务调用明确选择 POST、JSON、`requestSignType=gateWay`、`responseSignType=gateWay`，经 `jhk_network` MethodChannel 的 `cloudRequest` 进入 Android 原生。桥接选项值分别为 method=1、contentType=0、requestSignType=1、responseType=0、responseSignType=1；这些数字由对象池枚举确认。[E07][E08]

**目前恢复的是进入原生网关前的逻辑正文。** 实际 HTTP header、网关签名、请求封装、响应解包仍未恢复，不能把这些正文直接当成可成功请求的 wire body。包内存在 AES 类和 `libEncryption.so`，不足以证明洗衣机网关使用某个 AES 模式或密钥。

### 响应判断

原生回包模型包含 `httpCode/httpMsg/data`。设备 Agent 先要求 HTTP 200 和可解析的 JSON `payload`，业务 DTO 再解释 `status/errorCode/errorDesc`；`JhkPayload.success` 比较 `status == "SUCCESS"`。读取还须检查设备清单、详情或状态实际结构。`refreshDeviceState` 成功响应主要是刷新受理结果，不能单凭它认定取得当前状态。[E09][E10]

已记录本机面板缓存的采集时间；原始状态接收时间、物理采样时间、缓存时效及回源参数是否生效仍未确认。

## 3. 操作契约

以下路径均在 `https://iot-aihome.hismarttv.com/4.0` 下，调用点采用 POST。字段是逻辑 `payload`，并非签名后的最终传输格式。服务器必填项仍待验证。

| 行为 | 路径 | 逻辑参数与限制 | 当前级别 |
| --- | --- | --- | --- |
| 首次设备枚举 | `/iot/devices/list` | `sourceType/customerId/homeId/partnerId/categoryCode/connectionType/bindStatus/withState/whitelist/withMultiSplit/comModuleId`；调用点启用 withState 与 withMultiSplit | 静态链路 |
| 按已有 ID 查询详情 | `/iot/devices/detail` | `sourceType/customerId/deviceId/partnerId` | 静态链路 |
| 刷新状态 | `/iot/state/refreshDeviceState` | `deviceIds/partnerId/deviceId`；刷新后还需读取状态或接收设备更新 | 静态链路 |
| 产品完整功能 | `/iot/devices/function/getByProduct` | `sourceType/products[]`；产品项含 `categoryCode/productCode`，按条件附加 `partnerId/deviceId` | 静态链路 |
| 首页卡片功能 | `/iot/devices/function/getHomepageConfig` | 同产品身份；卡片功能不能代替完整功能 | 静态链路 |
| 程序列表 | `/iot/devices/function/getModeList` | `sourceType/categoryCode/productCode/partnerId/deviceId` | 静态链路 |
| 各程序参数 | `/iot/devices/function/getModesFunctions` | 上述身份 + `modeCodes[]`；调用端按至多 5 个程序分批 | 静态链路 |
| 记忆参数 | `/iot/param/memory/get` | `sourceType/customerId/deviceId/partnerId`；不能将记忆值视为实时运行值 | 静态链路 |
| 动态面板资源 | `/iot/layout/controlFile/list` | `productCodeList[]` 含 product/category/可选 brand；另有 `sceneCode` | 静态链路 |
| 洗衣场景程序 | `/iot/wash/washScene/device/get` | `sourceType/categoryCode/productCode`，按条件附加 `tubType` | 静态链路 |
| 自定义程序读取 | `/iot/cloudCache/operationData/query` | `homeId/customerId/businessDataTypes/businessDataDim/partnerId/deviceId`；业务类型包含 `washCustomProgram` | 静态链路 |
| 智能程序命名读取 | `/iot/state/value/custom/name/get` | `devices[]` 含 device/partner/product/category 身份 | 静态链路 |
| 启停、程序等控制 | `/iot/devices/execute` | `sourceType/exclusionFlag/customerId/deviceId/partnerId/actions`；另有顶层 `sourceName`；当前调用 exclusionFlag=1 | 仅静态，禁止执行 |

首次枚举使用了与 OTA 清单相同的去重序列化实现，这不表示调用 OTA。枚举验收需比对完整 ID 集合、共享/多筒条目及 `totalCount`，不能只比数量。`homeId` 是否必须通过家庭目录取得属于内部依赖，当前不扩展对外家庭管理功能。

13 项操作各自的函数、路由、参数字段、源码行与文件摘要见 [contract.json](contract.json)。全部 `execution_enabled=false`；当前没有可发送网络请求的独立客户端。

## 4. 两个实际设备与原 App 验证

采集时间：2026-10-22 11:55:04（Asia/Shanghai）。来源为用户已正常登录的原始 App 界面及其现有 Vuex 设备缓存；通过 App 自身已开放的 WebView 调试端口读取普通属性，没有调用查询/控制桥接、注入 Frida 或改写页面状态。

| 项目 | 上分区：双筒 | 下分区：洗衣机 |
| --- | --- | --- |
| 内部产品代码 / App 产品名称 | `WV20W-1` | `WH120E5S-1` |
| 类别 | `connector.device.type.washer.multiple` | `connector.device.type.washer` |
| 分筒 | 左筒、右筒 | 单筒 |
| 实际功能定义 | 55 个 | 49 个 |
| 程序记录 | 54 条，即左/右各 27 条 | 37 条 |
| 缓存在线 / 电源 | 在线 / 已关闭 | 在线 / 已关闭 |
| 缓存远程权限 | `0=UnSupported` | `3=LongAuthorized` |
| 缓存童锁 | 已关闭 | 已关闭 |
| 缓存剩余时长 | 左/右均 0 分钟 | 43 分钟 |
| 上报版本字段 | hwVersion=`WM.01.08.03.10`；swVersion=`1.0` | 同左 |

`virtualWholeFamily` 是虚拟分组。已在本机用完整 ID 集合确认：分组的两个成员与两个运行时设备模块一致；分享结果不包含 ID、SN、家庭/账号标识。首页一张卡片并不等于只有一个设备对象。尚未独立核对整个账号目录，不据分组成员数声称账号内没有其他设备。

以上产品代码不是已核对的零售铭牌。55/49 排除了 `functionMap.stateMap` 辅助对象；54/37 是配置记录数，不能当作功能覆盖分母。所有记录的配置 visibleFlag 为 1，不代表已逐个打开或执行。下分区关机时仍保留 43 分钟，可能属于缓存/记忆状态，不能由余时推断正在运行。采样时间、缓存时效和当前物理状态未独立确认。

### 型号差异与控制约束

- 上分区的程序、运行阶段、余时、预约、启停、故障和水电量按 `.left/.right` 分开；电源、童锁、远程权限等为设备级功能。下分区使用独立身份和无分筒后缀的功能，另含洗涤剂/柔顺剂投放、门锁、取衣与线屑提醒、一键智洗等定义。
- 同一类程序不能跨型号复用值。例如上分区 `Baby_care_wash.left/right` 的 value 为 `12`，下分区 `Baby_care_wash` 的 value 为 `19`，显示名称也不同。动作仍须从当前型号的 action.command/params 与属性定义生成。[E11][E12][E13]
- 远程权限配置明确为 `0=不支持、1=未授权、2=单次授权、3=长期授权`。Flutter 共用 UI 判断采用“值不等于字符串 1”，不能据此证明服务器一定允许控制；本次没有改变任何授权。[E14]
- 已取得通用功能的属性类型、单位、默认值、范围/枚举，以及程序 functionCodeList；尚未取得所有程序各自的 getModesFunctions 回包。程序引用中，上分区有 22 个、下分区有 15 个不同功能代码未包含在通用功能表中，因此温度、转速、漂洗次数的逐程序限制仍不完整，不给出统一范围。
- 余时属性的 suffix 明确为 `min`；水量为 `L`、电量为“度”。这些配置不证明历史统计已验证。下分区缓存出现 waterConsumption/powerConsumption/washAmount 字段，但统计周期和对应 HTTP 响应未确认，交付中不包含个人使用累计值。
- 当前型号配置存在故障、筒清洁、预约、智能场景及 OTA 定义；它们仍是配置/静态支持证据，没有启动、取消预约、重置故障、清洁或升级。童锁、运行阶段、卖场模式、support_again_running 和完成后先设程序再启动的分支必须保留。[E15][E16]

完整功能定义、动作参数、程序列表、当前状态映射与尚缺的程序功能代码见 [models.json](models.json)。来自面板最终使用的配置，已剔除 UI 补充的 active 标记；不是服务器原样回包。洗护管家页的推荐场景、榜单及专题已读取，未点击“启动”或偏好设置。

### 动态面板来源与摘要

| 产品 | 资源登记版本 | 原包 MD5 |
| --- | --- | --- |
| virtualWholeFamily | 2439 | `4b593257916aa1494ff25ab2aeedf730` |
| WV20W-1 | 2440 | `25ad5d11ae9a7d383950b8a95e04cf1f` |
| WH120E5S-1 | 2441 | `293f9fe156d98cdc5918cfca6bedbc8f` |

从原 App 登记表取得官方公开资源 URL，以无账号会话的 GET 下载，禁止重定向；三个原包均与登记 MD5 一致，并记录 SHA256。全家筒已安装的 177 个文件与对应原包逐一相符。下载包只做离线文本解析，没有执行它们；设置页显示的智控页版本为 `1.8.0.5`，与登记版本、设备上报版本是不同版本字段。[资源摘要](resources.json)

## 5. 运行恢复、权限与仍缺的验收

- 原始 App 安装成功，包名、版本与安装后 APK SHA256 均与输入一致。用户明确允许本次 Play Protect 的 Install anyway，并自行完成安装；没有关闭全局保护、修改 APK 或原生库。
- 安装后 Android 无网：Active default network 为 none，netd 卡在 stopping，eth0 策略表无 IPv4 默认路由；宿主实际 legacy 转发与 NAT 已存在。对原 netd 发送 TERM 后服务恢复 running，但网络仍未恢复，网卡 down/up 也无效。
- 经用户单独批准，停止会话并重启一次 waydroid-container，再启动会话。随后默认路由、默认网络 100、DNS、网关/海信域名连通、ADB 和 App 首页加载均恢复。没有切换转译层、清除应用数据或修改宿主防火墙。
- 用户自行完成正常登录，密码/验证码输入期间未采集屏幕或输入日志。会话/偏好复制最初被自动审批审查阻止，之后用户明确授权读取当前登录令牌和设备配置缓存；才继续本机私有读取。并未恢复可独立重放的明文鉴权/续期协议。
- 实际验证达到了“已登录原 App 的界面 + 两个设备的运行时配置缓存”。尚未达到“独立 HTTP 读取”，没有发送任何设备控制或设置写入。

剩余接入缺口是原生网关签名/加密/解包、独立登录/续期/失效恢复、完整账号目录、逐程序参数详情、历史统计/故障记录与状态新鲜度。后续云客户端须固定 host/route/method/body 白名单，先离线验证拒绝写操作、任意 URL、重定向和透传，再少量真实只读请求。本次未发送猜测签名的请求，不以面板成功代替独立适配器验收。

## 6. 复现与交付边界

输入 APK 保持不变；反编译、AOT、字符串、资源与工具产物写入本任务目录或新增的 `tools/blutter*`。`runtime/private/` 为 0700，安装截图与 UI dump 为 0600，不属于可分享文件。

```sh
python3 analysis/hisense-aijia/7.0.8.12-937cf3f07445/scripts/baseline.py
python3 analysis/hisense-aijia/7.0.8.12-937cf3f07445/scripts/build_models.py
python3 analysis/hisense-aijia/7.0.8.12-937cf3f07445/scripts/build_contract.py
python3 analysis/hisense-aijia/7.0.8.12-937cf3f07445/scripts/verify_analysis.py
```

build_models.py 依赖本机私有快照；分享清单不含该快照，因此分享文件可供审阅，不能单独重放登录或生成型号结果。read_panel_snapshot.mjs 仅含固定的面板属性读取表达式，需已授权且已开放的本地 WebView 目标，不含任意执行入口或云请求功能。临时调试转发与本次 Android 诊断文件已清理，本地特权诊断 shell 已退出；不再使用的偏好/不相关数据库副本已删除，App 保留正常登录态。

最终可审阅交付清单见 [delivery_manifest.json](delivery_manifest.json)。压缩包仅采用该显式清单并附清单本身，包含报告、结构化契约、基线、工具来源、脱敏运行摘要与脚本；排除 APK、完整反编译/AOT、对象池、原始日志、截图、账号会话和设备私有回包。包内文件可按清单的 SHA256 核验；源码与私有证据链接仍需本机完整分析目录，整个分析目录不属于可分享内容。

## 证据入口

[E01]: blutter/asm/jhk_account/jhk_auth_data.dart:10
[E02]: blutter/asm/jhk_biz_device/src/agent/network_agent.dart:3730
[E03]: blutter/asm/jhk_biz_device/src/agent/dto/device_dto.dart:2894
[E04]: blutter/asm/jhk_biz_device/src/agent/params/parameter.dart:10
[E05]: blutter/asm/jhk_network/jhk_network.dart:458
[E06]: blutter/asm/jhk_biz_device/src/domain/manager.dart:13019
[E07]: blutter/asm/jhk_network/jhk_network_method_channel.dart:10
[E08]: blutter/objs.txt:55225
[E09]: blutter/asm/jhk_network/jhk_native_response.dart:98
[E10]: blutter/asm/jhk_biz_device/src/agent/dto/payload.dart:10
[E11]: blutter/asm/jhk_biz_control/domain/model/washer/washer_control_helper.dart:95
[E12]: blutter/asm/jhk_biz_control/domain/model/common/dev_control_helper.dart:1902
[E13]: blutter/asm/jhk_biz_device/src/agent/network_agent.dart:4813
[E14]: blutter/asm/jhk_main_page/src/widgets/large_dev_card/dryer/dryer_state_vm.dart:1493
[E15]: blutter/asm/jhk_main_page/src/widgets/large_dev_card/washer/washer_state_vm.dart:8693
[E16]: blutter/asm/jhk_main_page/src/widgets/large_dev_card/washer/washer_device_status_helper.dart:388
