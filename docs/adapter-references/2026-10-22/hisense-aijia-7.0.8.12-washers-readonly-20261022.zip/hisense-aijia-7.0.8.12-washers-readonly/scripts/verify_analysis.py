#!/usr/bin/env python3
"""Verify this local analysis and build an explicit share-file manifest. Offline only."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
FILES = [
    "README.md", "contract.json", "baseline.json", "tool_provenance.json",
    "runtime/status.json", "runtime/observations.json", "models.json", "resources.json",
    "scripts/baseline.py", "scripts/build_contract.py", "scripts/build_models.py",
    "scripts/read_panel_snapshot.mjs", "scripts/verify_analysis.py",
]


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def main():
    baseline = json.loads((ROOT / "baseline.json").read_text())
    apk = ROOT.parents[2] / baseline["apk"]
    assert digest(apk) == baseline["sha256"], "Input APK changed"
    models_path = ROOT / "models.json"
    models_before = models_path.read_bytes()
    observations_before = (ROOT / "runtime/observations.json").read_bytes()
    subprocess.run([sys.executable, str(ROOT / "scripts/build_models.py")], check=True)
    assert models_path.read_bytes() == models_before, "Model generation differed"
    assert (ROOT / "runtime/observations.json").read_bytes() == observations_before
    contract_path = ROOT / "contract.json"
    before = contract_path.read_bytes()
    subprocess.run([sys.executable, str(ROOT / "scripts/build_contract.py")], check=True)
    assert contract_path.read_bytes() == before, "Contract differed from its generator"
    contract = json.loads(before)
    assert len(contract["operations"]) == 13
    assert contract["scope"]["control_executed"] is False
    refs = contract["transport_boundary"]["evidence"][:]
    for op in contract["operations"]:
        assert op["execution_enabled"] is False
        assert op["verification"]["control_executed"] is False
        assert op["verification"]["independent_read_verified"] is False
        refs.extend(op["evidence"])
    for ref in refs:
        path = ROOT / ref["file"]
        assert path.is_file() and digest(path) == ref["sha256"], ref["file"]
        assert 1 <= ref["line"] <= len(path.read_text().splitlines()), ref
    readme = (ROOT / "README.md").read_text()
    links = re.findall(r"\]\(([^)]+)\)", readme)
    links += re.findall(r"^\[E\d+\]:\s*(\S+)", readme, re.M)
    for link in links:
        if link.startswith(("https://", "http://", "#")):
            continue
        target = re.sub(r":\d+$", "", link)
        if target == "delivery_manifest.json":
            continue  # This file is created and read back below.
        assert (ROOT / target).is_file(), f"Missing report target: {link}"
        if target != link:
            assert int(link.rsplit(":", 1)[1]) <= len((ROOT / target).read_text().splitlines())
    status = json.loads((ROOT / "runtime/status.json").read_text())
    assert status["control_executed"] is False
    assert status["independent_api_verified"] is False
    assert (ROOT / "runtime/private").stat().st_mode & 0o777 == 0o700
    for path in (ROOT / "runtime/private").rglob("*"):
        if path.is_file():
            assert path.stat().st_mode & 0o077 == 0, f"Private file permissions: {path.name}"
        elif path.is_dir():
            assert path.stat().st_mode & 0o777 == 0o700
    models = json.loads(models_before)
    expected_models = {"WV20W-1": (55, 54), "WH120E5S-1": (49, 37)}
    assert models["group"]["member_id_set_equals_device_module_id_set"] is True
    for model in models["models"]:
        product = model["identity"]["productCode"]
        assert (len(model["functions"]), len(model["programs"])) == expected_models[product]
        assert model["evidence"]["sha256"] == digest(ROOT / model["evidence"]["file"])
        assert model["verification"]["control_executed"] is False
    resources = json.loads((ROOT / "resources.json").read_text())
    assert len(resources["packages"]) == 3
    resource_files = 0
    for resource in resources["packages"]:
        package = ROOT / resource["local_package"]
        raw = package.read_bytes()
        assert hashlib.md5(raw).hexdigest() == resource["expected_md5"] == resource["actual_md5"]
        assert hashlib.sha256(raw).hexdigest() == resource["sha256"]
        with ZipFile(package) as archive:
            for path in (package.parent / "extracted").rglob("*"):
                if path.is_file():
                    assert path.read_bytes() == archive.read(path.relative_to(package.parent / "extracted").as_posix())
                    resource_files += 1
    # Scan all share files for actual private identifiers, in addition to generic patterns.
    snapshot = json.loads((ROOT / "runtime/private/panel-state.json").read_text())
    secret_names = {"deviceid", "serialnumber", "homeid", "ownerid", "customerid", "groupid", "commoduleid",
                    "token", "accesstoken", "refreshtoken", "subscriberid", "loginname"}
    private_values = set()
    def collect(value):
        if isinstance(value, dict):
            for key, child in value.items():
                if key.lower() in secret_names and isinstance(child, (str, int)) and len(str(child)) >= 6:
                    private_values.add(str(child))
                collect(child)
        elif isinstance(value, list):
            for child in value:
                collect(child)
    collect(snapshot)
    entries = []
    for name in FILES:
        path = ROOT / name
        assert path.is_file() and not path.is_symlink(), name
        content = path.read_text()
        assert not any(value in content for value in private_values), f"Private identifier in {name}"
        # Conservative pattern checks only; this does not certify the whole directory public.
        if path.suffix != ".py":
            assert not re.search(r"Bearer\s+[A-Za-z0-9._~+/=-]{16,}", content), name
            assert not re.search(r"eyJ[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{15,}\.", content), name
            assert not re.search(r'"(?:accessToken|refreshToken|password)"\s*:\s*"(?!unknown)[^"]{16,}"', content), name
            assert not re.search(r"(?<!\d)1[3-9]\d{9}(?!\d)", content), name
        entries.append({"path": name, "bytes": path.stat().st_size, "sha256": digest(path)})
    manifest = {
        "schema_version": 1, "files": entries,
        "manifest_self_hash_excluded": True,
        "excluded": ["APK", "sources/", "jadx/", "blutter/", "*.log", "runtime/private/", "raw account/device/session data"],
        "validation": {"apk_sha256_matches": True, "contract_reproducible": True,
                       "contract_evidence_checked": len(refs), "report_targets_checked": len(links),
                       "model_generation_reproducible": True, "model_id_set_matched_locally": True,
                       "resource_packages_verified": 3, "extracted_resource_files_verified": resource_files,
                       "actual_private_identifiers_scanned": len(private_values),
                       "all_execution_disabled": True, "control_executed": False,
                       "private_permissions_checked": True, "secret_pattern_checks_passed": True},
        "limits": "Explicit review-file list only. Source evidence remains local and is excluded; pattern checks do not certify the full directory shareable. Package only the listed files plus this manifest.",
    }
    target = ROOT / "delivery_manifest.json"
    target.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    for item in json.loads(target.read_text())["files"]:
        assert digest(ROOT / item["path"]) == item["sha256"]
    print(f"Verified {len(refs)} source references, 2 model records, 3 resource packages, {resource_files} extracted files, {len(entries)} share files; no network/device actions")


if __name__ == "__main__":
    main()
