#!/usr/bin/env python3
"""Inventory the supplied Xiaomi APK offline; never contacts Android or cloud."""
import hashlib
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET
from zipfile import ZipFile

ROOT = Path(__file__).resolve().parents[1]
APK = ROOT.parents[2] / "com.xiaomi.smarthome.apk"
EXPECTED = "73335d3c17dff3e73097db7e2f86a373b7eb2c67611dc82749883ab2da3f0b6e"


def save(name, data):
    (ROOT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def main():
    with APK.open("rb") as stream:
        digest = hashlib.file_digest(stream, "sha256").hexdigest()
    if digest != EXPECTED:
        raise SystemExit("APK changed: use a separate analysis directory")
    manifest = ET.parse(ROOT / "jadx/resources/AndroidManifest.xml").getroot()
    android = "{http://schemas.android.com/apk/res/android}"
    sdk = manifest.find("uses-sdk")
    with ZipFile(APK) as archive:
        entries = archive.infolist()
        inventory = []
        for entry in entries:
            row = {"path": entry.filename, "bytes": entry.file_size}
            if entry.filename.endswith((".dex", ".so", ".hbc", ".bundle")) or entry.filename.startswith(("assets/rn_plugins/", "assets/device_config/")):
                row["sha256"] = hashlib.sha256(archive.read(entry)).hexdigest()
            inventory.append(row)
        save("apk_inventory.json", inventory)
        config = json.loads(archive.read("assets/device_config/plugin_config_cn-zh_cn"))
        devices = config["result"]["devices"]["list"]
        save("bundled_models.json", {
            "source": "assets/device_config/plugin_config_cn-zh_cn",
            "source_sha256": hashlib.sha256(archive.read("assets/device_config/plugin_config_cn-zh_cn")).hexdigest(),
            "scope": "Bundled catalog only; not account devices or per-model verified capabilities",
            "models": [{k: item.get(k) for k in ["model", "name", "pd_id", "pid", "subcategory_id", "resolve_type", "min_app_version", "is_matter_type", "ct_offline_enter"]} for item in devices],
        })
        bundled = []
        for entry in entries:
            if entry.filename.startswith("assets/rn_plugins/") and entry.filename.endswith(".zip"):
                bundled.append({"path": entry.filename, "bytes": entry.file_size,
                                "sha256": hashlib.sha256(archive.read(entry)).hexdigest(),
                                "execution_enabled": False})
        save("bundled_plugins.json", bundled)
        baseline = {
            "apk": APK.name, "sha256": digest, "bytes": APK.stat().st_size,
            "package": manifest.get("package"), "version_name": manifest.get(android + "versionName"),
            "version_code": manifest.get(android + "versionCode"),
            "min_sdk": sdk.get(android + "minSdkVersion"), "target_sdk": sdk.get(android + "targetSdkVersion"),
            "compile_sdk": manifest.get(android + "compileSdkVersion"),
            "zip_entries": len(entries), "uncompressed_bytes": sum(e.file_size for e in entries),
            "abis": sorted({e.filename.split('/')[1] for e in entries if e.filename.startswith('lib/')}),
            "native_libraries": sum(e.filename.startswith('lib/') and e.filename.endswith('.so') for e in entries),
            "root_dex_files": [e.filename for e in entries if re.fullmatch(r'classes\d*\.dex', e.filename)],
            "extra_dex_files": [e.filename for e in entries if e.filename.endswith('.dex') and '/' in e.filename],
            "rn_sdk": json.loads(archive.read("assets/plugin_rn_sdk/project.json")),
            "rn_sdk_package": json.loads(archive.read("assets/plugin_rn_sdk/raw/miotsdk_package.json")),
            "catalog_entries": len(devices),
            "scope": "User requests normal App login, then analysis of actual account devices; dynamic verification read-only",
            "control_executed": False,
        }
    save("baseline.json", baseline)
    print(json.dumps({k: baseline[k] for k in ["package", "version_name", "sha256", "native_libraries", "catalog_entries"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
