#!/usr/bin/env python3
"""Fixed CN Xiaomi Home reads only; no arbitrary URL, route, body, RPC or action.

Uses the user's explicitly authorized local session. It does not log in,
renew tokens, follow redirects, execute plugins or change device settings.
"""
import argparse
import base64
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import secrets
import struct
import time
import urllib.error
import urllib.parse
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
HOST = 'https://core.api.mijia.tech'
ROUTES = {'directory': '/v2/home/device_list_page', 'homes': '/v2/homeroom/gethome_merged',
          'properties': '/miotspec/prop/get'}
DIRECTORY = {'getVirtualModel': True, 'getHuamiDevices': 1, 'get_split_device': True,
             'support_smart_home': True, 'get_cariot_device': True,
             'get_third_device': True, 'get_phone_device': True, 'get_miwear_device': True}
HOMES = {'fg': True, 'fetch_share': True, 'fetch_share_dev': True, 'limit': 300,
         'app_ver': 12, 'fetch_cariot': True, 'plat_form': 0}


def b64(value):
    return base64.b64encode(value).decode('ascii')


class RC4:
    def __init__(self, key, drop=1024):
        self.state = list(range(256))
        j = 0
        for i in range(256):
            j = (j + self.state[i] + key[i % len(key)]) & 255
            self.state[i], self.state[j] = self.state[j], self.state[i]
        self.i = self.j = 0
        self.apply(bytes(drop))

    def apply(self, data):
        result = bytearray()
        for byte in data:
            self.i = (self.i + 1) & 255
            self.j = (self.j + self.state[self.i]) & 255
            self.state[self.i], self.state[self.j] = self.state[self.j], self.state[self.i]
            result.append(byte ^ self.state[(self.state[self.i] + self.state[self.j]) & 255])
        return bytes(result)


def signature(route, params, security):
    parts = ['POST', route] + [key + '=' + params[key] for key in sorted(params)] + [security]
    return b64(hashlib.sha1('&'.join(parts).encode('utf-8')).digest())


def encode(route, data, ssecurity, nonce):
    key = hashlib.sha256(base64.b64decode(ssecurity) + base64.b64decode(nonce)).digest()
    security = b64(key)
    plain = {'data': json.dumps(data, ensure_ascii=False, separators=(',', ':'))}
    plain['rc4_hash__'] = signature(route, plain, security)
    cipher = RC4(key)
    encrypted = {name: b64(cipher.apply(plain[name].encode('utf-8'))) for name in sorted(plain)}
    encrypted.update(signature=signature(route, encrypted, security), _nonce=nonce, ssecurity=ssecurity)
    return encrypted, key


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, file, code, message, headers, new_url):
        raise ValueError('Redirect refused')


def sample_allowed(prop):
    name = prop.get('type', '').split(':')[3].lower()
    return 'read' in prop.get('access', []) and not any(term in name for term in
        ['password', 'passwd', 'token', 'secret', 'stream', 'url', 'ssid', 'serial',
         'mac', 'ip-address', 'user-id', 'key-id'])


def known_properties():
    rows = json.loads((ROOT / 'runtime/private/cached-devices.json').read_text())
    specs = {}
    for path in (ROOT / 'runtime/private/device-cache/files/spec_support_cache_v5/128').glob('*'):
        spec = json.loads(gzip.decompress(path.read_bytes()))
        specs[spec['type']] = spec
    result = set()
    for device in rows:
        for service in specs.get(device.get('specUrn'), {}).get('services', []):
            if service['iid'] == 1:
                continue
            for prop in service.get('properties', []):
                # Exclude identity, network credentials and media transport from sampling.
                if sample_allowed(prop):
                    result.add((device['did'], service['iid'], prop['iid']))
    return result


def validate(operation, body, allowed_properties=None):
    if operation not in ROUTES or type(body) is not dict:
        raise ValueError('Operation refused')
    if operation == 'homes':
        if body != HOMES or any(type(body[k]) is not type(v) for k, v in HOMES.items()):
            raise ValueError('Home query shape refused')
    elif operation == 'directory':
        expected = DIRECTORY.copy()
        if 'start_did' in body:
            cursor = body['start_did']
            if type(cursor) is not str or not 1 <= len(cursor) <= 100 or not all(c.isalnum() or c in '._-' for c in cursor):
                raise ValueError('Invalid pagination cursor')
            expected['start_did'] = cursor
        if body != expected or any(type(body[k]) is not type(v) for k, v in expected.items()):
            raise ValueError('Device query shape refused')
    else:
        if set(body) != {'params', 'datasource'} or type(body['datasource']) is not int or body['datasource'] != 2:
            raise ValueError('Property query shape refused')
        params = body['params']
        if type(params) is not list or not 1 <= len(params) <= 90:
            raise ValueError('Property batch refused')
        for param in params:
            if type(param) is not dict or set(param) != {'did', 'siid', 'piid'}:
                raise ValueError('Property item refused')
            if type(param['did']) is not str or type(param['siid']) is not int or type(param['piid']) is not int:
                raise ValueError('Property type refused')
            if (param['did'], param['siid'], param['piid']) not in allowed_properties:
                raise ValueError('Unknown or non-readable property refused')


def send(operation, body):
    validate(operation, body, known_properties() if operation == 'properties' else None)
    session = json.loads((ROOT / 'runtime/private/mijia-session.json').read_text())
    if session['sid'] != 'mijia':
        raise ValueError('Wrong service session')
    route = ROUTES[operation]
    nonce = b64(secrets.token_bytes(8) + struct.pack('>i', int((time.time() * 1000 + session['timeDiff']) / 60000)))
    form, key = encode(route, body, session['ssecurity'], nonce)
    headers = {'Content-Type': 'application/x-www-form-urlencoded', 'Accept-Encoding': 'identity',
               'MIOT-ENCRYPT-ALGORITHM': 'ENCRYPT-RC4', 'MIOT-ACCEPT-ENCODING': 'GZIP',
               'User-Agent': 'Android-13-11.7.709-XiaomiHome',
               'Cookie': 'cUserId=' + session['cUserId'] + '; serviceToken=' + session['serviceToken'] +
                         '; yetAnotherServiceToken=' + session['serviceToken'] + '; countryCode=CN'}
    request = urllib.request.Request(HOST + '/app' + route, urllib.parse.urlencode(form).encode('ascii'), headers, method='POST')
    if urllib.parse.urlsplit(request.full_url).netloc != 'core.api.mijia.tech':
        raise ValueError('Host refused')
    # Explicit direct transport; do not inherit proxy settings or redirect cookies.
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
    with opener.open(request, timeout=30) as response:
        raw = response.read(8 * 1024 * 1024 + 1)
        if len(raw) > 8 * 1024 * 1024:
            raise ValueError('Oversized response')
        metadata = {'received_at': datetime.now(timezone.utc).isoformat(), 'http_status': response.status,
                    'operation': operation, 'route': route, 'raw_sha256': hashlib.sha256(raw).hexdigest(),
                    'session_reused': True, 'proxy_policy': 'direct_no_environment_proxy',
                    'redirects': 'disabled', 'cache_semantics': 'unknown', 'device_sample_time': None}
        # Business failures may be unencrypted JSON; never retry with guessed signing.
        if raw.lstrip().startswith(b'{'):
            decoded = raw
        else:
            decoded = RC4(key).apply(base64.b64decode(raw, validate=True))
            if response.headers.get('MIOT-CONTENT-ENCODING') == 'GZIP':
                decoded = gzip.decompress(decoded)
        data = json.loads(decoded)
    metadata['business_code'] = data.get('code') if isinstance(data, dict) else None
    target = ROOT / ('runtime/private/' + operation + '-' + str(time.time_ns()) + '.json')
    target.write_text(json.dumps({'metadata': metadata, 'request': body, 'response': data}, ensure_ascii=False, indent=2) + '\n')
    target.chmod(0o600)
    if metadata['http_status'] != 200 or type(metadata['business_code']) is not int or metadata['business_code'] != 0 or 'result' not in data:
        raise ValueError('HTTP or outer business response failed; private evidence saved')
    return data['result'], metadata


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation', choices=tuple(ROUTES))
    args = parser.parse_args()
    if args.operation == 'properties':
        plan = sorted(known_properties())
        for offset in range(0, len(plan), 90):
            body = {'params': [dict(zip(['did', 'siid', 'piid'], row)) for row in plan[offset:offset + 90]], 'datasource': 2}
            result, metadata = send('properties', body)
            if not isinstance(result, list):
                raise ValueError('Property response is not a list')
            metadata['requested'] = len(body['params'])
            metadata['returned'] = len(result)
            metadata['successful_items'] = sum(type(row.get('code')) is int and row['code'] == 0 and 'value' in row for row in result)
            metadata['item_codes'] = {str(code): sum(row.get('code') == code for row in result) for code in {row.get('code') for row in result}}
            print(json.dumps(metadata, ensure_ascii=False), flush=True)
    else:
        body = HOMES.copy() if args.operation == 'homes' else DIRECTORY.copy()
        seen = set()
        for _ in range(5):
            result, metadata = send(args.operation, body)
            if not isinstance(result, dict):
                raise ValueError('Directory response is not an object')
            metadata['result_keys'] = list(result)
            for name, value in result.items():
                if isinstance(value, list):
                    metadata[name + '_count'] = len(value)
            print(json.dumps(metadata, ensure_ascii=False), flush=True)
            if args.operation != 'directory' or not result.get('has_more'):
                break
            cursor = result.get('next_start_did')
            if not cursor or cursor in seen:
                raise ValueError('Invalid/repeated pagination cursor')
            seen.add(cursor)
            body = dict(DIRECTORY, start_did=cursor)
        else:
            raise ValueError('Pagination limit reached; enumeration incomplete')


if __name__ == '__main__':
    os.umask(0o077)
    try:
        main()
    except Exception as error:
        raise SystemExit('Read failed: ' + type(error).__name__ + ('; ' + str(error) if isinstance(error, ValueError) else ''))
