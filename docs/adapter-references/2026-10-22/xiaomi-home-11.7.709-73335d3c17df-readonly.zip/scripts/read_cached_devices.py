#!/usr/bin/env python3
"""Decode fixed cached Device parcel records offline using APK field order.

Only selected identity/config fields are saved; tokens, MAC, IP, coordinates,
SSID, serials and owner identity are skipped. No Android code is executed.
"""
import json
from pathlib import Path
import re
import struct

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'runtime/private/device-cache/files/datastore/own_home_device_33_v2.parcel'
KEEP = {'did', 'model', 'name', 'isOnline', 'thirdStatus', 'pid', 'permitLevel',
        'showMode', 'hideMode', 'parentId', 'parentModel', 'mPropInfo', 'methodInfo',
        'extraInfo', 'event', 'canUseNotBind', 'canAuth', 'descNew', 'descTimeJString',
        'specUrn', 'voiceCtrl', 'freqFlag', 'comFlag', 'ethType', 'sort', 'lastModified',
        'accessType', 'lastOnline'}
FIELDS = [
    ('s', 'did'), ('s', 'model'), ('s', 'name'), ('s', 'mac'),
    ('i', 'isOnline'), ('i', 'thirdStatus'), ('i', 'pid'), ('i', 'permitLevel'),
    ('i', 'resetFlag'), ('i', 'rssi'), ('s', 'token'), ('s', 'localIP'),
    ('d', 'longitude'), ('d', 'latitude'), ('s', 'ssid'), ('s', 'bssid'),
    ('i', 'showMode'), ('i', 'hideMode'), ('s', 'icon'), ('s', 'parentId'),
    ('s', 'parentModel'), ('s', 'ownerName'), ('s', 'ownerId'), ('s', 'mPropInfo'),
    ('s', 'methodInfo'), ('s', 'extraInfo'), ('s', 'event'), ('i', 'location'),
    ('i', 'canUseNotBind'), ('i', 'canAuth'), ('s', 'descNew'), ('s', 'descTimeJString'),
    ('s', 'specUrn'), ('i', 'voiceCtrl'), ('i', 'freqFlag'), ('i', 'comFlag'),
    ('s', 'orderTimeJString'), ('i', 'ethType'), ('s', 'userId'), ('i', 'sort'),
    ('q', 'lastModified'), ('s', 'ip'), ('i', 'isNew'), ('i', 'scrollTo'),
    ('i', 'isConnected'), ('s', 'sn'), ('i', 'accessType'), ('s', 'partnerId'),
    ('s', 'meshId'), ('q', 'lastOnline'), ('s', 'carConfig'), ('s', 'carPicInfo'),
    ('s', 'devPicInfo'),
]


class Parcel:
    def __init__(self, data, offset, origin):
        self.data, self.offset, self.origin = data, offset, origin

    def value(self, kind):
        if kind == 's':
            length = self.value('i')
            if length == -1:
                return None
            if not 0 <= length <= 1000000:
                raise ValueError('Invalid parcel string length')
            end = self.offset + length * 2
            if self.data[end:end + 2] != b'\0\0':
                raise ValueError('Parcel string terminator mismatch')
            value = self.data[self.offset:end].decode('utf-16-le')
            self.offset = self.origin + ((end + 2 - self.origin + 3) // 4) * 4
            return value
        value = struct.unpack_from('<' + kind, self.data, self.offset)[0]
        self.offset += struct.calcsize('<' + kind)
        return value


def main():
    data = SOURCE.read_bytes()
    # DataStore framing before the marshalled Bundle; verify its magic.
    if data[9:13] != b'BNDL':
        raise SystemExit('Unrecognized cache framing; do not guess field offsets')
    parcel = Parcel(data, 13, 5)
    if parcel.value('i') != 1 or parcel.value('s') != 'parcel' or parcel.value('i') != 4:
        raise ValueError('Unexpected cache Bundle layout')
    value_size = parcel.value('i')
    value_start = parcel.offset
    if parcel.value('s') != 'com.xiaomi.smarthome.device.module.DeviceCacheStore$HomeCache':
        raise ValueError('Unexpected cache Parcelable')
    parcel.value('s')  # homeId remains private and is unnecessary for comparison.
    rows = []
    partitions = {}
    for partition in ['devicesAll', 'deviceHideExtra', 'deviceHideGroupMember']:
        count = parcel.value('i')
        if not 0 <= count <= 10000:
            raise ValueError('Invalid cache list count')
        partitions[partition] = count
        for _ in range(count):
            offset = parcel.offset + 4
            full = parcel.value('s')
            short = full.removeprefix('com.xiaomi.smarthome.device.')
            if short not in ['BleDevice', 'MiioDeviceV2', 'BleMeshDevice', 'WatchBandDevice']:
                raise ValueError('Unsupported Device subclass')
            row = {'parcel_class': short, 'file_offset': offset, 'cache_partition': partition}
            for kind, name in FIELDS:
                value = parcel.value(kind)
                if name in KEEP:
                    row[name] = value
            if short == 'BleDevice':
                # This snapshot has no packet/scan payloads. Refuse new shapes.
                if [parcel.value('i') for _ in range(4)] != [-1, -1, 0, -1]:
                    raise ValueError('Unsupported BLE payload; do not guess its layout')
            if not row['did'] or not re.fullmatch(r'[\w.-]+', row['model'] or ''):
                raise ValueError('Invalid device identity')
            rows.append(row)
    if parcel.offset != value_start + value_size or parcel.offset != len(data):
        raise ValueError('Cache length/partition boundary mismatch')
    rows.sort(key=lambda row: row['file_offset'])
    if len({row['did'] for row in rows}) != len(rows):
        raise ValueError('Duplicate device IDs in cache')
    target = ROOT / 'runtime/private/cached-devices.json'
    target.write_text(json.dumps(rows, ensure_ascii=False, indent=2) + '\n')
    target.chmod(0o600)
    (ROOT / 'runtime/cache-structure.json').write_text(json.dumps({
        'partitions': partitions, 'entire_value_consumed': True,
        'interpretation': 'Parsed HomeCache lists in order; not a marker scan'
    }, indent=2) + '\n')
    print('Parsed device cache records:', len(rows))
    for row in rows:
        print(row['model'], 'pid=' + str(row['pid']), 'cache_online=' + str(row['isOnline']), row['specUrn'])


if __name__ == '__main__':
    main()
