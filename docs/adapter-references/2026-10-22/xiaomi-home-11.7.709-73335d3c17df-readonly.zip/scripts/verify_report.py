#!/usr/bin/env python3
"""Offline checks of local evidence, schema observations and selected delivery files."""
import base64
from collections import Counter
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import re
import stat
import urllib.parse

ROOT = Path(__file__).resolve().parents[1]
PRIVATE = ROOT / 'runtime/private'
DELIVERY = [
    'README.md', 'baseline.json', 'contract.json', 'models.json',
    'runtime/status.json', 'runtime/cache-structure.json', 'runtime/observations.json', 'runtime/shutdown.json',
    'scripts/baseline.py', 'scripts/build_report.py', 'scripts/read_cached_devices.py',
    'scripts/readonly_client.py', 'scripts/test_readonly_client.py', 'scripts/verify_report.py',
    'verification.json']


def load(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    contract = load(ROOT / 'contract.json')
    model_doc = load(ROOT / 'models.json')
    status = load(ROOT / 'runtime/status.json')
    baseline = load(ROOT / 'baseline.json')
    require(sha(ROOT.parents[2] / 'com.xiaomi.smarthome.apk') == baseline['sha256'], 'APK digest changed')
    for ref in contract['evidence']:
        path = ROOT / ref['path']
        require(sha(path) == ref['sha256'], 'Source digest mismatch: ' + ref['path'])
        lines = path.read_text().splitlines()
        require(0 < ref['line'] <= len(lines) and ref['contains'] in lines[ref['line'] - 1], 'Source line mismatch: ' + ref['path'])
    private_count = 0
    for path in [PRIVATE, *PRIVATE.rglob('*')]:
        require(not path.is_symlink(), 'Private evidence symlink refused')
        expected = 0o700 if path.is_dir() else 0o600
        require(stat.S_IMODE(path.stat().st_mode) == expected, 'Private permission mismatch: ' + str(path.relative_to(ROOT)))
        private_count += int(path.is_file())
    cache_manifest = load(PRIVATE / 'device-cache/manifest.json')
    for item in cache_manifest['files']:
        path = PRIVATE / 'device-cache' / item['path']
        require(sha(path) == item['sha256'] and path.stat().st_size == item['bytes'], 'Copied cache digest mismatch')
    observations = load(ROOT / 'runtime/observations.json')
    resource_index = load(PRIVATE / 'resource-index.json')
    for template in contract['plugin_resolution']['candidates']:
        require(sha(ROOT / resource_index[template['resource_id']]) == template['sha256'], 'Template digest mismatch')
    counts = Counter()
    for snap in observations['snapshots']:
        path = ROOT / snap['evidence_file']
        require(sha(path) == snap['evidence_file_sha256'], 'Response evidence file digest mismatch')
        raw = load(path)
        require(raw['metadata']['raw_sha256'] == snap['raw_sha256'], 'Recorded transport digest mismatch')
        require(raw['response']['code'] == 0 and raw['metadata']['http_status'] == 200, 'Outer request failed')
        if snap['operation'] == 'properties':
            keys = lambda row: (row['did'], row['siid'], row['piid'])
            requested = [keys(x) for x in raw['request']['params']]
            returned = [keys(x) for x in raw['response']['result']]
            require(sorted(requested) == sorted(returned) and len(set(requested)) == len(requested), 'Property identity/length mismatch')
            counts.update(x['code'] for x in raw['response']['result'])
    require(sum(counts.values()) == 324 and counts[0] == 40, 'Property totals inconsistent')
    for entry in model_doc['models']:
        source = entry['spec_source']
        if source:
            path = ROOT / source['path']
            spec = json.loads(gzip.decompress(path.read_bytes()))
            require(sha(path) == source['sha256'] and spec['type'] == entry['spec_urn'], 'Spec digest/URN mismatch')
            clean_services = json.loads(json.dumps(entry['services']))
            for service in clean_services:
                for kind in ['properties', 'actions', 'events']:
                    for item in service.get(kind, []):
                        item.pop('analysis_verification', None)
            require(clean_services == spec['services'], 'Model schema constraints changed')
        props = {(service['iid'], prop['iid']): prop for service in entry['services'] for prop in service.get('properties', [])}
        successes = 0
        for device in entry['instances']:
            for read in device['read_observations']:
                prop = props[(read['siid'], read['piid'])]
                require('read' in prop.get('access', []), 'Non-readable property sampled')
                if not read['valid_value_received']:
                    require(read['code'] != 0, 'Zero code without valid value requires explicit handling')
                    continue
                successes += 1
                if 'value' in read:
                    value = read['value']
                    fmt = prop['format']
                    if fmt == 'bool':
                        require(type(value) is bool, 'Boolean property type mismatch')
                    elif fmt in ['uint8', 'uint16', 'uint32', 'uint64', 'int8', 'int16', 'int32', 'int64']:
                        require(type(value) is int, 'Integer property type mismatch')
                    elif fmt in ['float', 'double']:
                        require(type(value) in [int, float], 'Numeric property type mismatch')
                    if 'value-list' in prop:
                        require(value in [v['value'] for v in prop['value-list']], 'Value absent from spec enum')
                    if 'value-range' in prop:
                        lo, hi, step = prop['value-range']
                        require(lo <= value <= hi, 'Value outside spec range')
                        if step:
                            require(abs((value - lo) / step - round((value - lo) / step)) < 1e-5, 'Value outside spec step')
        require(successes == entry['independent_read_summary']['successful_items'], 'Per-model success mismatch')
    require(len(model_doc['models']) == 19 and model_doc['comparison']['common_ids'] == 21, 'Inventory mismatch')
    require(status['independent_http_read_verified'] and not status['control_executed'], 'Runtime status stale')
    shutdown = load(ROOT / 'runtime/shutdown.json')
    require(shutdown['waydroid_session'] == 'STOPPED' and shutdown['waydroid_service'] == 'inactive'
            and shutdown['adb_server_running'] is False and shutdown['android_runtime_processes_remaining'] == [],
            'Android shutdown not verified')
    require(not any(x['execution_enabled'] for x in contract['operations'] if x['semantics'] in ['write', 'action', 'mixed_unknown']), 'Write execution exposed')

    # Scan only explicit delivery files against known private identifiers/secrets.
    # This does not certify raw sources or the entire analysis directory as public.
    session = load(PRIVATE / 'mijia-session.json')
    sensitive = [session[k] for k in ['serviceToken', 'ssecurity', 'cUserId']]
    directory_path, = PRIVATE.glob('directory-*.json')
    directory = load(directory_path)
    sensitive_keys = {'did', 'uid', 'token', 'mac', 'bssid', 'ssid', 'sn', 'ownerId', 'parent_id'}

    def collect(value):
        if isinstance(value, dict):
            for key, item in value.items():
                if key in sensitive_keys and isinstance(item, (str, int)) and len(str(item)) >= 8:
                    sensitive.append(str(item))
                collect(item)
        elif isinstance(value, list):
            for item in value:
                collect(item)

    collect(directory)
    collect(load(PRIVATE / 'cached-devices.json'))
    variants = set()
    for secret in sensitive:
        variants.update([secret, urllib.parse.quote(secret, safe=''), base64.b64encode(secret.encode()).decode()])
    secret = session['ssecurity']
    variants.add(base64.b64decode(secret).hex())
    selected = [path for path in DELIVERY if path != 'verification.json']
    for relative in selected:
        text = (ROOT / relative).read_text()
        require(not any(value in text for value in variants), 'Known private value in delivery: ' + relative)
        require(re.search(r'\b(?:[0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}\b', text) is None, 'MAC literal in delivery: ' + relative)
    result = {'verified_at': datetime.now(timezone.utc).isoformat(), 'offline_only': True,
        'checks': {'apk_digest': True, 'source_lines_and_hashes': len(contract['evidence']),
                   'cache_files': len(cache_manifest['files']), 'response_snapshots': len(observations['snapshots']),
                   'property_identity_and_nested_results': True, 'model_spec_constraints_preserved': True,
                   'successful_numeric_value_types_enum_range_step': True, 'private_files_permission_checked': private_count,
                   'selected_delivery_known_secret_scan': True, 'write_execution_disabled': True},
        'property_items': sum(counts.values()), 'successful_property_items': counts[0],
        'limits': ['Transport raw SHA256 was recorded at receipt; encrypted wire bytes were not retained for rehashing.',
                   'Known-secret scanning covers explicit delivery files only, not raw sources/private evidence.',
                   'Offline tests do not prove current session validity or additional model capabilities.']}
    (ROOT / 'verification.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    manifest = {'files': [{'path': path, 'sha256': sha(ROOT / path), 'bytes': (ROOT / path).stat().st_size} for path in DELIVERY],
        'exclusions': ['runtime/private/**', 'sources/**', 'jadx/**', '*.log', '*.apk', '*.dex',
                       'device/account IDs and names, SN/MAC/network identity, credentials, raw responses, screenshots and logs',
                       'session extraction and privileged cache copy scripts; raw catalog/index outputs'],
        'private_material_uploaded': False, 'archive_created': False,
        'redaction_notes': ['Account-prefixed template filenames replaced with anonymous resource IDs.',
                            'Device/account IDs, names, network identifiers and string property values excluded.',
                            'No original source copies included; no source redactions or line-number changes in this package.'],
        'reproducibility': 'Synthetic client tests standalone. Report generation/full verification need excluded local APK/source/private evidence.',
        'manifest_digest': 'Manifest does not hash itself; files have individual SHA256.'}
    (ROOT / 'delivery_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    print('Offline evidence verification passed; selected delivery files:', len(DELIVERY))


if __name__ == '__main__':
    main()
