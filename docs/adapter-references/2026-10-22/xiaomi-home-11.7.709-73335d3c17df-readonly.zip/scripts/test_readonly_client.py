#!/usr/bin/env python3
"""Offline cryptography/deny-boundary tests; uses synthetic values only."""
import base64
import hashlib
import json
import unittest
import urllib.request

import readonly_client as client


class ReadOnlyTests(unittest.TestCase):
    def test_network_identifier_not_in_sampling_plan(self):
        prop = {'type': 'urn:miot-spec-v2:property:dhcp-server-mac:00000000:test:1', 'access': ['read']}
        self.assertFalse(client.sample_allowed(prop))

    def test_rc4_published_vector_and_drop(self):
        self.assertEqual(client.RC4(b'Key', drop=0).apply(b'Plaintext').hex(), 'bbf316e8d940af0ad3')
        cipher = client.RC4(bytes([1, 2, 3, 4, 5]), drop=1024)
        self.assertEqual(cipher.apply(bytes(16)).hex(), '30abbcc7c20b01609f23ee2d5f6bb7df')

    def test_signed_plain_and_continuous_encrypted_parameters(self):
        route = '/miotspec/prop/get'
        secret = client.b64(bytes(range(16)))
        nonce = client.b64(bytes(range(12)))
        body = {'params': [{'did': 'synthetic', 'siid': 2, 'piid': 1}], 'datasource': 2}
        form, key = client.encode(route, body, secret, nonce)
        security = client.b64(hashlib.sha256(bytes(range(16)) + bytes(range(12))).digest())
        self.assertEqual(client.b64(key), security)
        cipher = client.RC4(key)
        plain = {name: cipher.apply(base64.b64decode(form[name])).decode() for name in ['data', 'rc4_hash__']}
        self.assertEqual(json.loads(plain['data']), body)
        expected = base64.b64encode(hashlib.sha1(('POST&' + route + '&data=' + plain['data'] + '&' + security).encode()).digest()).decode()
        self.assertEqual(plain['rc4_hash__'], expected)
        self.assertEqual(form['signature'], client.signature(route, {k: form[k] for k in ['data', 'rc4_hash__']}, security))

    def test_reject_write_proxy_and_arbitrary_body(self):
        for operation in ['set', 'action', 'rpc', '/miotspec/prop/set', 'https://attacker.example']:
            with self.subTest(operation=operation), self.assertRaises(ValueError):
                client.validate(operation, {})
        for extra in [{'url': 'https://attacker.example'}, {'method': 'set_power'}, {'value': True}, {'dids': ['arbitrary']}]:
            with self.subTest(extra=extra), self.assertRaises(ValueError):
                client.validate('directory', dict(client.DIRECTORY, **extra))
        client.validate('directory', client.DIRECTORY.copy())
        client.validate('homes', client.HOMES.copy())

    def test_only_actual_readable_properties_and_fixed_types(self):
        allowed = {('synthetic', 2, 1)}
        valid = {'params': [{'did': 'synthetic', 'siid': 2, 'piid': 1}], 'datasource': 2}
        client.validate('properties', valid, allowed)
        for body in [dict(valid, datasource=True), dict(valid, datasource=1), dict(valid, url='x'),
                     dict(valid, params=[]), dict(valid, params=valid['params'] * 91),
                     dict(valid, params=[dict(valid['params'][0], value=True)]),
                     dict(valid, params=[dict(valid['params'][0], piid=99)]),
                     dict(valid, params=[dict(valid['params'][0], siid=True)])]:
            with self.subTest(body=body), self.assertRaises(ValueError):
                client.validate('properties', body, allowed)

    def test_redirect_rejected_before_cookie_resend(self):
        request = urllib.request.Request(client.HOST + '/app/v2/home/device_list_page', headers={'Cookie': 'synthetic'})
        with self.assertRaises(ValueError):
            client.NoRedirect().redirect_request(request, None, 302, 'Found', {}, 'https://attacker.example')


if __name__ == '__main__':
    unittest.main()
