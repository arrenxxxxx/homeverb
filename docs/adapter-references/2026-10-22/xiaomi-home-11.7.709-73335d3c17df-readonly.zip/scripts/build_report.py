#!/usr/bin/env python3
"""Build redacted local analysis from existing evidence. No network or App writes."""
from collections import Counter, defaultdict
import copy
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PRIVATE = ROOT / 'runtime/private'


def load(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    (ROOT / path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def evidence(path, text):
    source = ROOT / path
    lines = source.read_text().splitlines()
    return {'path': path, 'line': next(i for i, line in enumerate(lines, 1) if text in line),
            'contains': text, 'sha256': sha(source), 'distribution': 'local_evidence_only'}


def main():
    baseline = load(ROOT / 'baseline.json')
    cached = load(PRIVATE / 'cached-devices.json')
    directory_path, = PRIVATE.glob('directory-*.json')
    directory = load(directory_path)
    cloud = directory['response']['result']['list']
    cache_map = {d['did']: d for d in cached}
    cloud_map = {d['did']: d for d in cloud}
    union = sorted(cache_map.keys() | cloud_map.keys())
    aliases = {did: f'D{i:02d}' for i, did in enumerate(union, 1)}
    all_models = sorted({d['model'] for d in cached + cloud})
    comparison = {
        'cloud_records': len(cloud), 'cached_records': len(cached),
        'cloud_models': len({d['model'] for d in cloud}),
        'cached_models': len({d['model'] for d in cached}),
        'common_ids': len(cache_map.keys() & cloud_map.keys()),
        'id_sets_equal': cache_map.keys() == cloud_map.keys(),
        'common_id_model_mismatches': sum(cache_map[k]['model'] != cloud_map[k]['model'] for k in cache_map.keys() & cloud_map.keys()),
        'cloud_only_models': sorted(cloud_map[k]['model'] for k in cloud_map.keys() - cache_map.keys()),
        'cache_only_models': sorted(cache_map[k]['model'] for k in cache_map.keys() - cloud_map.keys()),
        'union_records_for_analysis': len(union), 'union_models_for_analysis': len(all_models),
        'has_more': directory['response']['result']['has_more'],
        'physical_device_count': None,
        'boundary': 'Union is an evidence inventory, not a proven complete physical-device inventory. Two pid=21 switch records are split logical children.',
        'cache_structure': load(ROOT / 'runtime/cache-structure.json')}
    snapshots = []
    reads = defaultdict(list)
    code_counts = Counter()
    total_requested = 0
    for path in sorted(PRIVATE.glob('*-*.json')):
        if not path.name.startswith(('directory-', 'homes-', 'properties-')):
            continue
        d = load(path)
        m = copy.deepcopy(d['metadata'])
        m.update(evidence_file=path.relative_to(ROOT).as_posix(), evidence_file_sha256=sha(path))
        assert m['http_status'] == 200 and m['business_code'] == 0
        if m['operation'] == 'properties':
            requested = {(p['did'], p['siid'], p['piid']) for p in d['request']['params']}
            returned = {(p['did'], p['siid'], p['piid']) for p in d['response']['result']}
            assert len(requested) == len(d['request']['params'])
            assert returned == requested and len(returned) == len(d['response']['result'])
            m.update(requested=len(requested), returned=len(returned), datasource=d['request']['datasource'])
            m['successful_items'] = 0
            for item in d['response']['result']:
                code_counts[item['code']] += 1
                good = type(item.get('code')) is int and item['code'] == 0 and 'value' in item
                m['successful_items'] += int(good)
                out = {'device': aliases[item['did']], 'siid': item['siid'], 'piid': item['piid'],
                       'code': item['code'], 'valid_value_received': good,
                       'received_at': m['received_at'], 'datasource': 2,
                       'updateTime': item.get('updateTime'), 'physical_sample_time_confirmed': False,
                       'evidence_file': m['evidence_file']}
                if good:
                    value = item['value']
                    out['value_type'] = type(value).__name__
                    # Only bool/numeric state values leave private storage. Network MAC is withheld.
                    if type(value) in (bool, int, float):
                        out['value'] = value
                    else:
                        out['value_withheld'] = True
                reads[item['did']].append(out)
            total_requested += len(requested)
        elif m['operation'] == 'homes':
            m['home_count'] = len(d['response']['result']['homelist'])
        else:
            m['record_count'] = len(cloud)
        snapshots.append(m)
    specs = {}
    for path in (PRIVATE / 'device-cache/files/spec_support_cache_v5/128').glob('*'):
        spec = json.loads(gzip.decompress(path.read_bytes()))
        specs[spec['type']] = (spec, {'path': path.relative_to(ROOT).as_posix(), 'sha256': sha(path),
                                    'cache_timestamp': spec.get('timestamp'), 'source': 'App cached MIoT schema; not a fresh spec fetch'})
    template_candidates = defaultdict(list)
    template_inventory = []
    resource_index = {}
    for path in sorted((PRIVATE / 'device-cache/files/std_plugin_config_cache').glob('*.json')):
        data = load(path)
        resource_id = 'T' + str(len(template_inventory) + 1).zfill(2)
        resource_index[resource_id] = path.relative_to(ROOT).as_posix()
        record = {'template': path.name.split('_miot.')[-1], 'plugin_id': data.get('plugin_id'),
                  'version': data.get('version'), 'sha256': sha(path),
                  'source': 'App cached standard-plugin config; private resource index',
                  'resource_id': resource_id,
                  'matching_account_models': sorted(set(data.get('model_list', [])) & set(all_models)),
                  'selection_verified': False}
        template_inventory.append(record)
        for model in record['matching_account_models']:
            template_candidates[model].append(record)
    index_path = PRIVATE / 'resource-index.json'
    index_path.write_text(json.dumps(resource_index, indent=2) + '\n')
    index_path.chmod(0o600)
    entries = []
    for model in all_models:
        ids = [did for did in union if (cloud_map.get(did) or cache_map[did])['model'] == model]
        urns = sorted({u for did in ids for u in [cloud_map.get(did, {}).get('spec_type'), cache_map.get(did, {}).get('specUrn')] if u})
        assert len(urns) <= 1, 'Model schema conflict must be resolved explicitly'
        urn = urns[0] if urns else None
        spec, spec_source = specs.get(urn, (None, None))
        instance_reads = [x for did in ids for x in reads[did]]
        model_entry = {'model': model, 'retail_model_confirmed': False,
            'cloud_instances': sum(did in cloud_map for did in ids), 'cache_instances': sum(did in cache_map for did in ids),
            'spec_urn': urn, 'spec_source': spec_source,
            'plugin_candidates': template_candidates[model],
            'selected_plugin_package_verified': False,
            'independent_read_summary': {'requested': len(instance_reads),
                'successful_items': sum(x['valid_value_received'] for x in instance_reads),
                'successful_instances': len({x['device'] for x in instance_reads if x['valid_value_received']}),
                'codes': dict(sorted(Counter(str(x['code']) for x in instance_reads).items()))},
            'instances': [], 'services': copy.deepcopy(spec['services']) if spec else [],
            'support_boundary': 'Schema definitions and template membership do not prove firmware support. Only matching successful read observations are verified. Writes/actions/events/history/media remain unexecuted.'}
        for did in ids:
            c, k = cloud_map.get(did, {}), cache_map.get(did, {})
            extra = c.get('extra') or {}
            model_entry['instances'].append({'device': aliases[did], 'sources': [v for v, yes in [('cloud', bool(c)), ('cache', bool(k))] if yes],
                'pid': c.get('pid', k.get('pid')), 'logical_split_child': c.get('pid', k.get('pid')) == 21,
                'parent': aliases.get(c.get('parent_id') or k.get('parentId')),
                'cloud_online': c.get('isOnline'), 'cached_online': k.get('isOnline'),
                'firmware': {key: extra[key] for key in ['fw_version', 'mcu_version', 'ble_fw_ver'] if key in extra},
                'read_observations': reads[did]})
        for service in model_entry['services']:
            for prop in service.get('properties', []):
                prop['analysis_verification'] = {
                    'definition_source': 'cached_model_spec',
                    'successful_instances': sorted({x['device'] for x in instance_reads if x['siid'] == service['iid'] and x['piid'] == prop['iid'] and x['valid_value_received']}),
                    'write_executed': False}
            for action in service.get('actions', []):
                action['analysis_verification'] = {'definition_source': 'cached_model_spec', 'executed': False,
                    'argument_mapping': 'in/out refer to property iid within this service; preserve their format, unit and constraints'}
            for event in service.get('events', []):
                event['analysis_verification'] = {'definition_source': 'cached_model_spec', 'subscription_or_history_verified': False,
                    'argument_mapping': 'arguments refer to property iid within this service'}
        model_entry['definition_counts'] = {kind: sum(len(s.get(kind, [])) for s in model_entry['services']) for kind in ['properties', 'actions', 'events']}
        entries.append(model_entry)
    model_document = {'apk_sha256': baseline['sha256'], 'comparison': comparison,
                      'values_policy': 'No full device/account IDs, names, locations, network identifiers or string property values. Aliases are local snapshot references.',
                      'models': entries}
    save('models.json', model_document)
    evidence_refs = [
        evidence('sources/BindDeviceRequest.java', '/v2/home/device_list_page'),
        evidence('sources/BindDeviceBody.java', 'getVirtualModel'),
        evidence('jadx/sources/_m_j/u5.java', '/v2/homeroom/gethome_merged'),
        evidence('sources/yr3.java', 'datasource'),
        evidence('sources/ir7.java', 'api.mijia.tech'),
        evidence('sources/ir7.java', '? "xiaomiio" : "mijia"'),
        evidence('sources/r88.java', '/v2/home/device_list_page'),
        evidence('sources/icc.java', '/app'),
        evidence('sources/m52.java', '/ 60000'),
        evidence('sources/m52.java', 'MessageDigest.getInstance("SHA1")'),
        evidence('jadx/sources/_m_j/mje.java', 'rc4_hash__'),
        evidence('jadx/sources/_m_j/e3a.java', '1024'),
        evidence('sources/oq6.java', 'FormBody.Builder'),
        evidence('sources/MijiaCookie.java', 'yetAnotherServiceToken'),
        evidence('sources/RnPluginHostApiProviderImpl.java', 'doSpecRequest'),
        evidence('sources/MIOTDeviceModuleCore.java', 'callMethod'),
        evidence('sources/MIOTServiceModuleCore.java', 'callSmartHomeAPI'),
        evidence('sources/DeviceRenderer.java', '/v2/plugin/fetch_plugin'),
        evidence('sources/vk9.java', 'jSONObject.put("package_id"'),
        evidence('sources/HomeCache.java', 'devicesAll'),
        evidence('jadx/sources/com/xiaomi/smarthome/device/Device.java', 'public void writeToParcel'),
        evidence('jadx/sources/com/xiaomi/smarthome/state/OooO00o.java', '-704083036')]
    operations = [
        {'id': 'directory', 'semantics': 'read', 'route': '/v2/home/device_list_page',
         'body': {'getVirtualModel': True, 'getHuamiDevices': 1, 'get_split_device': True, 'support_smart_home': True,
                  'get_cariot_device': True, 'get_third_device': True, 'get_phone_device': True, 'get_miwear_device': True},
         'optional_body': {'start_did': 'string pagination cursor from preceding response'},
         'response': 'code==0; result.list; result.has_more; result.next_start_did',
         'independent_read_verified': True, 'scope': 'Fresh directory without known dids; one returned page, has_more=false. Cache set mismatch remains.'},
        {'id': 'homes', 'semantics': 'read', 'route': '/v2/homeroom/gethome_merged',
         'body': {'fg': True, 'fetch_share': True, 'fetch_share_dev': True, 'limit': 300, 'app_ver': 12, 'fetch_cariot': True, 'plat_form': 0},
         'response': 'code==0; result.homelist; paging metadata; home identities remain private',
         'independent_read_verified': True, 'scope': 'One home returned; auxiliary directory dependency, not a claim of all home paging cases'},
        {'id': 'properties', 'semantics': 'read', 'route': '/miotspec/prop/get',
         'body_schema': {'params': [{'did': 'actual device ID string', 'siid': 'integer service iid', 'piid': 'integer property iid'}], 'datasource': 2},
         'constraints': ['1..90 items', 'actual cached device + exact spec read access', 'service 1 identity properties excluded',
                         'network credentials/identity/media fields excluded from sampling', 'no arbitrary values or route'],
         'response': 'outer code==0; result items matched by did/siid/piid; item code==0 and value present required',
         'independent_read_verified': True, 'scope': 'Only per-property successes in models.json; datasource=2 cache/physical sampling semantics unknown'},
        {'id': 'property_write_candidate', 'semantics': 'write', 'route': '/miotspec/prop/set',
         'body_schema': {'params': [{'did': 'string', 'siid': 'integer', 'piid': 'integer', 'value': 'spec typed value'}]},
         'constraints': ['Exact model write access, unit, enum/range in models.json', 'runtime firmware, state and plugin conversions not fully recovered'],
         'independent_read_verified': False, 'scope': 'Static bridge and model schema only; no control authorization or execution'},
        {'id': 'action_candidate', 'semantics': 'action', 'route': '/miotspec/action',
         'body_schema': {'params': {'did': 'string', 'siid': 'integer', 'aiid': 'integer', 'in': 'values corresponding to service action.in property IDs'}},
         'constraints': ['Exact action in/out schema in models.json', 'runtime state/firmware and composite UI behavior unresolved'],
         'independent_read_verified': False, 'scope': 'Static only; no action executed'},
        {'id': 'event_candidate', 'semantics': 'read_candidate', 'route': '/miotspec/event/get',
         'body_schema': None, 'independent_read_verified': False,
         'scope': 'Bridge route and model event argument definitions found; paging, subscription/history body and retention unresolved; not allowlisted'},
        {'id': 'rpc_candidate', 'semantics': 'mixed_unknown', 'route': '/home/rpc/{did}; /home/rpcv2/{did}',
         'body_schema': None, 'independent_read_verified': False,
         'scope': 'Method-level semantics unresolved. Whole RPC proxy never allowlisted.'}]
    for op in operations:
        op.update(http_method='POST', execution_enabled=op['id'] in ['directory', 'homes', 'properties'],
                  control_executed=False, static_recovered=op['body_schema'] is not None if 'body_schema' in op else True)
    contract = {'schema_version': 1, 'apk': baseline, 'scope': 'Actual account objects, all observed internal models; dynamic verification read only',
        'authorization': {'session_extraction': 'User explicitly authorized current CN session into local private files for local read-only verification',
                          'control': False, 'password_read': False, 'renewal': False},
        'authentication': {'mode': 'reuse_existing_app_session', 'service': 'mijia', 'region': 'CN',
            'private_reference': 'runtime/private/mijia-session.json (0600; excluded from delivery)',
            'cookie_fields': ['cUserId', 'serviceToken', 'yetAnotherServiceToken', 'countryCode=CN'],
            'standalone_login_verified': False, 'renewal_verified': False, 'expiry_recovery_verified': False,
            'local_cache_decryption': 'APK-derived Android-ID key, AES/CBC/PKCS5Padding. Key/IV and encrypted login cache excluded from share files.'},
        'transport': {'host': 'https://core.api.mijia.tech', 'url_prefix': '/app', 'method': 'POST',
            'overseas_static_candidate': 'https://{region}.{prefix}api.io.mi.com; xiaomiio SID; not verified',
            'redirects': 'refused', 'proxy': 'explicit direct; environment proxies ignored',
            'headers': {'MIOT-ENCRYPT-ALGORITHM': 'ENCRYPT-RC4', 'MIOT-ACCEPT-ENCODING': 'GZIP', 'Accept-Encoding': 'identity',
                        'Content-Type': 'application/x-www-form-urlencoded'},
            'encoding_steps': [
                'nonce=Base64(random 8 bytes || int32 big-endian floor((epoch_ms+timeDiff_ms)/60000))',
                'key=SHA256(Base64decode(ssecurity)||Base64decode(nonce)); security=Base64(key)',
                'data=compact JSON UTF-8 (ensure_ascii=False)',
                'rc4_hash__=Base64(SHA1(UTF8(POST&business_route&sorted plaintext key=value&security)))',
                'RC4(key), discard 1024 bytes; one continuous stream over sorted data then rc4_hash__; Base64 each ciphertext',
                'signature=Base64(SHA1(UTF8(POST&business_route&sorted encrypted key=value&security)))',
                'Add plaintext _nonce and ssecurity; URL encode all form fields after signing',
                'Sign business_route without /app. Response: Base64 decode, fresh RC4/drop1024, then gzip when header says GZIP; errors may be plaintext JSON'],
            'response_validation': ['HTTP 200', 'integer outer code 0', 'non-null expected result shape', 'property identity match', 'nested code 0 + value required']},
        'operations': operations,
        'model_contract': 'models.json', 'device_comparison': comparison,
        'plugin_resolution': {'chain': ['device.model', 'PluginDeviceManager catalog', 'PluginPackageManager model/package_id/type',
                    'DeviceRenderer /v2/plugin/fetch_plugin latest_req/backup_req', 'downloaded package + MIoT schema + template/customized config',
                    'RN bridge to host provider to authenticated transport'],
            'evidence_level': 'Static call chain and existing cache membership. No plugin fetch or plugin code execution.',
            'candidates': template_inventory,
            'unknowns': ['Actual selected package ID/version per account device not verified',
                         'Two cached switch-template versions overlap; membership does not choose latest',
                         'Cached fridge/washer/lock templates do not establish ownership or support',
                         'HBC/native/plugin-specific behavior, firmware gates and UI transformations incomplete']},
        'verification': {'session_reused': True, 'http_snapshots': len(snapshots), 'property_items_requested': total_requested,
            'property_items_successful': code_counts[0], 'successful_instances': sum(any(x['valid_value_received'] for x in reads[did]) for did in union),
            'successful_models': sum(e['independent_read_summary']['successful_items'] > 0 for e in entries),
            'nested_codes': dict(sorted((str(k), v) for k, v in code_counts.items())),
            'received_at_range': [min(x['received_at'] for x in snapshots), max(x['received_at'] for x in snapshots)],
            'control_executed': False, 'cache_semantics': 'unknown', 'physical_sample_time_confirmed': False,
            'historical_sampling_note': '324 historical items include DHCP MAC property; its string value is private. Sampling whitelist now excludes all MAC-named fields. No unchanged reads repeated.'},
        'evidence': evidence_refs,
        'remaining_unknowns': ['Cache scale vs cloud watch discrepancy and full account/physical completeness',
            'Failed property codes have no proven human-readable meaning in this analysis',
            'Standalone login, token renewal and expiry recovery', 'BLE/local gateway specialized reads, event/history and statistics',
            'Camera/doorbell live media and storage history; no streams/images downloaded',
            'Scale/watch health data and specialized integrations', 'All writes/actions, composite constraints and runtime firmware gates'],
        'tool_provenance': {'jadx': '1.5.6', 'java': '21.0.11-tem',
            'failures': ['Full JADX interrupted/exit137; second attempt -Xmx3g -j2 OOM/exit1 around 31%',
                         'Targeted single-DEX decompiles can invent package/type aliases; exact DEX class index and Metadata take precedence',
                         'PluginDeviceInfo custom cache parser experiment did not consume entire file; not used for model selection'],
            'not_completed': ['complete native disassembly', 'complete HBC/plugin decompilation'],
            'baseline_script': 'scripts/baseline.py', 'offline_tests': 'scripts/test_readonly_client.py'}}
    save('contract.json', contract)
    save('runtime/observations.json', {'comparison': comparison, 'snapshots': snapshots,
         'property_verification': contract['verification'], 'private_values_excluded': True})
    status = load(ROOT / 'runtime/status.json')
    status.update(account_device_enumeration_verified=True, independent_http_read_verified=True,
        account_device_enumeration_scope='One cloud page has_more=false; full equality to local cache NOT verified',
        device_comparison=comparison, independent_reads=contract['verification'],
        session_extraction_authorized=True, session_secret_location='runtime/private/mijia-session.json (0600)',
        pending=contract['remaining_unknowns'], analysis_state='bounded_readonly_analysis_delivered')
    save('runtime/status.json', status)
    table = []
    for e in entries:
        c = e['definition_counts']; s = e['independent_read_summary']
        codes = ', '.join(k + ':' + str(v) for k, v in s['codes'].items() if k != '0') or '—'
        table.append(f"| `{e['model']}` | {e['cloud_instances']}/{e['cache_instances']} | {c['properties']}/{c['actions']}/{c['events']} | {s['successful_items']}/{s['requested']} | {codes} |")
    readme = f'''# 米家 APK 只读接入分析

基线：`com.xiaomi.smarthome` **11.7.709 (110717091)**，SHA256 `{baseline['sha256']}`。原包未修改，使用用户正常登录后的中国区会话；用户明确授权会话仅存本机并用于只读验证。没有执行设备控制、配置、绑定、场景、诊断启动或 OTA。

## 当前可用结论

固定白名单客户端独立完成了设备目录、家庭目录及 MIoT 属性读取：6 次 HTTP 请求均为 200、外层业务码 0；324 项属性返回中 **40 项有效值，涉及 8 个设备对象、7 个内部型号**。其余 284 项为嵌套错误，不能算成功。成功返回包含空净开关/模式/温湿度/PM2.5/滤网、风扇档位与摇头设置、插座/开关状态、网关属性；逐项 siid/piid、类型、单位、枚举、范围和验证结果见 [models.json](models.json)。40 项包含一项 DHCP MAC，其值仅留在私有证据，后续采样白名单已排除 MAC 字段。

云端返回 **22 条、18 个型号**，单页 `has_more=false`；本地缓存也为 22 条、18 个型号，但完整 ID 集合仅 **21 条重合**。云端独有 `miwear.watch.n66tc`，缓存独有 `hmpace.scales.mibfs`。缓存已按 HomeCache 的三个列表顺序完整解析：devicesAll=22，其余列表=0，因此差异不能归因于隐藏列表。共同 ID 的型号不一致数为 {comparison['common_id_model_mismatches']}。分析并集为 23 条记录、19 个内部型号，只用于保留两份证据，**不表示 23 台实体设备或账号全量已一致**。其中两个 `opple.switch.0010d6` pid=21 记录为父开关拆分出的逻辑对象。

读取时间：2026-10-22 **14:26:33–14:27:16（北京时间）**。属性使用 App 默认 `datasource=2`；虽有部分 `updateTime`，缓存语义、回源及真实物理采样时间尚未证实。这是一次状态快照，不能视为持续可用性证明。

## 按实际型号核对

“定义”列为物模型中的属性/动作/事件数，来自 App 的 17 份精确 URN 缓存，属于静态定义；动作和事件均未执行。成功列是有效返回数/请求项数，包含多个实例，不能直接当作功能覆盖率。错误码仅保留原值，不猜测含义。

| 内部型号 | 云端/缓存记录 | 定义：属性/动作/事件 | 有效读取/请求 | 其余返回码:项数 |
| --- | ---: | ---: | ---: | --- |
{chr(10).join(table)}

高级定义已逐型号保留在 JSON：插座的用电/充电保护/定时项，油烟机及灶具关联，摄像机巡航/存储/隐私/AI/围栏/自检，门锁电量/门状态/告警事件，以及 BLE 遥控器、温湿度、水浸等。**这些定义不等于固件已支持或接口已验证。** 本次未取得 BLE 专用读取、历史统计、健康数据、事件订阅或视频流；体脂秤和手表没有取得对应 MIoT schema。

## 已恢复的调用与鉴权

首次枚举使用 `/v2/home/device_list_page` 的完整固定标志，区别于已有 dids 的详情查询。家庭目录是 `/v2/homeroom/gethome_merged`，状态读取是 `/miotspec/prop/get`，每批最多 90 项。具体请求正文、类型、响应包装和限制见 [contract.json](contract.json)。

实际中国区 host 为 `https://core.api.mijia.tech/app`，SID 为 `mijia`。nonce、时间偏移、SHA256 派生键、两层 SHA1 签名、连续 RC4 流（丢弃前 1024 字节）、Base64、表单编码与响应解密均已由独立成功请求交叉验证。签名业务路径不含 `/app`；排序、JSON 原文和编码顺序不能改变。客户端固定域名/路由/正文，拒绝重定向，显式直连，不续期，也不提供任意 RPC/URL/正文入口。

这证明**复用当前 App 会话**可读，不证明独立登录、续期或过期恢复已经完成。认证材料位于本机 `runtime/private/`，目录 0700、文件 0600，不进入交付清单。

插件链已定位到 model → 本地目录 → package_id/type → `fetch_plugin` → RN/MIoT 桥 → host provider → 签名传输。缓存中 switch 1107/2634、camera 4433、doorbell 125 等模板与部分实际型号相交；switch 两版本重叠，尚未证实各设备最终选中的包与版本。下载缓存中出现 fridge/washer/lock 模板不证明账号有相应设备。未发送插件拉取请求或执行未知插件，HBC/native 与插件专属业务仍有缺口。

`prop/set`、`action` 只记录静态参数及精确型号定义，执行关闭。通用 `/home/rpc/{{did}}` 同时可承载读写，未加入白名单。组合操作的 UI 转换、运行状态互斥和固件门槛尚未完整恢复。

## 证据与复核

- [脱敏读取证据](runtime/observations.json)：接收时间、请求/返回计数、响应密文摘要、私有证据文件摘要及集合差异。
- [运行状态](runtime/status.json)：原包安装、登录、语言与当前验证边界。英文界面来自 Waydroid `en-US`，App 无语言覆盖；账号地区仍是 CN，未改语言或地区。
- [基线](baseline.json)：arm64-v8a、14 个主 DEX、137 个 native 库、SDK 24/35；包内 11549 条产品目录是全局候选，不是账号设备。RN 两处元数据版本分别保留，API 均为 10117。
- `contract.json.evidence` 包含原始本地源码的路径、行号、摘要。JADX 1.5.6 全量反编译先中断、后 OOM；定向反编译存在类型/包名推断错误，已按 DEX 索引和 Metadata 限定证据，不能将输出视为完整源码。
- [交付清单](delivery_manifest.json) 仅明确列出的脱敏文档与脚本可用于分享；整个分析目录包含私密证据，不可整体打包。原 APK、DEX/JADX、会话、缓存、截图、日志及私有响应均排除。

离线复核（不会联网）：

```sh
python3 scripts/test_readonly_client.py
python3 scripts/verify_report.py
```

`build_report.py` 根据本机私有快照重建结果；分享清单排除这些快照，因此接收者不能直接重放生成或真实读取。白名单合成数据测试可独立执行。首次会话提取曾因缺少明确认证材料持久化授权被自动审查拒绝；用户随后已明确授权，本次阻塞已解除，未绕过审查。

## 尚未验收

账号缓存/云端差异、物理设备分母、每个设备最终插件版本、失败属性的正确专用读取链路、BLE/局域网协议、历史统计/事件、健康与媒体、独立认证生命周期，以及所有控制/动作的运行约束。当前交付的是上述范围内可复核的只读接入契约，不声明全部功能已接通。
'''
    shutdown_path = ROOT / 'runtime/shutdown.json'
    if shutdown_path.exists():
        shutdown = load(shutdown_path)
        readme += '\n## 本地调试环境收尾\n\n'
        readme += f"已于 {shutdown['verified_at_local']}（北京时间）按用户要求停止米家、海信、美居三个调试 App，关闭 Waydroid 会话、容器及 ADB 服务。安装数据和本机私有分析证据保留，未卸载或清除账号数据。详情见 [关闭记录](runtime/shutdown.json)。\n"
    (ROOT / 'README.md').write_text(readme)
    print('Built report:', len(entries), 'models;', total_requested, 'property responses;', code_counts[0], 'valid values')


if __name__ == '__main__':
    main()
